package talend_3rdi_git.data_masking_connection_details_0_1;

import routines.wordcount;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.EBMR_routine;
import routines.Unstructure_WordcountService;
import routines.Unstructure_WordcountSoapBindingStub;
import routines.Relational;
import routines.Unstructure_WordcountServiceLocator;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TOXLINE_isNumeric_Routine;
import routines.string_to_date;
import routines.Unstructure_Wordcount_PortType;
import routines.TalendString;
import routines.DQTechnical;
import routines.MDM;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.PopulateFromDynamic;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")
/**
 * Job: Data_Masking_Connection_Details Purpose: <br>
 * Description: This job is design to load connection table from excel input. <br>
 * @author nawale, rahul
 * @version 6.2.1.20160704_1411
 * @status 
 */
public class Data_Masking_Connection_Details implements TalendJob {
	static {
		System.setProperty("TalendJob.log",
				"Data_Masking_Connection_Details.log");
	}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(Data_Masking_Connection_Details.class);

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (file_schema_connection_details != null) {

				this.setProperty("file_schema_connection_details",
						file_schema_connection_details.toString());

			}

			if (metadata_host != null) {

				this.setProperty("metadata_host", metadata_host.toString());

			}

			if (metadata_port != null) {

				this.setProperty("metadata_port", metadata_port.toString());

			}

			if (metadata_db_schema != null) {

				this.setProperty("metadata_db_schema",
						metadata_db_schema.toString());

			}

			if (metadata_db_name != null) {

				this.setProperty("metadata_db_name",
						metadata_db_name.toString());

			}

			if (metadata_db_user != null) {

				this.setProperty("metadata_db_user",
						metadata_db_user.toString());

			}

			if (metadata_db_pass != null) {

				this.setProperty("metadata_db_pass",
						metadata_db_pass.toString());

			}

		}

		public String file_schema_connection_details;

		public String getFile_schema_connection_details() {
			return this.file_schema_connection_details;
		}

		public String metadata_host;

		public String getMetadata_host() {
			return this.metadata_host;
		}

		public String metadata_port;

		public String getMetadata_port() {
			return this.metadata_port;
		}

		public String metadata_db_schema;

		public String getMetadata_db_schema() {
			return this.metadata_db_schema;
		}

		public String metadata_db_name;

		public String getMetadata_db_name() {
			return this.metadata_db_name;
		}

		public String metadata_db_user;

		public String getMetadata_db_user() {
			return this.metadata_db_user;
		}

		public String metadata_db_pass;

		public String getMetadata_db_pass() {
			return this.metadata_db_pass;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Data_Masking_Connection_Details";
	private final String projectName = "TALEND_3RDI_GIT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils(
			"_VM20YAVxEeeaMIwQRnCKvg", "0.1");

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err
						.println("Exception in component " + currentComponent);
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Data_Masking_Connection_Details.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Data_Masking_Connection_Details.this,
									new Object[] { e, currentComponent,
											globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						talendLogs_LOGS.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						talendLogs_LOGSProcess(globalMap);
					}
				} catch (TalendException e) {
					// do nothing

				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputExcel_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAddCRCRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlOutput_3_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlOutput_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlOutput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAddCRCRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row5_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendLogs_LOGS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendLogs_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendLogs_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendStats_STATS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendStats_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendStats_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMSSqlInput_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendLogs_LOGS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendStats_STATS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class active_deactivateStruct implements
			routines.system.IPersistableRow<active_deactivateStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime
						* result
						+ ((this.db_type == null) ? 0 : this.db_type.hashCode());

				result = prime * result
						+ ((this.db_nme == null) ? 0 : this.db_nme.hashCode());

				result = prime
						* result
						+ ((this.db_schema == null) ? 0 : this.db_schema
								.hashCode());

				result = prime * result
						+ ((this.host == null) ? 0 : this.host.hashCode());

				result = prime * result
						+ ((this.port == null) ? 0 : this.port.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final active_deactivateStruct other = (active_deactivateStruct) obj;

			if (this.db_type == null) {
				if (other.db_type != null)
					return false;

			} else if (!this.db_type.equals(other.db_type))

				return false;

			if (this.db_nme == null) {
				if (other.db_nme != null)
					return false;

			} else if (!this.db_nme.equals(other.db_nme))

				return false;

			if (this.db_schema == null) {
				if (other.db_schema != null)
					return false;

			} else if (!this.db_schema.equals(other.db_schema))

				return false;

			if (this.host == null) {
				if (other.host != null)
					return false;

			} else if (!this.host.equals(other.host))

				return false;

			if (this.port == null) {
				if (other.port != null)
					return false;

			} else if (!this.port.equals(other.port))

				return false;

			return true;
		}

		public void copyDataTo(active_deactivateStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;
			other.db_user = this.db_user;
			other.db_pass = this.db_pass;
			other.active = this.active;

		}

		public void copyKeysDataTo(active_deactivateStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(active_deactivateStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.db_type, other.db_type);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_nme, other.db_nme);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_schema, other.db_schema);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.host, other.host);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.port, other.port);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class updateStruct implements
			routines.system.IPersistableRow<updateStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime
						* result
						+ ((this.db_type == null) ? 0 : this.db_type.hashCode());

				result = prime * result
						+ ((this.db_nme == null) ? 0 : this.db_nme.hashCode());

				result = prime
						* result
						+ ((this.db_schema == null) ? 0 : this.db_schema
								.hashCode());

				result = prime * result
						+ ((this.host == null) ? 0 : this.host.hashCode());

				result = prime * result
						+ ((this.port == null) ? 0 : this.port.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final updateStruct other = (updateStruct) obj;

			if (this.db_type == null) {
				if (other.db_type != null)
					return false;

			} else if (!this.db_type.equals(other.db_type))

				return false;

			if (this.db_nme == null) {
				if (other.db_nme != null)
					return false;

			} else if (!this.db_nme.equals(other.db_nme))

				return false;

			if (this.db_schema == null) {
				if (other.db_schema != null)
					return false;

			} else if (!this.db_schema.equals(other.db_schema))

				return false;

			if (this.host == null) {
				if (other.host != null)
					return false;

			} else if (!this.host.equals(other.host))

				return false;

			if (this.port == null) {
				if (other.port != null)
					return false;

			} else if (!this.port.equals(other.port))

				return false;

			return true;
		}

		public void copyDataTo(updateStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;
			other.db_user = this.db_user;
			other.db_pass = this.db_pass;
			other.active = this.active;

		}

		public void copyKeysDataTo(updateStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(updateStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.db_type, other.db_type);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_nme, other.db_nme);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_schema, other.db_schema);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.host, other.host);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.port, other.port);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class insertStruct implements
			routines.system.IPersistableRow<insertStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime
						* result
						+ ((this.db_type == null) ? 0 : this.db_type.hashCode());

				result = prime * result
						+ ((this.db_nme == null) ? 0 : this.db_nme.hashCode());

				result = prime
						* result
						+ ((this.db_schema == null) ? 0 : this.db_schema
								.hashCode());

				result = prime * result
						+ ((this.host == null) ? 0 : this.host.hashCode());

				result = prime * result
						+ ((this.port == null) ? 0 : this.port.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final insertStruct other = (insertStruct) obj;

			if (this.db_type == null) {
				if (other.db_type != null)
					return false;

			} else if (!this.db_type.equals(other.db_type))

				return false;

			if (this.db_nme == null) {
				if (other.db_nme != null)
					return false;

			} else if (!this.db_nme.equals(other.db_nme))

				return false;

			if (this.db_schema == null) {
				if (other.db_schema != null)
					return false;

			} else if (!this.db_schema.equals(other.db_schema))

				return false;

			if (this.host == null) {
				if (other.host != null)
					return false;

			} else if (!this.host.equals(other.host))

				return false;

			if (this.port == null) {
				if (other.port != null)
					return false;

			} else if (!this.port.equals(other.port))

				return false;

			return true;
		}

		public void copyDataTo(insertStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;
			other.db_user = this.db_user;
			other.db_pass = this.db_pass;
			other.active = this.active;

		}

		public void copyKeysDataTo(insertStruct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(insertStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.db_type, other.db_type);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_nme, other.db_nme);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.db_schema, other.db_schema);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.host, other.host);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.port, other.port);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements
			routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		public Long CRC;

		public Long getCRC() {
			return this.CRC;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.CRC = null;
					} else {
						this.CRC = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

				// Long

				if (this.CRC == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CRC);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append(",CRC=" + String.valueOf(CRC));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			if (CRC == null) {
				sb.append("<null>");
			} else {
				sb.append(CRC);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out2Struct implements
			routines.system.IPersistableRow<out2Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements
			routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputExcel_1Struct implements
			routines.system.IPersistableRow<after_tFileInputExcel_1Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputExcel_1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				tMSSqlInput_1Process(globalMap);

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();
				out2Struct out2 = new out2Struct();
				row4Struct row4 = new row4Struct();
				active_deactivateStruct active_deactivate = new active_deactivateStruct();
				updateStruct update = new updateStruct();
				insertStruct insert = new insertStruct();

				/**
				 * [tMSSqlOutput_3 begin ] start
				 */

				ok_Hash.put("tMSSqlOutput_3", false);
				start_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());

				currentComponent = "tMSSqlOutput_3";

				int tos_count_tMSSqlOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlOutput_3 = new StringBuilder();
				log4jParamters_tMSSqlOutput_3.append("Parameters:");
				log4jParamters_tMSSqlOutput_3.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("TABLE_ACTION" + " = "
						+ "NONE");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("IDENTITY_INSERT" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("DATA_ACTION" + " = "
						+ "UPDATE");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("COMMIT_EVERY" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("ADD_COLS" + " = " + "[]");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("USE_FIELD_OPTIONS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("IGNORE_DATE_OUTOF_RANGE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("ENABLE_DEBUG_MODE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("SUPPORT_NULL_WHERE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("USE_BATCH_SIZE" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				log4jParamters_tMSSqlOutput_3.append("BATCH_SIZE" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ log4jParamters_tMSSqlOutput_3);

				int nb_line_tMSSqlOutput_3 = 0;
				int nb_line_update_tMSSqlOutput_3 = 0;
				int nb_line_inserted_tMSSqlOutput_3 = 0;
				int nb_line_deleted_tMSSqlOutput_3 = 0;
				int nb_line_rejected_tMSSqlOutput_3 = 0;

				int deletedCount_tMSSqlOutput_3 = 0;
				int updatedCount_tMSSqlOutput_3 = 0;
				int insertedCount_tMSSqlOutput_3 = 0;
				int rejectedCount_tMSSqlOutput_3 = 0;
				String dbschema_tMSSqlOutput_3 = null;
				String tableName_tMSSqlOutput_3 = null;
				boolean whetherReject_tMSSqlOutput_3 = false;

				java.util.Calendar calendar_tMSSqlOutput_3 = java.util.Calendar
						.getInstance();
				long year1_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tMSSqlOutput_3 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tMSSqlOutput_3;

				java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_3 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				int updateKeyCount_tMSSqlOutput_3 = 5;
				if (updateKeyCount_tMSSqlOutput_3 < 1) {
					throw new RuntimeException(
							"For update, Schema must have a key");
				}

				java.sql.Connection conn_tMSSqlOutput_3 = null;
				String dbUser_tMSSqlOutput_3 = null;
				dbschema_tMSSqlOutput_3 = context.metadata_db_schema;
				String driverClass_tMSSqlOutput_3 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Driver ClassName: "
							+ driverClass_tMSSqlOutput_3 + ".");
				java.lang.Class.forName(driverClass_tMSSqlOutput_3);
				String port_tMSSqlOutput_3 = context.metadata_port;
				String dbname_tMSSqlOutput_3 = context.metadata_db_name;
				String url_tMSSqlOutput_3 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlOutput_3)) {
					url_tMSSqlOutput_3 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlOutput_3)) {
					url_tMSSqlOutput_3 += "//" + context.metadata_db_name;
				}
				url_tMSSqlOutput_3 += ";appName=" + projectName + ";" + "";
				dbUser_tMSSqlOutput_3 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlOutput_3 = context.metadata_db_pass;

				String dbPwd_tMSSqlOutput_3 = decryptedPassword_tMSSqlOutput_3;
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Connection attempts to '"
							+ url_tMSSqlOutput_3 + "' with the username '"
							+ dbUser_tMSSqlOutput_3 + "'.");
				conn_tMSSqlOutput_3 = java.sql.DriverManager.getConnection(
						url_tMSSqlOutput_3, dbUser_tMSSqlOutput_3,
						dbPwd_tMSSqlOutput_3);
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Connection to '"
							+ url_tMSSqlOutput_3 + "' has succeeded.");

				resourceMap.put("conn_tMSSqlOutput_3", conn_tMSSqlOutput_3);

				conn_tMSSqlOutput_3.setAutoCommit(false);
				int commitEvery_tMSSqlOutput_3 = 10000;
				int commitCounter_tMSSqlOutput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ "Connection is set auto commit to '"
							+ conn_tMSSqlOutput_3.getAutoCommit() + "'.");
				int batchSize_tMSSqlOutput_3 = 10000;
				int batchSizeCounter_tMSSqlOutput_3 = 0;

				if (dbschema_tMSSqlOutput_3 == null
						|| dbschema_tMSSqlOutput_3.trim().length() == 0) {
					tableName_tMSSqlOutput_3 = "schema_connection_details";
				} else {
					tableName_tMSSqlOutput_3 = dbschema_tMSSqlOutput_3 + "].["
							+ "schema_connection_details";
				}
				int count_tMSSqlOutput_3 = 0;

				String update_tMSSqlOutput_3 = "UPDATE ["
						+ tableName_tMSSqlOutput_3
						+ "] SET [db_user] = ?,[db_pass] = ?,[active] = ? WHERE [db_type] = ? AND [db_nme] = ? AND [db_schema] = ? AND [host] = ? AND [port] = ?";
				java.sql.PreparedStatement pstmt_tMSSqlOutput_3 = conn_tMSSqlOutput_3
						.prepareStatement(update_tMSSqlOutput_3);

				/**
				 * [tMSSqlOutput_3 begin ] stop
				 */

				/**
				 * [tMSSqlOutput_2 begin ] start
				 */

				ok_Hash.put("tMSSqlOutput_2", false);
				start_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());

				currentComponent = "tMSSqlOutput_2";

				int tos_count_tMSSqlOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlOutput_2 = new StringBuilder();
				log4jParamters_tMSSqlOutput_2.append("Parameters:");
				log4jParamters_tMSSqlOutput_2.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("TABLE_ACTION" + " = "
						+ "NONE");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("IDENTITY_INSERT" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DATA_ACTION" + " = "
						+ "UPDATE");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("COMMIT_EVERY" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("ADD_COLS" + " = " + "[]");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USE_FIELD_OPTIONS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("IGNORE_DATE_OUTOF_RANGE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("ENABLE_DEBUG_MODE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("SUPPORT_NULL_WHERE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USE_BATCH_SIZE" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("BATCH_SIZE" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ log4jParamters_tMSSqlOutput_2);

				int nb_line_tMSSqlOutput_2 = 0;
				int nb_line_update_tMSSqlOutput_2 = 0;
				int nb_line_inserted_tMSSqlOutput_2 = 0;
				int nb_line_deleted_tMSSqlOutput_2 = 0;
				int nb_line_rejected_tMSSqlOutput_2 = 0;

				int deletedCount_tMSSqlOutput_2 = 0;
				int updatedCount_tMSSqlOutput_2 = 0;
				int insertedCount_tMSSqlOutput_2 = 0;
				int rejectedCount_tMSSqlOutput_2 = 0;
				String dbschema_tMSSqlOutput_2 = null;
				String tableName_tMSSqlOutput_2 = null;
				boolean whetherReject_tMSSqlOutput_2 = false;

				java.util.Calendar calendar_tMSSqlOutput_2 = java.util.Calendar
						.getInstance();
				long year1_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tMSSqlOutput_2 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tMSSqlOutput_2;

				java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_2 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				int updateKeyCount_tMSSqlOutput_2 = 5;
				if (updateKeyCount_tMSSqlOutput_2 < 1) {
					throw new RuntimeException(
							"For update, Schema must have a key");
				}

				java.sql.Connection conn_tMSSqlOutput_2 = null;
				String dbUser_tMSSqlOutput_2 = null;
				dbschema_tMSSqlOutput_2 = context.metadata_db_schema;
				String driverClass_tMSSqlOutput_2 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Driver ClassName: "
							+ driverClass_tMSSqlOutput_2 + ".");
				java.lang.Class.forName(driverClass_tMSSqlOutput_2);
				String port_tMSSqlOutput_2 = context.metadata_port;
				String dbname_tMSSqlOutput_2 = context.metadata_db_name;
				String url_tMSSqlOutput_2 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlOutput_2)) {
					url_tMSSqlOutput_2 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlOutput_2)) {
					url_tMSSqlOutput_2 += "//" + context.metadata_db_name;
				}
				url_tMSSqlOutput_2 += ";appName=" + projectName + ";" + "";
				dbUser_tMSSqlOutput_2 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlOutput_2 = context.metadata_db_pass;

				String dbPwd_tMSSqlOutput_2 = decryptedPassword_tMSSqlOutput_2;
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Connection attempts to '"
							+ url_tMSSqlOutput_2 + "' with the username '"
							+ dbUser_tMSSqlOutput_2 + "'.");
				conn_tMSSqlOutput_2 = java.sql.DriverManager.getConnection(
						url_tMSSqlOutput_2, dbUser_tMSSqlOutput_2,
						dbPwd_tMSSqlOutput_2);
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Connection to '"
							+ url_tMSSqlOutput_2 + "' has succeeded.");

				resourceMap.put("conn_tMSSqlOutput_2", conn_tMSSqlOutput_2);

				conn_tMSSqlOutput_2.setAutoCommit(false);
				int commitEvery_tMSSqlOutput_2 = 10000;
				int commitCounter_tMSSqlOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection is set auto commit to '"
							+ conn_tMSSqlOutput_2.getAutoCommit() + "'.");
				int batchSize_tMSSqlOutput_2 = 10000;
				int batchSizeCounter_tMSSqlOutput_2 = 0;

				if (dbschema_tMSSqlOutput_2 == null
						|| dbschema_tMSSqlOutput_2.trim().length() == 0) {
					tableName_tMSSqlOutput_2 = "schema_connection_details";
				} else {
					tableName_tMSSqlOutput_2 = dbschema_tMSSqlOutput_2 + "].["
							+ "schema_connection_details";
				}
				int count_tMSSqlOutput_2 = 0;

				String update_tMSSqlOutput_2 = "UPDATE ["
						+ tableName_tMSSqlOutput_2
						+ "] SET [db_user] = ?,[db_pass] = ?,[active] = ? WHERE [db_type] = ? AND [db_nme] = ? AND [db_schema] = ? AND [host] = ? AND [port] = ?";
				java.sql.PreparedStatement pstmt_tMSSqlOutput_2 = conn_tMSSqlOutput_2
						.prepareStatement(update_tMSSqlOutput_2);

				/**
				 * [tMSSqlOutput_2 begin ] stop
				 */

				/**
				 * [tMSSqlOutput_1 begin ] start
				 */

				ok_Hash.put("tMSSqlOutput_1", false);
				start_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());

				currentComponent = "tMSSqlOutput_1";

				int tos_count_tMSSqlOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlOutput_1 = new StringBuilder();
				log4jParamters_tMSSqlOutput_1.append("Parameters:");
				log4jParamters_tMSSqlOutput_1.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("TABLE_ACTION" + " = "
						+ "NONE");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("IDENTITY_INSERT" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DATA_ACTION" + " = "
						+ "INSERT");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("COMMIT_EVERY" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("ADD_COLS" + " = " + "[]");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USE_FIELD_OPTIONS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("IGNORE_DATE_OUTOF_RANGE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("ENABLE_DEBUG_MODE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("SUPPORT_NULL_WHERE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USE_BATCH_SIZE" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("BATCH_SIZE" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ log4jParamters_tMSSqlOutput_1);

				int nb_line_tMSSqlOutput_1 = 0;
				int nb_line_update_tMSSqlOutput_1 = 0;
				int nb_line_inserted_tMSSqlOutput_1 = 0;
				int nb_line_deleted_tMSSqlOutput_1 = 0;
				int nb_line_rejected_tMSSqlOutput_1 = 0;

				int deletedCount_tMSSqlOutput_1 = 0;
				int updatedCount_tMSSqlOutput_1 = 0;
				int insertedCount_tMSSqlOutput_1 = 0;
				int rejectedCount_tMSSqlOutput_1 = 0;
				String dbschema_tMSSqlOutput_1 = null;
				String tableName_tMSSqlOutput_1 = null;
				boolean whetherReject_tMSSqlOutput_1 = false;

				java.util.Calendar calendar_tMSSqlOutput_1 = java.util.Calendar
						.getInstance();
				long year1_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tMSSqlOutput_1 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tMSSqlOutput_1;

				java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tMSSqlOutput_1 = null;
				String dbUser_tMSSqlOutput_1 = null;
				dbschema_tMSSqlOutput_1 = context.metadata_db_schema;
				String driverClass_tMSSqlOutput_1 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Driver ClassName: "
							+ driverClass_tMSSqlOutput_1 + ".");
				java.lang.Class.forName(driverClass_tMSSqlOutput_1);
				String port_tMSSqlOutput_1 = context.metadata_port;
				String dbname_tMSSqlOutput_1 = context.metadata_db_name;
				String url_tMSSqlOutput_1 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlOutput_1)) {
					url_tMSSqlOutput_1 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlOutput_1)) {
					url_tMSSqlOutput_1 += "//" + context.metadata_db_name;
				}
				url_tMSSqlOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tMSSqlOutput_1 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlOutput_1 = context.metadata_db_pass;

				String dbPwd_tMSSqlOutput_1 = decryptedPassword_tMSSqlOutput_1;
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Connection attempts to '"
							+ url_tMSSqlOutput_1 + "' with the username '"
							+ dbUser_tMSSqlOutput_1 + "'.");
				conn_tMSSqlOutput_1 = java.sql.DriverManager.getConnection(
						url_tMSSqlOutput_1, dbUser_tMSSqlOutput_1,
						dbPwd_tMSSqlOutput_1);
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Connection to '"
							+ url_tMSSqlOutput_1 + "' has succeeded.");

				resourceMap.put("conn_tMSSqlOutput_1", conn_tMSSqlOutput_1);

				conn_tMSSqlOutput_1.setAutoCommit(false);
				int commitEvery_tMSSqlOutput_1 = 10000;
				int commitCounter_tMSSqlOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection is set auto commit to '"
							+ conn_tMSSqlOutput_1.getAutoCommit() + "'.");
				int batchSize_tMSSqlOutput_1 = 10000;
				int batchSizeCounter_tMSSqlOutput_1 = 0;

				if (dbschema_tMSSqlOutput_1 == null
						|| dbschema_tMSSqlOutput_1.trim().length() == 0) {
					tableName_tMSSqlOutput_1 = "schema_connection_details";
				} else {
					tableName_tMSSqlOutput_1 = dbschema_tMSSqlOutput_1 + "].["
							+ "schema_connection_details";
				}
				int count_tMSSqlOutput_1 = 0;

				String insert_tMSSqlOutput_1 = "INSERT INTO ["
						+ tableName_tMSSqlOutput_1
						+ "] ([db_type],[db_nme],[db_schema],[host],[port],[db_user],[db_pass],[active]) VALUES (?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tMSSqlOutput_1 = conn_tMSSqlOutput_1
						.prepareStatement(insert_tMSSqlOutput_1);

				/**
				 * [tMSSqlOutput_1 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_2 = new StringBuilder();
				log4jParamters_tMap_2.append("Parameters:");
				log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_2.append(" | ");
				log4jParamters_tMap_2
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + log4jParamters_tMap_2);

				// ###############################
				// # Lookup's keys initialization
				int count_row4_tMap_2 = 0;

				int count_row5_tMap_2 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct>) globalMap
						.get("tHash_Lookup_row5"));

				row5Struct row5HashKey = new row5Struct();
				row5Struct row5Default = new row5Struct();
				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_active_deactivate_tMap_2 = 0;

				active_deactivateStruct active_deactivate_tmp = new active_deactivateStruct();
				int count_update_tMap_2 = 0;

				updateStruct update_tmp = new updateStruct();
				int count_insert_tMap_2 = 0;

				insertStruct insert_tmp = new insertStruct();
				// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tAddCRCRow_1 begin ] start
				 */

				ok_Hash.put("tAddCRCRow_1", false);
				start_Hash.put("tAddCRCRow_1", System.currentTimeMillis());

				currentComponent = "tAddCRCRow_1";

				int tos_count_tAddCRCRow_1 = 0;

				int nb_line_tAddCRCRow_1 = 0;

				/**
				 * [tAddCRCRow_1 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_3 = new StringBuilder();
				log4jParamters_tMap_3.append("Parameters:");
				log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + log4jParamters_tMap_3);

				// ###############################
				// # Lookup's keys initialization
				int count_row2_tMap_3 = 0;

				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_out2_tMap_3 = 0;

				out2Struct out2_tmp = new out2Struct();
				// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tFilterRow_4 begin ] start
				 */

				ok_Hash.put("tFilterRow_4", false);
				start_Hash.put("tFilterRow_4", System.currentTimeMillis());

				currentComponent = "tFilterRow_4";

				int tos_count_tFilterRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tFilterRow_4 - " + "Start to work.");
				StringBuilder log4jParamters_tFilterRow_4 = new StringBuilder();
				log4jParamters_tFilterRow_4.append("Parameters:");
				log4jParamters_tFilterRow_4.append("LOGICAL_OP" + " = " + "&&");
				log4jParamters_tFilterRow_4.append(" | ");
				log4jParamters_tFilterRow_4.append("CONDITIONS" + " = "
						+ "[{OPERATOR=" + ("!=") + ", RVALUE=" + ("null")
						+ ", INPUT_COLUMN=" + ("db_type") + ", FUNCTION="
						+ ("") + "}, {OPERATOR=" + ("!=") + ", RVALUE="
						+ ("null") + ", INPUT_COLUMN=" + ("db_nme")
						+ ", FUNCTION=" + ("") + "}, {OPERATOR=" + ("!=")
						+ ", RVALUE=" + ("null") + ", INPUT_COLUMN="
						+ ("db_schema") + ", FUNCTION=" + ("")
						+ "}, {OPERATOR=" + ("!=") + ", RVALUE=" + ("null")
						+ ", INPUT_COLUMN=" + ("host") + ", FUNCTION=" + ("")
						+ "}, {OPERATOR=" + ("!=") + ", RVALUE=" + ("null")
						+ ", INPUT_COLUMN=" + ("port") + ", FUNCTION=" + ("")
						+ "}, {OPERATOR=" + ("!=") + ", RVALUE=" + ("null")
						+ ", INPUT_COLUMN=" + ("db_user") + ", FUNCTION="
						+ ("") + "}, {OPERATOR=" + ("!=") + ", RVALUE="
						+ ("null") + ", INPUT_COLUMN=" + ("db_pass")
						+ ", FUNCTION=" + ("") + "}, {OPERATOR=" + ("!=")
						+ ", RVALUE=" + ("null") + ", INPUT_COLUMN="
						+ ("active") + ", FUNCTION=" + ("") + "}]");
				log4jParamters_tFilterRow_4.append(" | ");
				log4jParamters_tFilterRow_4.append("USE_ADVANCED" + " = "
						+ "false");
				log4jParamters_tFilterRow_4.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFilterRow_4 - " + log4jParamters_tFilterRow_4);
				int nb_line_tFilterRow_4 = 0;
				int nb_line_ok_tFilterRow_4 = 0;
				int nb_line_reject_tFilterRow_4 = 0;

				class Operator_tFilterRow_4 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_4(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_4 begin ] stop
				 */

				/**
				 * [tFileInputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_1", false);
				start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileInputExcel_1";

				int tos_count_tFileInputExcel_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
				log4jParamters_tFileInputExcel_1.append("Parameters:");
				log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = "
						+ "true");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FILENAME" + " = "
						+ "context.file_schema_connection_details");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = "
						+ "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("SHEETLIST" + " = "
						+ "[{USE_REGEX=" + ("false") + ", SHEETNAME="
						+ ("\"Sheet1\"") + "}]");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = "
						+ "1");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = "
						+ "");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = "
						+ "true");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = "
						+ "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("TRIMSELECT" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_type") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("db_nme") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_schema")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("host") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("port") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_user")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_pass") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("active") + "}]");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("CONVERTDATETOSTRING"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("GENERATION_MODE"
						+ " = " + "USER_MODE");
				log4jParamters_tFileInputExcel_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - "
							+ log4jParamters_tFileInputExcel_1);

				class RegexUtil_tFileInputExcel_1 {

					public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(
							org.apache.poi.xssf.usermodel.XSSFWorkbook workbook,
							String oneSheetName, boolean useRegex) {

						java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

						if (useRegex) {// this part process the regex issue

							java.util.regex.Pattern pattern = java.util.regex.Pattern
									.compile(oneSheetName);
							for (org.apache.poi.xssf.usermodel.XSSFSheet sheet : workbook) {
								String sheetName = sheet.getSheetName();
								java.util.regex.Matcher matcher = pattern
										.matcher(sheetName);
								if (matcher.matches()) {
									if (sheet != null) {
										list.add(sheet);
									}
								}
							}

						} else {
							org.apache.poi.xssf.usermodel.XSSFSheet sheet = workbook
									.getSheet(oneSheetName);
							if (sheet != null) {
								list.add(sheet);
							}

						}

						return list;
					}

					public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(
							org.apache.poi.xssf.usermodel.XSSFWorkbook workbook,
							int index, boolean useRegex) {
						java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
						org.apache.poi.xssf.usermodel.XSSFSheet sheet = workbook
								.getSheetAt(index);
						if (sheet != null) {
							list.add(sheet);
						}
						return list;
					}

				}
				RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();

				Object source_tFileInputExcel_1 = context.file_schema_connection_details;
				org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_1 = null;

				if (source_tFileInputExcel_1 instanceof String) {
					workbook_tFileInputExcel_1 = new org.apache.poi.xssf.usermodel.XSSFWorkbook(
							(String) source_tFileInputExcel_1);
				} else if (source_tFileInputExcel_1 instanceof java.io.InputStream) {
					workbook_tFileInputExcel_1 = new org.apache.poi.xssf.usermodel.XSSFWorkbook(
							(java.io.InputStream) source_tFileInputExcel_1);
				} else {
					workbook_tFileInputExcel_1 = null;
					throw new java.lang.Exception(
							"The data source should be specified as Inputstream or File Path!");
				}
				try {

					java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
					sheetList_tFileInputExcel_1
							.addAll(regexUtil_tFileInputExcel_1
									.getSheets(workbook_tFileInputExcel_1,
											"Sheet1", false));
					if (sheetList_tFileInputExcel_1.size() <= 0) {
						throw new RuntimeException("Special sheets not exist!");
					}

					java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
					for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
						if (sheet_FilterNull_tFileInputExcel_1 != null
								&& sheetList_FilterNull_tFileInputExcel_1
										.iterator() != null
								&& sheet_FilterNull_tFileInputExcel_1
										.iterator().hasNext()) {
							sheetList_FilterNull_tFileInputExcel_1
									.add(sheet_FilterNull_tFileInputExcel_1);
						}
					}
					sheetList_tFileInputExcel_1 = sheetList_FilterNull_tFileInputExcel_1;
					if (sheetList_tFileInputExcel_1.size() > 0) {
						int nb_line_tFileInputExcel_1 = 0;

						int begin_line_tFileInputExcel_1 = 1;

						int footer_input_tFileInputExcel_1 = 0;

						int end_line_tFileInputExcel_1 = 0;
						for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
							end_line_tFileInputExcel_1 += (sheet_tFileInputExcel_1
									.getLastRowNum() + 1);
						}
						end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
						int limit_tFileInputExcel_1 = -1;
						int start_column_tFileInputExcel_1 = 1 - 1;
						int end_column_tFileInputExcel_1 = -1;

						org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_1 = null;
						org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
								.get(0);
						int rowCount_tFileInputExcel_1 = 0;
						int sheetIndex_tFileInputExcel_1 = 0;
						int currentRows_tFileInputExcel_1 = (sheetList_tFileInputExcel_1
								.get(0).getLastRowNum() + 1);

						// for the number format
						java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat(
								"#.####################################");
						char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1
								.getDecimalFormatSymbols()
								.getDecimalSeparator();
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");

						for (int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++) {

							int emptyColumnCount_tFileInputExcel_1 = 0;

							if (limit_tFileInputExcel_1 != -1
									&& nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
								break;
							}

							while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1
									+ currentRows_tFileInputExcel_1) {
								rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
								sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
										.get(++sheetIndex_tFileInputExcel_1);
								currentRows_tFileInputExcel_1 = (sheet_tFileInputExcel_1
										.getLastRowNum() + 1);
							}
							globalMap.put("tFileInputExcel_1_CURRENT_SHEET",
									sheet_tFileInputExcel_1.getSheetName());
							if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
								row_tFileInputExcel_1 = sheet_tFileInputExcel_1
										.getRow(i_tFileInputExcel_1
												- rowCount_tFileInputExcel_1);
							}
							row1 = null;
							int tempRowLength_tFileInputExcel_1 = 8;

							int columnIndex_tFileInputExcel_1 = 0;

							String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
							int excel_end_column_tFileInputExcel_1;
							if (row_tFileInputExcel_1 == null) {
								excel_end_column_tFileInputExcel_1 = 0;
							} else {
								excel_end_column_tFileInputExcel_1 = row_tFileInputExcel_1
										.getLastCellNum();
							}
							int actual_end_column_tFileInputExcel_1;
							if (end_column_tFileInputExcel_1 == -1) {
								actual_end_column_tFileInputExcel_1 = excel_end_column_tFileInputExcel_1;
							} else {
								actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 > excel_end_column_tFileInputExcel_1 ? excel_end_column_tFileInputExcel_1
										: end_column_tFileInputExcel_1;
							}
							org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_1 = null;
							for (int i = 0; i < tempRowLength_tFileInputExcel_1; i++) {
								if (i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1) {
									org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1
											.getCell(i
													+ start_column_tFileInputExcel_1);
									if (cell_tFileInputExcel_1 != null) {
										switch (cell_tFileInputExcel_1
												.getCellType()) {
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
											temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
													.getRichStringCellValue()
													.getString();
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
											if (org.apache.poi.ss.usermodel.DateUtil
													.isCellDateFormatted(cell_tFileInputExcel_1)) {
												temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
														.getDateCellValue()
														.toString();
											} else {
												temp_row_tFileInputExcel_1[i] = df_tFileInputExcel_1
														.format(cell_tFileInputExcel_1
																.getNumericCellValue());
											}
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BOOLEAN:
											temp_row_tFileInputExcel_1[i] = String
													.valueOf(cell_tFileInputExcel_1
															.getBooleanCellValue());
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_FORMULA:
											switch (cell_tFileInputExcel_1
													.getCachedFormulaResultType()) {
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
												temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
														.getRichStringCellValue()
														.getString();
												break;
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
												if (org.apache.poi.ss.usermodel.DateUtil
														.isCellDateFormatted(cell_tFileInputExcel_1)) {
													temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
															.getDateCellValue()
															.toString();
												} else {
													ne_tFileInputExcel_1 = new org.apache.poi.ss.formula.eval.NumberEval(
															cell_tFileInputExcel_1
																	.getNumericCellValue());
													temp_row_tFileInputExcel_1[i] = ne_tFileInputExcel_1
															.getStringValue();
												}
												break;
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BOOLEAN:
												temp_row_tFileInputExcel_1[i] = String
														.valueOf(cell_tFileInputExcel_1
																.getBooleanCellValue());
												break;
											default:
												temp_row_tFileInputExcel_1[i] = "";
											}
											break;
										default:
											temp_row_tFileInputExcel_1[i] = "";
										}
									} else {
										temp_row_tFileInputExcel_1[i] = "";
									}

								} else {
									temp_row_tFileInputExcel_1[i] = "";
								}
							}
							boolean whetherReject_tFileInputExcel_1 = false;
							row1 = new row1Struct();
							int curColNum_tFileInputExcel_1 = -1;
							String curColName_tFileInputExcel_1 = "";
							try {
								columnIndex_tFileInputExcel_1 = 0;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "db_type";

									row1.db_type = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.db_type = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 1;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "db_nme";

									row1.db_nme = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.db_nme = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 2;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "db_schema";

									row1.db_schema = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.db_schema = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 3;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "host";

									row1.host = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.host = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 4;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "port";

									row1.port = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.port = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 5;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "db_user";

									row1.db_user = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.db_user = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 6;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "db_pass";

									row1.db_pass = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row1.db_pass = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 7;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "active";

									row1.active = ParserUtils
											.parseTo_Integer(ParserUtils
													.parseTo_Number(
															temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1],
															null,
															'.' == decimalChar_tFileInputExcel_1 ? null
																	: decimalChar_tFileInputExcel_1));
								} else {
									row1.active = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								nb_line_tFileInputExcel_1++;

								log.debug("tFileInputExcel_1 - Retrieving the record "
										+ (nb_line_tFileInputExcel_1) + ".");

							} catch (java.lang.Exception e) {
								whetherReject_tFileInputExcel_1 = true;
								throw (e);
							}

							/**
							 * [tFileInputExcel_1 begin ] stop
							 */

							/**
							 * [tFileInputExcel_1 main ] start
							 */

							currentComponent = "tFileInputExcel_1";

							tos_count_tFileInputExcel_1++;

							/**
							 * [tFileInputExcel_1 main ] stop
							 */
							// Start of branch "row1"
							if (row1 != null) {

								/**
								 * [tFilterRow_4 main ] start
								 */

								currentComponent = "tFilterRow_4";

								if (log.isTraceEnabled()) {
									log.trace("row1 - "
											+ (row1 == null ? "" : row1
													.toLogString()));
								}

								row2 = null;
								Operator_tFilterRow_4 ope_tFilterRow_4 = new Operator_tFilterRow_4(
										"&&");
								ope_tFilterRow_4.matches(
										(row1.db_type != null),
										"db_type!=null failed");
								ope_tFilterRow_4.matches((row1.db_nme != null),
										"db_nme!=null failed");
								ope_tFilterRow_4.matches(
										(row1.db_schema != null),
										"db_schema!=null failed");
								ope_tFilterRow_4.matches((row1.host != null),
										"host!=null failed");
								ope_tFilterRow_4.matches((row1.port != null),
										"port!=null failed");
								ope_tFilterRow_4.matches(
										(row1.db_user != null),
										"db_user!=null failed");
								ope_tFilterRow_4.matches(
										(row1.db_pass != null),
										"db_pass!=null failed");
								ope_tFilterRow_4.matches((row1.active != null),
										"active!=null failed");

								if (ope_tFilterRow_4.getMatchFlag()) {
									if (row2 == null) {
										row2 = new row2Struct();
									}
									row2.db_type = row1.db_type;
									row2.db_nme = row1.db_nme;
									row2.db_schema = row1.db_schema;
									row2.host = row1.host;
									row2.port = row1.port;
									row2.db_user = row1.db_user;
									row2.db_pass = row1.db_pass;
									row2.active = row1.active;
									log.debug("tFilterRow_4 - Process the record "
											+ (nb_line_tFilterRow_4 + 1) + ".");

									nb_line_ok_tFilterRow_4++;
								} else {
									nb_line_reject_tFilterRow_4++;
								}

								nb_line_tFilterRow_4++;

								tos_count_tFilterRow_4++;

								/**
								 * [tFilterRow_4 main ] stop
								 */
								// Start of branch "row2"
								if (row2 != null) {

									/**
									 * [tMap_3 main ] start
									 */

									currentComponent = "tMap_3";

									if (log.isTraceEnabled()) {
										log.trace("row2 - "
												+ (row2 == null ? "" : row2
														.toLogString()));
									}

									boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

									// ###############################
									// # Input tables (lookups)
									boolean rejectedInnerJoin_tMap_3 = false;
									boolean mainRowRejected_tMap_3 = false;

									// ###############################
									{ // start of Var scope

										// ###############################
										// # Vars tables

										Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
										// ###############################
										// # Output tables

										out2 = null;

										// # Output table : 'out2'
										count_out2_tMap_3++;

										out2_tmp.db_type = StringHandling
												.UPCASE(row2.db_type);
										out2_tmp.db_nme = StringHandling
												.UPCASE(row2.db_nme);
										out2_tmp.db_schema = StringHandling
												.UPCASE(row2.db_schema);
										out2_tmp.host = StringHandling
												.UPCASE(row2.host);
										out2_tmp.port = StringHandling
												.UPCASE(row2.port);
										out2_tmp.db_user = StringHandling
												.UPCASE(row2.db_user);
										out2_tmp.db_pass = row2.db_pass;
										out2_tmp.active = row2.active;
										out2 = out2_tmp;
										log.debug("tMap_3 - Outputting the record "
												+ count_out2_tMap_3
												+ " of the output table 'out2'.");

										// ###############################

									} // end of Var scope

									rejectedInnerJoin_tMap_3 = false;

									tos_count_tMap_3++;

									/**
									 * [tMap_3 main ] stop
									 */
									// Start of branch "out2"
									if (out2 != null) {

										/**
										 * [tAddCRCRow_1 main ] start
										 */

										currentComponent = "tAddCRCRow_1";

										if (log.isTraceEnabled()) {
											log.trace("out2 - "
													+ (out2 == null ? "" : out2
															.toLogString()));
										}

										Long crcComputedValuetAddCRCRow_1 = null;
										StringBuilder strBuffer_tAddCRCRow_1 = new StringBuilder();
										strBuffer_tAddCRCRow_1.append(

										String.valueOf(out2.db_type)

										);

										strBuffer_tAddCRCRow_1.append(

										String.valueOf(out2.db_nme)

										);

										strBuffer_tAddCRCRow_1.append(

										String.valueOf(out2.db_schema)

										);

										strBuffer_tAddCRCRow_1.append(

										String.valueOf(out2.host)

										);

										strBuffer_tAddCRCRow_1.append(

										String.valueOf(out2.port)

										);

										java.util.zip.CRC32 crc32tAddCRCRow_1 = new java.util.zip.CRC32();
										crc32tAddCRCRow_1
												.update(strBuffer_tAddCRCRow_1
														.toString().getBytes());
										crcComputedValuetAddCRCRow_1 = new Long(
												crc32tAddCRCRow_1.getValue());
										row4.db_type = out2.db_type;
										row4.db_nme = out2.db_nme;
										row4.db_schema = out2.db_schema;
										row4.host = out2.host;
										row4.port = out2.port;
										row4.db_user = out2.db_user;
										row4.db_pass = out2.db_pass;
										row4.active = out2.active;
										row4.CRC = crcComputedValuetAddCRCRow_1;
										nb_line_tAddCRCRow_1++;

										tos_count_tAddCRCRow_1++;

										/**
										 * [tAddCRCRow_1 main ] stop
										 */

										/**
										 * [tMap_2 main ] start
										 */

										currentComponent = "tMap_2";

										if (log.isTraceEnabled()) {
											log.trace("row4 - "
													+ (row4 == null ? "" : row4
															.toLogString()));
										}

										boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

										// ###############################
										// # Input tables (lookups)
										boolean rejectedInnerJoin_tMap_2 = false;
										boolean mainRowRejected_tMap_2 = false;

										// /////////////////////////////////////////////
										// Starting Lookup Table "row5"
										// /////////////////////////////////////////////

										boolean forceLooprow5 = false;

										row5Struct row5ObjectFromLookup = null;

										if (!rejectedInnerJoin_tMap_2) { // G_TM_M_020

											hasCasePrimitiveKeyWithNull_tMap_2 = false;

											row5HashKey.CRC = row4.CRC;

											row5HashKey.hashCodeDirty = true;

											tHash_Lookup_row5
													.lookup(row5HashKey);

											if (!tHash_Lookup_row5.hasNext()) { // G_TM_M_090

												rejectedInnerJoin_tMap_2 = true;

											} // G_TM_M_090

										} // G_TM_M_020

										if (tHash_Lookup_row5 != null
												&& tHash_Lookup_row5
														.getCount(row5HashKey) > 1) { // G
																						// 071

											// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row5' and it contains more one result from keys :  row5.CRC = '"
											// + row5HashKey.CRC + "'");
										} // G 071

										row5Struct row5 = null;

										row5Struct fromLookup_row5 = null;
										row5 = row5Default;

										if (tHash_Lookup_row5 != null
												&& tHash_Lookup_row5.hasNext()) { // G
																					// 099

											fromLookup_row5 = tHash_Lookup_row5
													.next();

										} // G 099

										if (fromLookup_row5 != null) {
											row5 = fromLookup_row5;
										}

										// ###############################
										{ // start of Var scope

											// ###############################
											// # Vars tables

											Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
											// ###############################
											// # Output tables

											active_deactivate = null;
											update = null;
											insert = null;

											if (!rejectedInnerJoin_tMap_2) {

												// # Output table :
												// 'active_deactivate'
												// # Filter conditions
												if (

												!row4.active
														.equals(row5.active)

												) {
													count_active_deactivate_tMap_2++;

													active_deactivate_tmp.db_type = row4.db_type;
													active_deactivate_tmp.db_nme = row4.db_nme;
													active_deactivate_tmp.db_schema = row4.db_schema;
													active_deactivate_tmp.host = row4.host;
													active_deactivate_tmp.port = row4.port;
													active_deactivate_tmp.db_user = row4.db_user;
													active_deactivate_tmp.db_pass = row4.db_pass;
													active_deactivate_tmp.active = row4.active;
													active_deactivate = active_deactivate_tmp;
													log.debug("tMap_2 - Outputting the record "
															+ count_active_deactivate_tMap_2
															+ " of the output table 'active_deactivate'.");

												} // closing filter/reject

												// # Output table : 'update'
												// # Filter conditions
												if (

												row4.active == 1
														&& (!row4.db_user
																.equals(row5.db_user) || !row4.db_pass
																.equals(row5.db_pass))

												) {
													count_update_tMap_2++;

													update_tmp.db_type = row4.db_type;
													update_tmp.db_nme = row4.db_nme;
													update_tmp.db_schema = row4.db_schema;
													update_tmp.host = row4.host;
													update_tmp.port = row4.port;
													update_tmp.db_user = row4.db_user;
													update_tmp.db_pass = row4.db_pass;
													update_tmp.active = row4.active;
													update = update_tmp;
													log.debug("tMap_2 - Outputting the record "
															+ count_update_tMap_2
															+ " of the output table 'update'.");

												} // closing filter/reject
											} // closing inner join bracket (1)
												// ###### START REJECTS #####

											// # Output reject table : 'insert'
											// # Filter conditions
											if (rejectedInnerJoin_tMap_2 && (

											row4.active == 1

											)) {
												count_insert_tMap_2++;

												insert_tmp.db_type = row4.db_type;
												insert_tmp.db_nme = row4.db_nme;
												insert_tmp.db_schema = row4.db_schema;
												insert_tmp.host = row4.host;
												insert_tmp.port = row4.port;
												insert_tmp.db_user = row4.db_user;
												insert_tmp.db_pass = row4.db_pass;
												insert_tmp.active = row4.active;
												insert = insert_tmp;
												log.debug("tMap_2 - Outputting the record "
														+ count_insert_tMap_2
														+ " of the output table 'insert'.");

											} // closing filter/reject
												// ###############################

										} // end of Var scope

										rejectedInnerJoin_tMap_2 = false;

										tos_count_tMap_2++;

										/**
										 * [tMap_2 main ] stop
										 */
										// Start of branch "active_deactivate"
										if (active_deactivate != null) {

											/**
											 * [tMSSqlOutput_3 main ] start
											 */

											currentComponent = "tMSSqlOutput_3";

											if (log.isTraceEnabled()) {
												log.trace("active_deactivate - "
														+ (active_deactivate == null ? ""
																: active_deactivate
																		.toLogString()));
											}

											whetherReject_tMSSqlOutput_3 = false;
											if (active_deactivate.db_user == null) {
												pstmt_tMSSqlOutput_3.setNull(1,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																1,
																active_deactivate.db_user);
											}

											if (active_deactivate.db_pass == null) {
												pstmt_tMSSqlOutput_3.setNull(2,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																2,
																active_deactivate.db_pass);
											}

											if (active_deactivate.active == null) {
												pstmt_tMSSqlOutput_3.setNull(3,
														java.sql.Types.INTEGER);
											} else {
												pstmt_tMSSqlOutput_3
														.setInt(3,
																active_deactivate.active);
											}

											if (active_deactivate.db_type == null) {
												pstmt_tMSSqlOutput_3
														.setNull(
																4 + count_tMSSqlOutput_3,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																4 + count_tMSSqlOutput_3,
																active_deactivate.db_type);
											}

											if (active_deactivate.db_nme == null) {
												pstmt_tMSSqlOutput_3
														.setNull(
																5 + count_tMSSqlOutput_3,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																5 + count_tMSSqlOutput_3,
																active_deactivate.db_nme);
											}

											if (active_deactivate.db_schema == null) {
												pstmt_tMSSqlOutput_3
														.setNull(
																6 + count_tMSSqlOutput_3,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																6 + count_tMSSqlOutput_3,
																active_deactivate.db_schema);
											}

											if (active_deactivate.host == null) {
												pstmt_tMSSqlOutput_3
														.setNull(
																7 + count_tMSSqlOutput_3,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																7 + count_tMSSqlOutput_3,
																active_deactivate.host);
											}

											if (active_deactivate.port == null) {
												pstmt_tMSSqlOutput_3
														.setNull(
																8 + count_tMSSqlOutput_3,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_3
														.setString(
																8 + count_tMSSqlOutput_3,
																active_deactivate.port);
											}

											pstmt_tMSSqlOutput_3.addBatch();
											nb_line_tMSSqlOutput_3++;

											if (log.isDebugEnabled())
												log.debug("tMSSqlOutput_3 - "
														+ "Adding the record "
														+ nb_line_tMSSqlOutput_3
														+ " to the " + "UPDATE"
														+ " batch.");
											batchSizeCounter_tMSSqlOutput_3++;

											if ((batchSize_tMSSqlOutput_3 > 0)
													&& (batchSize_tMSSqlOutput_3 <= batchSizeCounter_tMSSqlOutput_3)) {
												try {
													int countSum_tMSSqlOutput_3 = 0;

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_3 - "
																+ "Executing the "
																+ "UPDATE"
																+ " batch.");
													for (int countEach_tMSSqlOutput_3 : pstmt_tMSSqlOutput_3
															.executeBatch()) {
														if (countEach_tMSSqlOutput_3 == -2
																|| countEach_tMSSqlOutput_3 == -3) {
															break;
														}
														countSum_tMSSqlOutput_3 += countEach_tMSSqlOutput_3;
													}

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_3 - "
																+ "The "
																+ "UPDATE"
																+ " batch execution has succeeded.");

													updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

													batchSizeCounter_tMSSqlOutput_3 = 0;
												} catch (java.sql.BatchUpdateException e) {

													int countSum_tMSSqlOutput_3 = 0;
													for (int countEach_tMSSqlOutput_3 : e
															.getUpdateCounts()) {
														countSum_tMSSqlOutput_3 += (countEach_tMSSqlOutput_3 < 0 ? 0
																: countEach_tMSSqlOutput_3);
													}

													updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

													log.error("tMSSqlOutput_3 - "
															+ e.getMessage());
													System.err.println(e
															.getMessage());

												}
											}

											commitCounter_tMSSqlOutput_3++;
											if (commitEvery_tMSSqlOutput_3 <= commitCounter_tMSSqlOutput_3) {
												if ((batchSize_tMSSqlOutput_3 > 0)
														&& (batchSizeCounter_tMSSqlOutput_3 > 0)) {
													try {
														int countSum_tMSSqlOutput_3 = 0;

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_3 - "
																	+ "Executing the "
																	+ "UPDATE"
																	+ " batch.");
														for (int countEach_tMSSqlOutput_3 : pstmt_tMSSqlOutput_3
																.executeBatch()) {
															if (countEach_tMSSqlOutput_3 == -2
																	|| countEach_tMSSqlOutput_3 == -3) {
																break;
															}
															countSum_tMSSqlOutput_3 += countEach_tMSSqlOutput_3;
														}

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_3 - "
																	+ "The "
																	+ "UPDATE"
																	+ " batch execution has succeeded.");

														updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

														batchSizeCounter_tMSSqlOutput_3 = 0;
													} catch (java.sql.BatchUpdateException e) {

														int countSum_tMSSqlOutput_3 = 0;
														for (int countEach_tMSSqlOutput_3 : e
																.getUpdateCounts()) {
															countSum_tMSSqlOutput_3 += (countEach_tMSSqlOutput_3 < 0 ? 0
																	: countEach_tMSSqlOutput_3);
														}

														updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

														log.error("tMSSqlOutput_3 - "
																+ e.getMessage());
														System.err.println(e
																.getMessage());

													}
												}

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_3 - "
															+ "Connection starting to commit "
															+ commitCounter_tMSSqlOutput_3
															+ " record(s).");
												conn_tMSSqlOutput_3.commit();

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_3 - "
															+ "Connection commit has succeeded.");
												commitCounter_tMSSqlOutput_3 = 0;
											}

											tos_count_tMSSqlOutput_3++;

											/**
											 * [tMSSqlOutput_3 main ] stop
											 */

										} // End of branch "active_deactivate"

										// Start of branch "update"
										if (update != null) {

											/**
											 * [tMSSqlOutput_2 main ] start
											 */

											currentComponent = "tMSSqlOutput_2";

											if (log.isTraceEnabled()) {
												log.trace("update - "
														+ (update == null ? ""
																: update.toLogString()));
											}

											whetherReject_tMSSqlOutput_2 = false;
											if (update.db_user == null) {
												pstmt_tMSSqlOutput_2.setNull(1,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2.setString(
														1, update.db_user);
											}

											if (update.db_pass == null) {
												pstmt_tMSSqlOutput_2.setNull(2,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2.setString(
														2, update.db_pass);
											}

											if (update.active == null) {
												pstmt_tMSSqlOutput_2.setNull(3,
														java.sql.Types.INTEGER);
											} else {
												pstmt_tMSSqlOutput_2.setInt(3,
														update.active);
											}

											if (update.db_type == null) {
												pstmt_tMSSqlOutput_2
														.setNull(
																4 + count_tMSSqlOutput_2,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2
														.setString(
																4 + count_tMSSqlOutput_2,
																update.db_type);
											}

											if (update.db_nme == null) {
												pstmt_tMSSqlOutput_2
														.setNull(
																5 + count_tMSSqlOutput_2,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2
														.setString(
																5 + count_tMSSqlOutput_2,
																update.db_nme);
											}

											if (update.db_schema == null) {
												pstmt_tMSSqlOutput_2
														.setNull(
																6 + count_tMSSqlOutput_2,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2
														.setString(
																6 + count_tMSSqlOutput_2,
																update.db_schema);
											}

											if (update.host == null) {
												pstmt_tMSSqlOutput_2
														.setNull(
																7 + count_tMSSqlOutput_2,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2
														.setString(
																7 + count_tMSSqlOutput_2,
																update.host);
											}

											if (update.port == null) {
												pstmt_tMSSqlOutput_2
														.setNull(
																8 + count_tMSSqlOutput_2,
																java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_2
														.setString(
																8 + count_tMSSqlOutput_2,
																update.port);
											}

											pstmt_tMSSqlOutput_2.addBatch();
											nb_line_tMSSqlOutput_2++;

											if (log.isDebugEnabled())
												log.debug("tMSSqlOutput_2 - "
														+ "Adding the record "
														+ nb_line_tMSSqlOutput_2
														+ " to the " + "UPDATE"
														+ " batch.");
											batchSizeCounter_tMSSqlOutput_2++;

											if ((batchSize_tMSSqlOutput_2 > 0)
													&& (batchSize_tMSSqlOutput_2 <= batchSizeCounter_tMSSqlOutput_2)) {
												try {
													int countSum_tMSSqlOutput_2 = 0;

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_2 - "
																+ "Executing the "
																+ "UPDATE"
																+ " batch.");
													for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
															.executeBatch()) {
														if (countEach_tMSSqlOutput_2 == -2
																|| countEach_tMSSqlOutput_2 == -3) {
															break;
														}
														countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
													}

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_2 - "
																+ "The "
																+ "UPDATE"
																+ " batch execution has succeeded.");

													updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

													batchSizeCounter_tMSSqlOutput_2 = 0;
												} catch (java.sql.BatchUpdateException e) {

													int countSum_tMSSqlOutput_2 = 0;
													for (int countEach_tMSSqlOutput_2 : e
															.getUpdateCounts()) {
														countSum_tMSSqlOutput_2 += (countEach_tMSSqlOutput_2 < 0 ? 0
																: countEach_tMSSqlOutput_2);
													}

													updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

													log.error("tMSSqlOutput_2 - "
															+ e.getMessage());
													System.err.println(e
															.getMessage());

												}
											}

											commitCounter_tMSSqlOutput_2++;
											if (commitEvery_tMSSqlOutput_2 <= commitCounter_tMSSqlOutput_2) {
												if ((batchSize_tMSSqlOutput_2 > 0)
														&& (batchSizeCounter_tMSSqlOutput_2 > 0)) {
													try {
														int countSum_tMSSqlOutput_2 = 0;

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_2 - "
																	+ "Executing the "
																	+ "UPDATE"
																	+ " batch.");
														for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
																.executeBatch()) {
															if (countEach_tMSSqlOutput_2 == -2
																	|| countEach_tMSSqlOutput_2 == -3) {
																break;
															}
															countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
														}

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_2 - "
																	+ "The "
																	+ "UPDATE"
																	+ " batch execution has succeeded.");

														updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

														batchSizeCounter_tMSSqlOutput_2 = 0;
													} catch (java.sql.BatchUpdateException e) {

														int countSum_tMSSqlOutput_2 = 0;
														for (int countEach_tMSSqlOutput_2 : e
																.getUpdateCounts()) {
															countSum_tMSSqlOutput_2 += (countEach_tMSSqlOutput_2 < 0 ? 0
																	: countEach_tMSSqlOutput_2);
														}

														updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

														log.error("tMSSqlOutput_2 - "
																+ e.getMessage());
														System.err.println(e
																.getMessage());

													}
												}

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_2 - "
															+ "Connection starting to commit "
															+ commitCounter_tMSSqlOutput_2
															+ " record(s).");
												conn_tMSSqlOutput_2.commit();

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_2 - "
															+ "Connection commit has succeeded.");
												commitCounter_tMSSqlOutput_2 = 0;
											}

											tos_count_tMSSqlOutput_2++;

											/**
											 * [tMSSqlOutput_2 main ] stop
											 */

										} // End of branch "update"

										// Start of branch "insert"
										if (insert != null) {

											/**
											 * [tMSSqlOutput_1 main ] start
											 */

											currentComponent = "tMSSqlOutput_1";

											if (log.isTraceEnabled()) {
												log.trace("insert - "
														+ (insert == null ? ""
																: insert.toLogString()));
											}

											whetherReject_tMSSqlOutput_1 = false;
											if (insert.db_type == null) {
												pstmt_tMSSqlOutput_1.setNull(1,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														1, insert.db_type);
											}

											if (insert.db_nme == null) {
												pstmt_tMSSqlOutput_1.setNull(2,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														2, insert.db_nme);
											}

											if (insert.db_schema == null) {
												pstmt_tMSSqlOutput_1.setNull(3,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														3, insert.db_schema);
											}

											if (insert.host == null) {
												pstmt_tMSSqlOutput_1.setNull(4,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														4, insert.host);
											}

											if (insert.port == null) {
												pstmt_tMSSqlOutput_1.setNull(5,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														5, insert.port);
											}

											if (insert.db_user == null) {
												pstmt_tMSSqlOutput_1.setNull(6,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														6, insert.db_user);
											}

											if (insert.db_pass == null) {
												pstmt_tMSSqlOutput_1.setNull(7,
														java.sql.Types.VARCHAR);
											} else {
												pstmt_tMSSqlOutput_1.setString(
														7, insert.db_pass);
											}

											if (insert.active == null) {
												pstmt_tMSSqlOutput_1.setNull(8,
														java.sql.Types.INTEGER);
											} else {
												pstmt_tMSSqlOutput_1.setInt(8,
														insert.active);
											}

											pstmt_tMSSqlOutput_1.addBatch();
											nb_line_tMSSqlOutput_1++;

											if (log.isDebugEnabled())
												log.debug("tMSSqlOutput_1 - "
														+ "Adding the record "
														+ nb_line_tMSSqlOutput_1
														+ " to the " + "INSERT"
														+ " batch.");
											batchSizeCounter_tMSSqlOutput_1++;

											if ((batchSize_tMSSqlOutput_1 > 0)
													&& (batchSize_tMSSqlOutput_1 <= batchSizeCounter_tMSSqlOutput_1)) {
												try {
													int countSum_tMSSqlOutput_1 = 0;

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_1 - "
																+ "Executing the "
																+ "INSERT"
																+ " batch.");
													for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
															.executeBatch()) {
														if (countEach_tMSSqlOutput_1 == -2
																|| countEach_tMSSqlOutput_1 == -3) {
															break;
														}
														countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
													}

													if (log.isDebugEnabled())
														log.debug("tMSSqlOutput_1 - "
																+ "The "
																+ "INSERT"
																+ " batch execution has succeeded.");

													insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

													batchSizeCounter_tMSSqlOutput_1 = 0;
												} catch (java.sql.BatchUpdateException e) {

													int countSum_tMSSqlOutput_1 = 0;
													for (int countEach_tMSSqlOutput_1 : e
															.getUpdateCounts()) {
														countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
																: countEach_tMSSqlOutput_1);
													}

													insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

													log.error("tMSSqlOutput_1 - "
															+ e.getMessage());
													System.err.println(e
															.getMessage());

												}
											}

											commitCounter_tMSSqlOutput_1++;
											if (commitEvery_tMSSqlOutput_1 <= commitCounter_tMSSqlOutput_1) {
												if ((batchSize_tMSSqlOutput_1 > 0)
														&& (batchSizeCounter_tMSSqlOutput_1 > 0)) {
													try {
														int countSum_tMSSqlOutput_1 = 0;

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_1 - "
																	+ "Executing the "
																	+ "INSERT"
																	+ " batch.");
														for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
																.executeBatch()) {
															if (countEach_tMSSqlOutput_1 == -2
																	|| countEach_tMSSqlOutput_1 == -3) {
																break;
															}
															countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
														}

														if (log.isDebugEnabled())
															log.debug("tMSSqlOutput_1 - "
																	+ "The "
																	+ "INSERT"
																	+ " batch execution has succeeded.");

														insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

														batchSizeCounter_tMSSqlOutput_1 = 0;
													} catch (java.sql.BatchUpdateException e) {

														int countSum_tMSSqlOutput_1 = 0;
														for (int countEach_tMSSqlOutput_1 : e
																.getUpdateCounts()) {
															countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
																	: countEach_tMSSqlOutput_1);
														}

														insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

														log.error("tMSSqlOutput_1 - "
																+ e.getMessage());
														System.err.println(e
																.getMessage());

													}
												}

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_1 - "
															+ "Connection starting to commit "
															+ commitCounter_tMSSqlOutput_1
															+ " record(s).");
												conn_tMSSqlOutput_1.commit();

												if (log.isDebugEnabled())
													log.debug("tMSSqlOutput_1 - "
															+ "Connection commit has succeeded.");
												commitCounter_tMSSqlOutput_1 = 0;
											}

											tos_count_tMSSqlOutput_1++;

											/**
											 * [tMSSqlOutput_1 main ] stop
											 */

										} // End of branch "insert"

									} // End of branch "out2"

								} // End of branch "row2"

							} // End of branch "row1"

							/**
							 * [tFileInputExcel_1 end ] start
							 */

							currentComponent = "tFileInputExcel_1";

						}

						log.debug("tFileInputExcel_1 - Retrieved records count: "
								+ nb_line_tFileInputExcel_1 + " .");

						globalMap.put("tFileInputExcel_1_NB_LINE",
								nb_line_tFileInputExcel_1);

					}

				} finally {

					if (!(source_tFileInputExcel_1 instanceof java.io.InputStream)) {
						workbook_tFileInputExcel_1.getPackage().revert();
					}

				}

				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - " + "Done.");

				ok_Hash.put("tFileInputExcel_1", true);
				end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileInputExcel_1 end ] stop
				 */

				/**
				 * [tFilterRow_4 end ] start
				 */

				currentComponent = "tFilterRow_4";

				globalMap.put("tFilterRow_4_NB_LINE", nb_line_tFilterRow_4);
				globalMap.put("tFilterRow_4_NB_LINE_OK",
						nb_line_ok_tFilterRow_4);
				globalMap.put("tFilterRow_4_NB_LINE_REJECT",
						nb_line_reject_tFilterRow_4);

				log.info("tFilterRow_4 - Processed records count:"
						+ nb_line_tFilterRow_4 + ". Matched records count:"
						+ nb_line_ok_tFilterRow_4 + ". Rejected records count:"
						+ nb_line_reject_tFilterRow_4 + ".");

				if (log.isDebugEnabled())
					log.debug("tFilterRow_4 - " + "Done.");

				ok_Hash.put("tFilterRow_4", true);
				end_Hash.put("tFilterRow_4", System.currentTimeMillis());

				/**
				 * [tFilterRow_4 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

				// ###############################
				// # Lookup hashes releasing
				// ###############################
				log.debug("tMap_3 - Written records count in the table 'out2': "
						+ count_out2_tMap_3 + ".");

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + "Done.");

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tAddCRCRow_1 end ] start
				 */

				currentComponent = "tAddCRCRow_1";

				globalMap.put("tAddCRCRow_1_NB_LINE", nb_line_tAddCRCRow_1);

				ok_Hash.put("tAddCRCRow_1", true);
				end_Hash.put("tAddCRCRow_1", System.currentTimeMillis());

				/**
				 * [tAddCRCRow_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

				// ###############################
				// # Lookup hashes releasing
				if (tHash_Lookup_row5 != null) {
					tHash_Lookup_row5.endGet();
				}
				globalMap.remove("tHash_Lookup_row5");

				// ###############################
				log.debug("tMap_2 - Written records count in the table 'active_deactivate': "
						+ count_active_deactivate_tMap_2 + ".");
				log.debug("tMap_2 - Written records count in the table 'update': "
						+ count_update_tMap_2 + ".");
				log.debug("tMap_2 - Written records count in the table 'insert': "
						+ count_insert_tMap_2 + ".");

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + "Done.");

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tMSSqlOutput_3 end ] start
				 */

				currentComponent = "tMSSqlOutput_3";

				try {
					int countSum_tMSSqlOutput_3 = 0;
					if (pstmt_tMSSqlOutput_3 != null
							&& batchSizeCounter_tMSSqlOutput_3 > 0) {

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_3 - " + "Executing the "
									+ "UPDATE" + " batch.");
						for (int countEach_tMSSqlOutput_3 : pstmt_tMSSqlOutput_3
								.executeBatch()) {
							if (countEach_tMSSqlOutput_3 == -2
									|| countEach_tMSSqlOutput_3 == -3) {
								break;
							}
							countSum_tMSSqlOutput_3 += countEach_tMSSqlOutput_3;
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_3 - " + "The " + "UPDATE"
									+ " batch execution has succeeded.");
					}

					updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tMSSqlOutput_3 = 0;
					for (int countEach_tMSSqlOutput_3 : e.getUpdateCounts()) {
						countSum_tMSSqlOutput_3 += (countEach_tMSSqlOutput_3 < 0 ? 0
								: countEach_tMSSqlOutput_3);
					}

					updatedCount_tMSSqlOutput_3 += countSum_tMSSqlOutput_3;

					log.error("tMSSqlOutput_3 - " + e.getMessage());
					System.err.println(e.getMessage());

				}
				if (pstmt_tMSSqlOutput_3 != null) {

					pstmt_tMSSqlOutput_3.close();

				}

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ "Connection starting to commit "
							+ commitCounter_tMSSqlOutput_3 + " record(s).");
				conn_tMSSqlOutput_3.commit();

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ "Connection commit has succeeded.");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ "Closing the connection to the database.");
				conn_tMSSqlOutput_3.close();
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - "
							+ "Connection to the database has closed.");
				resourceMap.put("finish_tMSSqlOutput_3", true);

				nb_line_deleted_tMSSqlOutput_3 = nb_line_deleted_tMSSqlOutput_3
						+ deletedCount_tMSSqlOutput_3;
				nb_line_update_tMSSqlOutput_3 = nb_line_update_tMSSqlOutput_3
						+ updatedCount_tMSSqlOutput_3;
				nb_line_inserted_tMSSqlOutput_3 = nb_line_inserted_tMSSqlOutput_3
						+ insertedCount_tMSSqlOutput_3;
				nb_line_rejected_tMSSqlOutput_3 = nb_line_rejected_tMSSqlOutput_3
						+ rejectedCount_tMSSqlOutput_3;

				globalMap.put("tMSSqlOutput_3_NB_LINE", nb_line_tMSSqlOutput_3);
				globalMap.put("tMSSqlOutput_3_NB_LINE_UPDATED",
						nb_line_update_tMSSqlOutput_3);
				globalMap.put("tMSSqlOutput_3_NB_LINE_INSERTED",
						nb_line_inserted_tMSSqlOutput_3);
				globalMap.put("tMSSqlOutput_3_NB_LINE_DELETED",
						nb_line_deleted_tMSSqlOutput_3);
				globalMap.put("tMSSqlOutput_3_NB_LINE_REJECTED",
						nb_line_rejected_tMSSqlOutput_3);

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Has " + "updated" + " "
							+ nb_line_update_tMSSqlOutput_3 + " record(s).");

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_3 - " + "Done.");

				ok_Hash.put("tMSSqlOutput_3", true);
				end_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());

				/**
				 * [tMSSqlOutput_3 end ] stop
				 */

				/**
				 * [tMSSqlOutput_2 end ] start
				 */

				currentComponent = "tMSSqlOutput_2";

				try {
					int countSum_tMSSqlOutput_2 = 0;
					if (pstmt_tMSSqlOutput_2 != null
							&& batchSizeCounter_tMSSqlOutput_2 > 0) {

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - " + "Executing the "
									+ "UPDATE" + " batch.");
						for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
								.executeBatch()) {
							if (countEach_tMSSqlOutput_2 == -2
									|| countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - " + "The " + "UPDATE"
									+ " batch execution has succeeded.");
					}

					updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tMSSqlOutput_2 = 0;
					for (int countEach_tMSSqlOutput_2 : e.getUpdateCounts()) {
						countSum_tMSSqlOutput_2 += (countEach_tMSSqlOutput_2 < 0 ? 0
								: countEach_tMSSqlOutput_2);
					}

					updatedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

					log.error("tMSSqlOutput_2 - " + e.getMessage());
					System.err.println(e.getMessage());

				}
				if (pstmt_tMSSqlOutput_2 != null) {

					pstmt_tMSSqlOutput_2.close();

				}

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection starting to commit "
							+ commitCounter_tMSSqlOutput_2 + " record(s).");
				conn_tMSSqlOutput_2.commit();

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection commit has succeeded.");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Closing the connection to the database.");
				conn_tMSSqlOutput_2.close();
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection to the database has closed.");
				resourceMap.put("finish_tMSSqlOutput_2", true);

				nb_line_deleted_tMSSqlOutput_2 = nb_line_deleted_tMSSqlOutput_2
						+ deletedCount_tMSSqlOutput_2;
				nb_line_update_tMSSqlOutput_2 = nb_line_update_tMSSqlOutput_2
						+ updatedCount_tMSSqlOutput_2;
				nb_line_inserted_tMSSqlOutput_2 = nb_line_inserted_tMSSqlOutput_2
						+ insertedCount_tMSSqlOutput_2;
				nb_line_rejected_tMSSqlOutput_2 = nb_line_rejected_tMSSqlOutput_2
						+ rejectedCount_tMSSqlOutput_2;

				globalMap.put("tMSSqlOutput_2_NB_LINE", nb_line_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_UPDATED",
						nb_line_update_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_INSERTED",
						nb_line_inserted_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_DELETED",
						nb_line_deleted_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_REJECTED",
						nb_line_rejected_tMSSqlOutput_2);

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Has " + "updated" + " "
							+ nb_line_update_tMSSqlOutput_2 + " record(s).");

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Done.");

				ok_Hash.put("tMSSqlOutput_2", true);
				end_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());

				/**
				 * [tMSSqlOutput_2 end ] stop
				 */

				/**
				 * [tMSSqlOutput_1 end ] start
				 */

				currentComponent = "tMSSqlOutput_1";

				try {
					int countSum_tMSSqlOutput_1 = 0;
					if (pstmt_tMSSqlOutput_1 != null
							&& batchSizeCounter_tMSSqlOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_1 - " + "Executing the "
									+ "INSERT" + " batch.");
						for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
								.executeBatch()) {
							if (countEach_tMSSqlOutput_1 == -2
									|| countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_1 - " + "The " + "INSERT"
									+ " batch execution has succeeded.");
					}

					insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tMSSqlOutput_1 = 0;
					for (int countEach_tMSSqlOutput_1 : e.getUpdateCounts()) {
						countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
								: countEach_tMSSqlOutput_1);
					}

					insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

					log.error("tMSSqlOutput_1 - " + e.getMessage());
					System.err.println(e.getMessage());

				}
				if (pstmt_tMSSqlOutput_1 != null) {

					pstmt_tMSSqlOutput_1.close();

				}

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection starting to commit "
							+ commitCounter_tMSSqlOutput_1 + " record(s).");
				conn_tMSSqlOutput_1.commit();

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection commit has succeeded.");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Closing the connection to the database.");
				conn_tMSSqlOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection to the database has closed.");
				resourceMap.put("finish_tMSSqlOutput_1", true);

				nb_line_deleted_tMSSqlOutput_1 = nb_line_deleted_tMSSqlOutput_1
						+ deletedCount_tMSSqlOutput_1;
				nb_line_update_tMSSqlOutput_1 = nb_line_update_tMSSqlOutput_1
						+ updatedCount_tMSSqlOutput_1;
				nb_line_inserted_tMSSqlOutput_1 = nb_line_inserted_tMSSqlOutput_1
						+ insertedCount_tMSSqlOutput_1;
				nb_line_rejected_tMSSqlOutput_1 = nb_line_rejected_tMSSqlOutput_1
						+ rejectedCount_tMSSqlOutput_1;

				globalMap.put("tMSSqlOutput_1_NB_LINE", nb_line_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_UPDATED",
						nb_line_update_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_INSERTED",
						nb_line_inserted_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_DELETED",
						nb_line_deleted_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_REJECTED",
						nb_line_rejected_tMSSqlOutput_1);

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Has " + "inserted" + " "
							+ nb_line_inserted_tMSSqlOutput_1 + " record(s).");

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Done.");

				ok_Hash.put("tMSSqlOutput_1", true);
				end_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());

				/**
				 * [tMSSqlOutput_1 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			// free memory for "tMap_2"
			globalMap.remove("tHash_Lookup_row5");

			try {

				/**
				 * [tFileInputExcel_1 finally ] start
				 */

				currentComponent = "tFileInputExcel_1";

				/**
				 * [tFileInputExcel_1 finally ] stop
				 */

				/**
				 * [tFilterRow_4 finally ] start
				 */

				currentComponent = "tFilterRow_4";

				/**
				 * [tFilterRow_4 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tAddCRCRow_1 finally ] start
				 */

				currentComponent = "tAddCRCRow_1";

				/**
				 * [tAddCRCRow_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tMSSqlOutput_3 finally ] start
				 */

				currentComponent = "tMSSqlOutput_3";

				if (resourceMap.get("finish_tMSSqlOutput_3") == null) {
					if (resourceMap.get("conn_tMSSqlOutput_3") != null) {
						try {

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_3 - "
										+ "Closing the connection to the database.");
							((java.sql.Connection) resourceMap
									.get("conn_tMSSqlOutput_3")).close();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_3 - "
										+ "Connection to the database has closed.");
						} catch (java.sql.SQLException sqlEx_tMSSqlOutput_3) {
							String errorMessage_tMSSqlOutput_3 = "failed to close the connection in tMSSqlOutput_3 :"
									+ sqlEx_tMSSqlOutput_3.getMessage();

							log.error("tMSSqlOutput_3 - "
									+ errorMessage_tMSSqlOutput_3);
							System.err.println(errorMessage_tMSSqlOutput_3);
						}
					}
				}

				/**
				 * [tMSSqlOutput_3 finally ] stop
				 */

				/**
				 * [tMSSqlOutput_2 finally ] start
				 */

				currentComponent = "tMSSqlOutput_2";

				if (resourceMap.get("finish_tMSSqlOutput_2") == null) {
					if (resourceMap.get("conn_tMSSqlOutput_2") != null) {
						try {

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - "
										+ "Closing the connection to the database.");
							((java.sql.Connection) resourceMap
									.get("conn_tMSSqlOutput_2")).close();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - "
										+ "Connection to the database has closed.");
						} catch (java.sql.SQLException sqlEx_tMSSqlOutput_2) {
							String errorMessage_tMSSqlOutput_2 = "failed to close the connection in tMSSqlOutput_2 :"
									+ sqlEx_tMSSqlOutput_2.getMessage();

							log.error("tMSSqlOutput_2 - "
									+ errorMessage_tMSSqlOutput_2);
							System.err.println(errorMessage_tMSSqlOutput_2);
						}
					}
				}

				/**
				 * [tMSSqlOutput_2 finally ] stop
				 */

				/**
				 * [tMSSqlOutput_1 finally ] start
				 */

				currentComponent = "tMSSqlOutput_1";

				if (resourceMap.get("finish_tMSSqlOutput_1") == null) {
					if (resourceMap.get("conn_tMSSqlOutput_1") != null) {
						try {

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Closing the connection to the database.");
							((java.sql.Connection) resourceMap
									.get("conn_tMSSqlOutput_1")).close();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Connection to the database has closed.");
						} catch (java.sql.SQLException sqlEx_tMSSqlOutput_1) {
							String errorMessage_tMSSqlOutput_1 = "failed to close the connection in tMSSqlOutput_1 :"
									+ sqlEx_tMSSqlOutput_1.getMessage();

							log.error("tMSSqlOutput_1 - "
									+ errorMessage_tMSSqlOutput_1);
							System.err.println(errorMessage_tMSSqlOutput_1);
						}
					}
				}

				/**
				 * [tMSSqlOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}

	public static class row5Struct implements
			routines.system.IPersistableComparableLookupRow<row5Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		public Long CRC;

		public Long getCRC() {
			return this.CRC;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result
						+ ((this.CRC == null) ? 0 : this.CRC.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row5Struct other = (row5Struct) obj;

			if (this.CRC == null) {
				if (other.CRC != null)
					return false;

			} else if (!this.CRC.equals(other.CRC))

				return false;

			return true;
		}

		public void copyDataTo(row5Struct other) {

			other.db_type = this.db_type;
			other.db_nme = this.db_nme;
			other.db_schema = this.db_schema;
			other.host = this.host;
			other.port = this.port;
			other.db_user = this.db_user;
			other.db_pass = this.db_pass;
			other.active = this.active;
			other.CRC = this.CRC;

		}

		public void copyKeysDataTo(row5Struct other) {

			other.CRC = this.CRC;

		}

		private String readString(DataInputStream dis, ObjectInputStream ois)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos,
				ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos,
				ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.CRC = null;
					} else {
						this.CRC = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Long

				if (this.CRC == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.CRC);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.db_type = readString(dis, ois);

				this.db_nme = readString(dis, ois);

				this.db_schema = readString(dis, ois);

				this.host = readString(dis, ois);

				this.port = readString(dis, ois);

				this.db_user = readString(dis, ois);

				this.db_pass = readString(dis, ois);

				this.active = readInteger(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.db_type, dos, oos);

				writeString(this.db_nme, dos, oos);

				writeString(this.db_schema, dos, oos);

				writeString(this.host, dos, oos);

				writeString(this.port, dos, oos);

				writeString(this.db_user, dos, oos);

				writeString(this.db_pass, dos, oos);

				writeInteger(this.active, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append(",CRC=" + String.valueOf(CRC));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			if (CRC == null) {
				sb.append("<null>");
			} else {
				sb.append(CRC);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.CRC, other.CRC);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out1Struct implements
			routines.system.IPersistableRow<out1Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tMSSqlInput_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();
				out1Struct out1 = new out1Struct();
				row5Struct row5 = new row5Struct();

				/**
				 * [tAdvancedHash_row5 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row5", false);
				start_Hash
						.put("tAdvancedHash_row5", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row5";

				int tos_count_tAdvancedHash_row5 = 0;

				// connection name:row5
				// source node:tAddCRCRow_2 - inputs:(out1) outputs:(row5,row5)
				// | target node:tAdvancedHash_row5 - inputs:(row5) outputs:()
				// linked node: tMap_2 - inputs:(row4,row5)
				// outputs:(active_deactivate,update,insert)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row5 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row5Struct> tHash_Lookup_row5 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row5Struct> getLookup(matchingModeEnum_row5);

				globalMap.put("tHash_Lookup_row5", tHash_Lookup_row5);

				/**
				 * [tAdvancedHash_row5 begin ] stop
				 */

				/**
				 * [tAddCRCRow_2 begin ] start
				 */

				ok_Hash.put("tAddCRCRow_2", false);
				start_Hash.put("tAddCRCRow_2", System.currentTimeMillis());

				currentComponent = "tAddCRCRow_2";

				int tos_count_tAddCRCRow_2 = 0;

				int nb_line_tAddCRCRow_2 = 0;

				/**
				 * [tAddCRCRow_2 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_1 = new StringBuilder();
				log4jParamters_tMap_1.append("Parameters:");
				log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + log4jParamters_tMap_1);

				// ###############################
				// # Lookup's keys initialization
				int count_row3_tMap_1 = 0;

				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_out1_tMap_1 = 0;

				out1Struct out1_tmp = new out1Struct();
				// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tMSSqlInput_1 begin ] start
				 */

				ok_Hash.put("tMSSqlInput_1", false);
				start_Hash.put("tMSSqlInput_1", System.currentTimeMillis());

				currentComponent = "tMSSqlInput_1";

				int tos_count_tMSSqlInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlInput_1 = new StringBuilder();
				log4jParamters_tMSSqlInput_1.append("Parameters:");
				log4jParamters_tMSSqlInput_1.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1
						.append("QUERY"
								+ " = "
								+ "\"SELECT db_type,  		db_nme,  		db_schema,  		host,  		port,  		db_user,  		db_pass,  		active  FROM	schema_connection_details\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("PROPERTIES" + " = "
						+ "\"noDatetimeStringSync=true\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_type") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("db_nme") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_schema")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("host") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("port") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_user")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_pass") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("active") + "}]");
				log4jParamters_tMSSqlInput_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + log4jParamters_tMSSqlInput_1);

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tMSSqlInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tMSSqlInput_1 = new String[] {
						"FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tMSSqlInput_1,
						talendToDBArray_tMSSqlInput_1);
				int nb_line_tMSSqlInput_1 = 0;
				java.sql.Connection conn_tMSSqlInput_1 = null;
				String driverClass_tMSSqlInput_1 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class.forName(driverClass_tMSSqlInput_1);
				String dbUser_tMSSqlInput_1 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlInput_1 = context.metadata_db_pass;

				String dbPwd_tMSSqlInput_1 = decryptedPassword_tMSSqlInput_1;

				String port_tMSSqlInput_1 = context.metadata_port;
				String dbname_tMSSqlInput_1 = context.metadata_db_name;
				String url_tMSSqlInput_1 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlInput_1)) {
					url_tMSSqlInput_1 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlInput_1)) {
					url_tMSSqlInput_1 += "//" + context.metadata_db_name;
				}
				url_tMSSqlInput_1 += ";appName=" + projectName + ";"
						+ "noDatetimeStringSync=true";
				String dbschema_tMSSqlInput_1 = context.metadata_db_schema;

				log.debug("tMSSqlInput_1 - Driver ClassName: "
						+ driverClass_tMSSqlInput_1 + ".");

				log.debug("tMSSqlInput_1 - Connection attempt to '"
						+ url_tMSSqlInput_1 + "' with the username '"
						+ dbUser_tMSSqlInput_1 + "'.");

				conn_tMSSqlInput_1 = java.sql.DriverManager.getConnection(
						url_tMSSqlInput_1, dbUser_tMSSqlInput_1,
						dbPwd_tMSSqlInput_1);
				log.debug("tMSSqlInput_1 - Connection to '" + url_tMSSqlInput_1
						+ "' has succeeded.");

				java.sql.Statement stmt_tMSSqlInput_1 = conn_tMSSqlInput_1
						.createStatement();

				String dbquery_tMSSqlInput_1 = "SELECT db_type,\n		db_nme,\n		db_schema,\n		host,\n		port,\n		db_user,\n		db_pass,\n		active\nFROM	schema_connection_details";

				log.debug("tMSSqlInput_1 - Executing the query: '"
						+ dbquery_tMSSqlInput_1 + "'.");

				globalMap.put("tMSSqlInput_1_QUERY", dbquery_tMSSqlInput_1);

				java.sql.ResultSet rs_tMSSqlInput_1 = null;
				try {
					rs_tMSSqlInput_1 = stmt_tMSSqlInput_1
							.executeQuery(dbquery_tMSSqlInput_1);
					java.sql.ResultSetMetaData rsmd_tMSSqlInput_1 = rs_tMSSqlInput_1
							.getMetaData();
					int colQtyInRs_tMSSqlInput_1 = rsmd_tMSSqlInput_1
							.getColumnCount();

					String tmpContent_tMSSqlInput_1 = null;

					log.debug("tMSSqlInput_1 - Retrieving records from the database.");

					while (rs_tMSSqlInput_1.next()) {
						nb_line_tMSSqlInput_1++;

						if (colQtyInRs_tMSSqlInput_1 < 1) {
							row3.db_type = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(1);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(1)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.db_type = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.db_type = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.db_type = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 2) {
							row3.db_nme = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(2);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(2)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.db_nme = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.db_nme = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.db_nme = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 3) {
							row3.db_schema = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(3);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(3)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.db_schema = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.db_schema = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.db_schema = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 4) {
							row3.host = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(4);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(4)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.host = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.host = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.host = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 5) {
							row3.port = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(5);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(5)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.port = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.port = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.port = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 6) {
							row3.db_user = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(6);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(6)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.db_user = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.db_user = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.db_user = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 7) {
							row3.db_pass = null;
						} else {

							tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1
									.getString(7);
							if (tmpContent_tMSSqlInput_1 != null) {
								if (talendToDBList_tMSSqlInput_1
										.contains(rsmd_tMSSqlInput_1
												.getColumnTypeName(7)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row3.db_pass = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_1);
								} else {
									row3.db_pass = tmpContent_tMSSqlInput_1;
								}
							} else {
								row3.db_pass = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_1 < 8) {
							row3.active = null;
						} else {

							if (rs_tMSSqlInput_1.getObject(8) != null) {
								row3.active = rs_tMSSqlInput_1.getInt(8);
							} else {
								row3.active = null;
							}
						}

						log.debug("tMSSqlInput_1 - Retrieving the record "
								+ nb_line_tMSSqlInput_1 + ".");

						/**
						 * [tMSSqlInput_1 begin ] stop
						 */

						/**
						 * [tMSSqlInput_1 main ] start
						 */

						currentComponent = "tMSSqlInput_1";

						tos_count_tMSSqlInput_1++;

						/**
						 * [tMSSqlInput_1 main ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (log.isTraceEnabled()) {
							log.trace("row3 - "
									+ (row3 == null ? "" : row3.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							out1 = null;

							// # Output table : 'out1'
							count_out1_tMap_1++;

							out1_tmp.db_type = StringHandling
									.UPCASE(row3.db_type);
							out1_tmp.db_nme = StringHandling
									.UPCASE(row3.db_nme);
							out1_tmp.db_schema = StringHandling
									.UPCASE(row3.db_schema);
							out1_tmp.host = StringHandling.UPCASE(row3.host);
							out1_tmp.port = StringHandling.UPCASE(row3.port);
							out1_tmp.db_user = StringHandling
									.UPCASE(row3.db_user);
							out1_tmp.db_pass = row3.db_pass;
							out1_tmp.active = row3.active;
							out1 = out1_tmp;
							log.debug("tMap_1 - Outputting the record "
									+ count_out1_tMap_1
									+ " of the output table 'out1'.");

							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */
						// Start of branch "out1"
						if (out1 != null) {

							/**
							 * [tAddCRCRow_2 main ] start
							 */

							currentComponent = "tAddCRCRow_2";

							if (log.isTraceEnabled()) {
								log.trace("out1 - "
										+ (out1 == null ? "" : out1
												.toLogString()));
							}

							Long crcComputedValuetAddCRCRow_2 = null;
							StringBuilder strBuffer_tAddCRCRow_2 = new StringBuilder();
							strBuffer_tAddCRCRow_2.append(

							String.valueOf(out1.db_type)

							);

							strBuffer_tAddCRCRow_2.append(

							String.valueOf(out1.db_nme)

							);

							strBuffer_tAddCRCRow_2.append(

							String.valueOf(out1.db_schema)

							);

							strBuffer_tAddCRCRow_2.append(

							String.valueOf(out1.host)

							);

							strBuffer_tAddCRCRow_2.append(

							String.valueOf(out1.port)

							);

							java.util.zip.CRC32 crc32tAddCRCRow_2 = new java.util.zip.CRC32();
							crc32tAddCRCRow_2.update(strBuffer_tAddCRCRow_2
									.toString().getBytes());
							crcComputedValuetAddCRCRow_2 = new Long(
									crc32tAddCRCRow_2.getValue());
							row5.db_type = out1.db_type;
							row5.db_nme = out1.db_nme;
							row5.db_schema = out1.db_schema;
							row5.host = out1.host;
							row5.port = out1.port;
							row5.db_user = out1.db_user;
							row5.db_pass = out1.db_pass;
							row5.active = out1.active;
							row5.CRC = crcComputedValuetAddCRCRow_2;
							row5.db_type = out1.db_type;
							row5.db_nme = out1.db_nme;
							row5.db_schema = out1.db_schema;
							row5.host = out1.host;
							row5.port = out1.port;
							row5.db_user = out1.db_user;
							row5.db_pass = out1.db_pass;
							row5.active = out1.active;
							row5.CRC = crcComputedValuetAddCRCRow_2;
							nb_line_tAddCRCRow_2++;

							tos_count_tAddCRCRow_2++;

							/**
							 * [tAddCRCRow_2 main ] stop
							 */

							/**
							 * [tAdvancedHash_row5 main ] start
							 */

							currentComponent = "tAdvancedHash_row5";

							if (log.isTraceEnabled()) {
								log.trace("row5 - "
										+ (row5 == null ? "" : row5
												.toLogString()));
							}

							row5Struct row5_HashRow = new row5Struct();

							row5_HashRow.db_type = row5.db_type;

							row5_HashRow.db_nme = row5.db_nme;

							row5_HashRow.db_schema = row5.db_schema;

							row5_HashRow.host = row5.host;

							row5_HashRow.port = row5.port;

							row5_HashRow.db_user = row5.db_user;

							row5_HashRow.db_pass = row5.db_pass;

							row5_HashRow.active = row5.active;

							row5_HashRow.CRC = row5.CRC;

							tHash_Lookup_row5.put(row5_HashRow);

							tos_count_tAdvancedHash_row5++;

							/**
							 * [tAdvancedHash_row5 main ] stop
							 */

						} // End of branch "out1"

						/**
						 * [tMSSqlInput_1 end ] start
						 */

						currentComponent = "tMSSqlInput_1";

					}
				} finally {
					stmt_tMSSqlInput_1.close();

					if (conn_tMSSqlInput_1 != null
							&& !conn_tMSSqlInput_1.isClosed()) {

						log.debug("tMSSqlInput_1 - Closing the connection to the database.");

						conn_tMSSqlInput_1.close();

						log.debug("tMSSqlInput_1 - Connection to the database closed.");

					}
				}
				globalMap.put("tMSSqlInput_1_NB_LINE", nb_line_tMSSqlInput_1);
				log.debug("tMSSqlInput_1 - Retrieved records count: "
						+ nb_line_tMSSqlInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + "Done.");

				ok_Hash.put("tMSSqlInput_1", true);
				end_Hash.put("tMSSqlInput_1", System.currentTimeMillis());

				/**
				 * [tMSSqlInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

				// ###############################
				// # Lookup hashes releasing
				// ###############################
				log.debug("tMap_1 - Written records count in the table 'out1': "
						+ count_out1_tMap_1 + ".");

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + "Done.");

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tAddCRCRow_2 end ] start
				 */

				currentComponent = "tAddCRCRow_2";

				globalMap.put("tAddCRCRow_2_NB_LINE", nb_line_tAddCRCRow_2);

				ok_Hash.put("tAddCRCRow_2", true);
				end_Hash.put("tAddCRCRow_2", System.currentTimeMillis());

				/**
				 * [tAddCRCRow_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_row5 end ] start
				 */

				currentComponent = "tAdvancedHash_row5";

				tHash_Lookup_row5.endPut();

				ok_Hash.put("tAdvancedHash_row5", true);
				end_Hash.put("tAdvancedHash_row5", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row5 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tMSSqlInput_1 finally ] start
				 */

				currentComponent = "tMSSqlInput_1";

				/**
				 * [tMSSqlInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tAddCRCRow_2 finally ] start
				 */

				currentComponent = "tAddCRCRow_2";

				/**
				 * [tAddCRCRow_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row5 finally ] start
				 */

				currentComponent = "tAdvancedHash_row5";

				/**
				 * [tAdvancedHash_row5 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row_talendLogs_LOGSStruct implements
			routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (moment == null) {
				sb.append("<null>");
			} else {
				sb.append(moment);
			}

			sb.append("|");

			if (pid == null) {
				sb.append("<null>");
			} else {
				sb.append(pid);
			}

			sb.append("|");

			if (root_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(root_pid);
			}

			sb.append("|");

			if (father_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(father_pid);
			}

			sb.append("|");

			if (project == null) {
				sb.append("<null>");
			} else {
				sb.append(project);
			}

			sb.append("|");

			if (job == null) {
				sb.append("<null>");
			} else {
				sb.append(job);
			}

			sb.append("|");

			if (context == null) {
				sb.append("<null>");
			} else {
				sb.append(context);
			}

			sb.append("|");

			if (priority == null) {
				sb.append("<null>");
			} else {
				sb.append(priority);
			}

			sb.append("|");

			if (type == null) {
				sb.append("<null>");
			} else {
				sb.append(type);
			}

			sb.append("|");

			if (origin == null) {
				sb.append("<null>");
			} else {
				sb.append(origin);
			}

			sb.append("|");

			if (message == null) {
				sb.append("<null>");
			} else {
				sb.append(message);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendLogs_LOGSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendLogs_LOGSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();

				/**
				 * [talendLogs_CONSOLE begin ] start
				 */

				ok_Hash.put("talendLogs_CONSOLE", false);
				start_Hash
						.put("talendLogs_CONSOLE", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				int tos_count_talendLogs_CONSOLE = 0;

				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - " + "Start to work.");
				StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
				log4jParamters_talendLogs_CONSOLE.append("Parameters:");
				log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = "
						+ "true");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR"
						+ " = " + "\"|\"");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE
						.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - "
							+ log4jParamters_talendLogs_CONSOLE);

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;

				StringBuilder strBuffer_talendLogs_CONSOLE = null;
				int nb_line_talendLogs_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendLogs_CONSOLE begin ] stop
				 */

				/**
				 * [talendLogs_LOGS begin ] start
				 */

				ok_Hash.put("talendLogs_LOGS", false);
				start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				int tos_count_talendLogs_LOGS = 0;

				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - " + "Start to work.");
				StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
				log4jParamters_talendLogs_LOGS.append("Parameters:");
				log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION"
						+ " = " + "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = "
						+ "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = "
						+ "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE"
						+ " = " + "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - "
							+ log4jParamters_talendLogs_LOGS);

				for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS
						.getMessages()) {
					row_talendLogs_LOGS.type = lcm.getType();
					row_talendLogs_LOGS.origin = (lcm.getOrigin() == null
							|| lcm.getOrigin().length() < 1 ? null : lcm
							.getOrigin());
					row_talendLogs_LOGS.priority = lcm.getPriority();
					row_talendLogs_LOGS.message = lcm.getMessage();
					row_talendLogs_LOGS.code = lcm.getCode();

					row_talendLogs_LOGS.moment = java.util.Calendar
							.getInstance().getTime();

					row_talendLogs_LOGS.pid = pid;
					row_talendLogs_LOGS.root_pid = rootPid;
					row_talendLogs_LOGS.father_pid = fatherPid;

					row_talendLogs_LOGS.project = projectName;
					row_talendLogs_LOGS.job = jobName;
					row_talendLogs_LOGS.context = contextStr;

					/**
					 * [talendLogs_LOGS begin ] stop
					 */

					/**
					 * [talendLogs_LOGS main ] start
					 */

					currentVirtualComponent = "talendLogs_LOGS";

					currentComponent = "talendLogs_LOGS";

					tos_count_talendLogs_LOGS++;

					/**
					 * [talendLogs_LOGS main ] stop
					 */

					/**
					 * [talendLogs_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendLogs_CONSOLE";

					currentComponent = "talendLogs_CONSOLE";

					// /////////////////////

					strBuffer_talendLogs_CONSOLE = new StringBuilder();

					if (row_talendLogs_LOGS.moment != null) { //

						strBuffer_talendLogs_CONSOLE.append(FormatterUtils
								.format_Date(row_talendLogs_LOGS.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.root_pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.root_pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.father_pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.father_pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.project != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.project));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.job != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.job));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.context != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.context));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.priority != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.priority));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.type != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.type));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.origin != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.origin));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.message != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.message));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.code != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.code));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendLogs_CONSOLE);
					}
					log.info("talendLogs_CONSOLE - Content of row "
							+ (nb_line_talendLogs_CONSOLE + 1) + ": "
							+ strBuffer_talendLogs_CONSOLE.toString());
					consoleOut_talendLogs_CONSOLE
							.println(strBuffer_talendLogs_CONSOLE.toString());
					consoleOut_talendLogs_CONSOLE.flush();
					nb_line_talendLogs_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendLogs_CONSOLE++;

					/**
					 * [talendLogs_CONSOLE main ] stop
					 */

					/**
					 * [talendLogs_LOGS end ] start
					 */

					currentVirtualComponent = "talendLogs_LOGS";

					currentComponent = "talendLogs_LOGS";

				}

				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - " + "Done.");

				ok_Hash.put("talendLogs_LOGS", true);
				end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				/**
				 * [talendLogs_LOGS end ] stop
				 */

				/**
				 * [talendLogs_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				// ////
				// ////
				globalMap.put("talendLogs_CONSOLE_NB_LINE",
						nb_line_talendLogs_CONSOLE);
				if (log.isInfoEnabled())
					log.info("talendLogs_CONSOLE - " + "Printed row count: "
							+ nb_line_talendLogs_CONSOLE + ".");

				// /////////////////////

				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - " + "Done.");

				ok_Hash.put("talendLogs_CONSOLE", true);
				end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendLogs_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [talendLogs_LOGS finally ] start
				 */

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				/**
				 * [talendLogs_LOGS finally ] stop
				 */

				/**
				 * [talendLogs_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				/**
				 * [talendLogs_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendStats_STATSStruct implements
			routines.system.IPersistableRow<row_talendStats_STATSStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details = new byte[2 * length];
					}
				}
				dis.readFully(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking_Connection_Details,
						0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking_Connection_Details) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (moment == null) {
				sb.append("<null>");
			} else {
				sb.append(moment);
			}

			sb.append("|");

			if (pid == null) {
				sb.append("<null>");
			} else {
				sb.append(pid);
			}

			sb.append("|");

			if (father_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(father_pid);
			}

			sb.append("|");

			if (root_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(root_pid);
			}

			sb.append("|");

			if (system_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(system_pid);
			}

			sb.append("|");

			if (project == null) {
				sb.append("<null>");
			} else {
				sb.append(project);
			}

			sb.append("|");

			if (job == null) {
				sb.append("<null>");
			} else {
				sb.append(job);
			}

			sb.append("|");

			if (job_repository_id == null) {
				sb.append("<null>");
			} else {
				sb.append(job_repository_id);
			}

			sb.append("|");

			if (job_version == null) {
				sb.append("<null>");
			} else {
				sb.append(job_version);
			}

			sb.append("|");

			if (context == null) {
				sb.append("<null>");
			} else {
				sb.append(context);
			}

			sb.append("|");

			if (origin == null) {
				sb.append("<null>");
			} else {
				sb.append(origin);
			}

			sb.append("|");

			if (message_type == null) {
				sb.append("<null>");
			} else {
				sb.append(message_type);
			}

			sb.append("|");

			if (message == null) {
				sb.append("<null>");
			} else {
				sb.append(message);
			}

			sb.append("|");

			if (duration == null) {
				sb.append("<null>");
			} else {
				sb.append(duration);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendStats_STATSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendStats_STATSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();

				/**
				 * [talendStats_CONSOLE begin ] start
				 */

				ok_Hash.put("talendStats_CONSOLE", false);
				start_Hash.put("talendStats_CONSOLE",
						System.currentTimeMillis());

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				int tos_count_talendStats_CONSOLE = 0;

				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - " + "Start to work.");
				StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
				log4jParamters_talendStats_CONSOLE.append("Parameters:");
				log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = "
						+ "true");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = "
						+ "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = "
						+ "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR"
						+ " = " + "\"|\"");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE
						.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - "
							+ log4jParamters_talendStats_CONSOLE);

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendStats_CONSOLE = null;

				StringBuilder strBuffer_talendStats_CONSOLE = null;
				int nb_line_talendStats_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendStats_CONSOLE begin ] stop
				 */

				/**
				 * [talendStats_STATS begin ] start
				 */

				ok_Hash.put("talendStats_STATS", false);
				start_Hash.put("talendStats_STATS", System.currentTimeMillis());

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				int tos_count_talendStats_STATS = 0;

				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - " + "Start to work.");
				StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
				log4jParamters_talendStats_STATS.append("Parameters:");
				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - "
							+ log4jParamters_talendStats_STATS);

				for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS
						.getMessages()) {
					row_talendStats_STATS.pid = pid;
					row_talendStats_STATS.root_pid = rootPid;
					row_talendStats_STATS.father_pid = fatherPid;
					row_talendStats_STATS.project = projectName;
					row_talendStats_STATS.job = jobName;
					row_talendStats_STATS.context = contextStr;
					row_talendStats_STATS.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row_talendStats_STATS.message = scm.getMessage();
					row_talendStats_STATS.duration = scm.getDuration();
					row_talendStats_STATS.moment = scm.getMoment();
					row_talendStats_STATS.message_type = scm.getMessageType();
					row_talendStats_STATS.job_version = scm.getJobVersion();
					row_talendStats_STATS.job_repository_id = scm.getJobId();
					row_talendStats_STATS.system_pid = scm.getSystemPid();

					/**
					 * [talendStats_STATS begin ] stop
					 */

					/**
					 * [talendStats_STATS main ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

					tos_count_talendStats_STATS++;

					/**
					 * [talendStats_STATS main ] stop
					 */

					/**
					 * [talendStats_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendStats_CONSOLE";

					currentComponent = "talendStats_CONSOLE";

					// /////////////////////

					strBuffer_talendStats_CONSOLE = new StringBuilder();

					if (row_talendStats_STATS.moment != null) { //

						strBuffer_talendStats_CONSOLE.append(FormatterUtils
								.format_Date(row_talendStats_STATS.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.father_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.father_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.root_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.root_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.system_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.system_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.project != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.project));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.job));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job_repository_id != null) { //

						strBuffer_talendStats_CONSOLE
								.append(String
										.valueOf(row_talendStats_STATS.job_repository_id));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job_version != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.job_version));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.context != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.context));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.origin != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.origin));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.message_type != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.message_type));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.message != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.message));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.duration != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.duration));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendStats_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendStats_CONSOLE);
					}
					log.info("talendStats_CONSOLE - Content of row "
							+ (nb_line_talendStats_CONSOLE + 1) + ": "
							+ strBuffer_talendStats_CONSOLE.toString());
					consoleOut_talendStats_CONSOLE
							.println(strBuffer_talendStats_CONSOLE.toString());
					consoleOut_talendStats_CONSOLE.flush();
					nb_line_talendStats_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendStats_CONSOLE++;

					/**
					 * [talendStats_CONSOLE main ] stop
					 */

					/**
					 * [talendStats_STATS end ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

				}

				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - " + "Done.");

				ok_Hash.put("talendStats_STATS", true);
				end_Hash.put("talendStats_STATS", System.currentTimeMillis());

				/**
				 * [talendStats_STATS end ] stop
				 */

				/**
				 * [talendStats_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				// ////
				// ////
				globalMap.put("talendStats_CONSOLE_NB_LINE",
						nb_line_talendStats_CONSOLE);
				if (log.isInfoEnabled())
					log.info("talendStats_CONSOLE - " + "Printed row count: "
							+ nb_line_talendStats_CONSOLE + ".");

				// /////////////////////

				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - " + "Done.");

				ok_Hash.put("talendStats_CONSOLE", true);
				end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendStats_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [talendStats_STATS finally ] start
				 */

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				/**
				 * [talendStats_STATS finally ] stop
				 */

				/**
				 * [talendStats_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				/**
				 * [talendStats_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private java.util.Properties context_param = new java.util.Properties();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Data_Masking_Connection_Details Data_Masking_Connection_DetailsClass = new Data_Masking_Connection_Details();

		int exitCode = Data_Masking_Connection_DetailsClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Data_Masking_Connection_Details' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (!"".equals(log4jLevel)) {
			if ("trace".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.OFF);
			}
			org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
		}
		log.info("TalendJob: 'Data_Masking_Connection_Details' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = Data_Masking_Connection_Details.class
					.getClassLoader().getResourceAsStream(
							"talend_3rdi_git/data_masking_connection_details_0_1/contexts/"
									+ contextStr + ".properties");
			if (isDefaultContext && inContext == null) {

			} else {
				if (inContext != null) {
					// defaultProps is in order to keep the original context
					// value
					defaultProps.load(inContext);
					inContext.close();
					context = new ContextProperties(defaultProps);
				} else {
					// print info and job continue to run, for case:
					// context_param is not empty.
					System.err.println("Could not find the context "
							+ contextStr);
				}
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
			}
			context.file_schema_connection_details = (String) context
					.getProperty("file_schema_connection_details");
			context.metadata_host = (String) context
					.getProperty("metadata_host");
			context.metadata_port = (String) context
					.getProperty("metadata_port");
			context.metadata_db_schema = (String) context
					.getProperty("metadata_db_schema");
			context.metadata_db_name = (String) context
					.getProperty("metadata_db_name");
			context.metadata_db_user = (String) context
					.getProperty("metadata_db_user");
			context.metadata_db_pass = (String) context
					.getProperty("metadata_db_pass");
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("file_schema_connection_details")) {
				context.file_schema_connection_details = (String) parentContextMap
						.get("file_schema_connection_details");
			}
			if (parentContextMap.containsKey("metadata_host")) {
				context.metadata_host = (String) parentContextMap
						.get("metadata_host");
			}
			if (parentContextMap.containsKey("metadata_port")) {
				context.metadata_port = (String) parentContextMap
						.get("metadata_port");
			}
			if (parentContextMap.containsKey("metadata_db_schema")) {
				context.metadata_db_schema = (String) parentContextMap
						.get("metadata_db_schema");
			}
			if (parentContextMap.containsKey("metadata_db_name")) {
				context.metadata_db_name = (String) parentContextMap
						.get("metadata_db_name");
			}
			if (parentContextMap.containsKey("metadata_db_user")) {
				context.metadata_db_user = (String) parentContextMap
						.get("metadata_db_user");
			}
			if (parentContextMap.containsKey("metadata_db_pass")) {
				context.metadata_db_pass = (String) parentContextMap
						.get("metadata_db_pass");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		talendStats_STATS.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputExcel_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputExcel_1) {
			globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

			e_tFileInputExcel_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out
					.println((endUsedMemory - startUsedMemory)
							+ " bytes memory increase when running : Data_Masking_Connection_Details");
		}
		talendStats_STATS.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 296211 characters generated by Talend Data Fabric on the March 28, 2017
 * 2:57:41 PM CDT
 ************************************************************************************************/
