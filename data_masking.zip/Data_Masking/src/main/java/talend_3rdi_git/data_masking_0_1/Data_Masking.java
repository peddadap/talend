package talend_3rdi_git.data_masking_0_1;

import routines.wordcount;
import routines.TalendDataGenerator;
import routines.EBMR_routine;
import routines.Unstructure_WordcountService;
import routines.Unstructure_WordcountSoapBindingStub;
import routines.Unstructure_WordcountServiceLocator;
import routines.Numeric;
import routines.DQTechnical;
import routines.MDM;
import routines.DataOperation;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.Rules;
import routines.SQLike;
import routines.TOXLINE_isNumeric_Routine;
import routines.string_to_date;
import routines.Unstructure_Wordcount_PortType;
import routines.SQLFilters;
import routines.TalendString;
import routines.DMLogger;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.PopulateFromDynamic;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

//the import part of tJavaRow_3
//import java.util.List;

//the import part of tJavaRow_4
import routines.DMLogger;

//the import part of AST_rules_1_tJavaFlex_5
import java.util.HashMap;
import routines.RuleColumn;
import routines.Rules;
import java.util.ArrayList;

//the import part of tJava_4
//import java.util.List;

//the import part of tJava_11
//import java.util.List;

//the import part of tJavaRow_2
//import java.util.List;

//the import part of tJavaRow_6
import routines.SQLFilters;

//the import part of tJava_1
//import java.util.List;

//the import part of tJavaRow_5
//import java.util.List;

//the import part of tJava_3
import java.io.File;
import java.io.PrintStream;
import java.io.FileOutputStream;

//the import part of tJava_8
//import java.util.List;

//the import part of tJava_9
//import java.util.List;

//the import part of tJava_10
//import java.util.List;

//the import part of tJava_2
//import java.util.List;
import routines.SQLFilters;

@SuppressWarnings("unused")
/**
 * Job: Data_Masking Purpose: <br>
 * Description:  <br>
 * @author nawale, rahul
 * @version 6.2.1.20160704_1411
 * @status 
 */
public class Data_Masking implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "Data_Masking.log");
	}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger
			.getLogger(Data_Masking.class);

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private Object[] multiThreadLockWrite = new Object[0];

	private final static String defaultCharset = java.nio.charset.Charset
			.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (src_db_type != null) {

				this.setProperty("src_db_type", src_db_type.toString());

			}

			if (src_db_nme != null) {

				this.setProperty("src_db_nme", src_db_nme.toString());

			}

			if (src_db_schema != null) {

				this.setProperty("src_db_schema", src_db_schema.toString());

			}

			if (table_nme != null) {

				this.setProperty("table_nme", table_nme.toString());

			}

			if (src_host != null) {

				this.setProperty("src_host", src_host.toString());

			}

			if (src_port != null) {

				this.setProperty("src_port", src_port.toString());

			}

			if (src_db_user != null) {

				this.setProperty("src_db_user", src_db_user.toString());

			}

			if (src_db_pass != null) {

				this.setProperty("src_db_pass", src_db_pass.toString());

			}

			if (src_additional_param != null) {

				this.setProperty("src_additional_param",
						src_additional_param.toString());

			}

			if (src_table_all_col != null) {

				this.setProperty("src_table_all_col",
						src_table_all_col.toString());

			}

			if (tgt_db_type != null) {

				this.setProperty("tgt_db_type", tgt_db_type.toString());

			}

			if (tgt_db_nme != null) {

				this.setProperty("tgt_db_nme", tgt_db_nme.toString());

			}

			if (tgt_db_schema != null) {

				this.setProperty("tgt_db_schema", tgt_db_schema.toString());

			}

			if (tgt_host != null) {

				this.setProperty("tgt_host", tgt_host.toString());

			}

			if (tgt_port != null) {

				this.setProperty("tgt_port", tgt_port.toString());

			}

			if (tgt_db_user != null) {

				this.setProperty("tgt_db_user", tgt_db_user.toString());

			}

			if (tgt_db_pass != null) {

				this.setProperty("tgt_db_pass", tgt_db_pass.toString());

			}

			if (tgt_additional_param != null) {

				this.setProperty("tgt_additional_param",
						tgt_additional_param.toString());

			}

			if (rules != null) {

				this.setProperty("rules", rules.toString());

			}

			if (src_sql != null) {

				this.setProperty("src_sql", src_sql.toString());

			}

			if (logfile != null) {

				this.setProperty("logfile", logfile.toString());

			}

			if (LogFileDir != null) {

				this.setProperty("LogFileDir", LogFileDir.toString());

			}

			if (file_param_execute != null) {

				this.setProperty("file_param_execute",
						file_param_execute.toString());

			}

			if (file_custom_sql_details != null) {

				this.setProperty("file_custom_sql_details",
						file_custom_sql_details.toString());

			}

			if (file_schema_connection_details != null) {

				this.setProperty("file_schema_connection_details",
						file_schema_connection_details.toString());

			}

			if (file_rule_details != null) {

				this.setProperty("file_rule_details",
						file_rule_details.toString());

			}

			if (metadata_host != null) {

				this.setProperty("metadata_host", metadata_host.toString());

			}

			if (metadata_port != null) {

				this.setProperty("metadata_port", metadata_port.toString());

			}

			if (metadata_db_schema != null) {

				this.setProperty("metadata_db_schema",
						metadata_db_schema.toString());

			}

			if (metadata_db_name != null) {

				this.setProperty("metadata_db_name",
						metadata_db_name.toString());

			}

			if (metadata_db_user != null) {

				this.setProperty("metadata_db_user",
						metadata_db_user.toString());

			}

			if (metadata_db_pass != null) {

				this.setProperty("metadata_db_pass",
						metadata_db_pass.toString());

			}

			if (file_ref_stat != null) {

				this.setProperty("file_ref_stat", file_ref_stat.toString());

			}

			if (properties_file_path != null) {

				this.setProperty("properties_file_path",
						properties_file_path.toString());

			}

		}

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String table_nme;

		public String getTable_nme() {
			return this.table_nme;
		}

		public String src_host;

		public String getSrc_host() {
			return this.src_host;
		}

		public String src_port;

		public String getSrc_port() {
			return this.src_port;
		}

		public String src_db_user;

		public String getSrc_db_user() {
			return this.src_db_user;
		}

		public String src_db_pass;

		public String getSrc_db_pass() {
			return this.src_db_pass;
		}

		public String src_additional_param;

		public String getSrc_additional_param() {
			return this.src_additional_param;
		}

		public String src_table_all_col;

		public String getSrc_table_all_col() {
			return this.src_table_all_col;
		}

		public String tgt_db_type;

		public String getTgt_db_type() {
			return this.tgt_db_type;
		}

		public String tgt_db_nme;

		public String getTgt_db_nme() {
			return this.tgt_db_nme;
		}

		public String tgt_db_schema;

		public String getTgt_db_schema() {
			return this.tgt_db_schema;
		}

		public String tgt_host;

		public String getTgt_host() {
			return this.tgt_host;
		}

		public String tgt_port;

		public String getTgt_port() {
			return this.tgt_port;
		}

		public String tgt_db_user;

		public String getTgt_db_user() {
			return this.tgt_db_user;
		}

		public String tgt_db_pass;

		public String getTgt_db_pass() {
			return this.tgt_db_pass;
		}

		public String tgt_additional_param;

		public String getTgt_additional_param() {
			return this.tgt_additional_param;
		}

		public String rules;

		public String getRules() {
			return this.rules;
		}

		public String src_sql;

		public String getSrc_sql() {
			return this.src_sql;
		}

		public String logfile;

		public String getLogfile() {
			return this.logfile;
		}

		public String LogFileDir;

		public String getLogFileDir() {
			return this.LogFileDir;
		}

		public String file_param_execute;

		public String getFile_param_execute() {
			return this.file_param_execute;
		}

		public String file_custom_sql_details;

		public String getFile_custom_sql_details() {
			return this.file_custom_sql_details;
		}

		public String file_schema_connection_details;

		public String getFile_schema_connection_details() {
			return this.file_schema_connection_details;
		}

		public String file_rule_details;

		public String getFile_rule_details() {
			return this.file_rule_details;
		}

		public String metadata_host;

		public String getMetadata_host() {
			return this.metadata_host;
		}

		public String metadata_port;

		public String getMetadata_port() {
			return this.metadata_port;
		}

		public String metadata_db_schema;

		public String getMetadata_db_schema() {
			return this.metadata_db_schema;
		}

		public String metadata_db_name;

		public String getMetadata_db_name() {
			return this.metadata_db_name;
		}

		public String metadata_db_user;

		public String getMetadata_db_user() {
			return this.metadata_db_user;
		}

		public java.lang.String metadata_db_pass;

		public java.lang.String getMetadata_db_pass() {
			return this.metadata_db_pass;
		}

		public String file_ref_stat;

		public String getFile_ref_stat() {
			return this.file_ref_stat;
		}

		public String properties_file_path;

		public String getProperties_file_path() {
			return this.properties_file_path;
		}
	}

	private ContextProperties context = new ContextProperties();

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Data_Masking";
	private final String projectName = "TALEND_3RDI_GIT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = java.util.Collections
			.synchronizedMap(new java.util.HashMap<String, Object>());

	private final java.util.Map<String, Long> start_Hash = java.util.Collections
			.synchronizedMap(new java.util.HashMap<String, Long>());
	private final java.util.Map<String, Long> end_Hash = java.util.Collections
			.synchronizedMap(new java.util.HashMap<String, Long>());
	private final java.util.Map<String, Boolean> ok_Hash = java.util.Collections
			.synchronizedMap(new java.util.HashMap<String, Boolean>());
	public final java.util.List<String[]> globalBuffer = java.util.Collections
			.synchronizedList(new java.util.ArrayList<String[]>());

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(
			java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources
				.entrySet()) {
			talendDataSources.put(
					dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry
							.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils(
			"_rO_-4P27Eea5H7tukcY4zg", "0.1");

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null
						&& currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE",
							getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE",
						getExceptionCauseMessage(e));
				System.err
						.println("Exception in component " + currentComponent);
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Data_Masking.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Data_Masking.this, new Object[] { e,
									currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						talendLogs_LOGS.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						talendLogs_LOGSProcess(globalMap);
					}
				} catch (TalendException e) {
					// do nothing

				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputExcel_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFlowToIterate_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void AST_rules_1_tJavaFlex_5_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlOutput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFixedFlowInput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tReplicate_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlOutput_2_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_11_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_11_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMSSqlInput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJavaRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPrejob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileTouch_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileTouch_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tParallelize_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tParallelize_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tRunJob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tRunJob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_8_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_8_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tRunJob_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tRunJob_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_9_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_9_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tRunJob_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tRunJob_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_10_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_10_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJava_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tJava_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPostjob_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tPostjob_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputRaw_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tReplace_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputRaw_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputRaw_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDenormalize_1_DenormalizeOut_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		tDenormalize_1_ArrayIn_error(exception, errorComponent, globalMap);

	}

	public void tDenormalize_1_ArrayIn_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		talendStats_STATS.addMessage("failure", errorComponent,
				end_Hash.get(errorComponent) - start_Hash.get(errorComponent));
		talendStats_STATSProcess(globalMap);

		((java.util.Map) threadLocal.get()).put("status", "failure");

		tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendLogs_LOGS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendLogs_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendLogs_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendStats_STATS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		talendStats_CONSOLE_error(exception, errorComponent, globalMap);

	}

	public void talendStats_CONSOLE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		((java.util.Map) threadLocal.get()).put("status", "failure");

		talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputExcel_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMSSqlInput_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_4_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFixedFlowInput_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_11_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMSSqlInput_4_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMSSqlInput_5_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tMSSqlInput_3_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPrejob_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_3_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileTouch_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tParallelize_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tRunJob_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_8_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tRunJob_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_9_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tRunJob_3_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_10_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tJava_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPostjob_2_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputRaw_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendLogs_LOGS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendStats_STATS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(),
				ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row10Struct implements
			routines.system.IPersistableRow<row10Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String col_rule;

		public String getCol_rule() {
			return this.col_rule;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.col_rule = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.col_rule, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("col_rule=" + col_rule);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (col_rule == null) {
				sb.append("<null>");
			} else {
				sb.append(col_rule);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row10Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtDenormalize_1 implements
			routines.system.IPersistableRow<OnRowsEndStructtDenormalize_1> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String col_rule;

		public String getCol_rule() {
			return this.col_rule;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.col_rule = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.col_rule, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("col_rule=" + col_rule);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (col_rule == null) {
				sb.append("<null>");
			} else {
				sb.append(col_rule);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtDenormalize_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out1Struct implements
			routines.system.IPersistableRow<out1Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String col_rule;

		public String getCol_rule() {
			return this.col_rule;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.col_rule = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.col_rule, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("col_rule=" + col_rule);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (col_rule == null) {
				sb.append("<null>");
			} else {
				sb.append(col_rule);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String table_nme;

		public String getTable_nme() {
			return this.table_nme;
		}

		public String col_nme;

		public String getCol_nme() {
			return this.col_nme;
		}

		public String rule_def;

		public String getRule_def() {
			return this.rule_def;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.src_db_type = readString(dis);

					this.src_db_nme = readString(dis);

					this.src_db_schema = readString(dis);

					this.table_nme = readString(dis);

					this.col_nme = readString(dis);

					this.rule_def = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.src_db_type, dos);

				// String

				writeString(this.src_db_nme, dos);

				// String

				writeString(this.src_db_schema, dos);

				// String

				writeString(this.table_nme, dos);

				// String

				writeString(this.col_nme, dos);

				// String

				writeString(this.rule_def, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("src_db_type=" + src_db_type);
			sb.append(",src_db_nme=" + src_db_nme);
			sb.append(",src_db_schema=" + src_db_schema);
			sb.append(",table_nme=" + table_nme);
			sb.append(",col_nme=" + col_nme);
			sb.append(",rule_def=" + rule_def);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (src_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_type);
			}

			sb.append("|");

			if (src_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_nme);
			}

			sb.append("|");

			if (src_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_schema);
			}

			sb.append("|");

			if (table_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(table_nme);
			}

			sb.append("|");

			if (col_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(col_nme);
			}

			sb.append("|");

			if (rule_def == null) {
				sb.append("<null>");
			} else {
				sb.append(rule_def);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row9Struct implements
			routines.system.IPersistableRow<row9Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String table_nme;

		public String getTable_nme() {
			return this.table_nme;
		}

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String tgt_db_type;

		public String getTgt_db_type() {
			return this.tgt_db_type;
		}

		public String tgt_db_nme;

		public String getTgt_db_nme() {
			return this.tgt_db_nme;
		}

		public String tgt_db_schema;

		public String getTgt_db_schema() {
			return this.tgt_db_schema;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.table_nme = readString(dis);

					this.src_db_type = readString(dis);

					this.src_db_nme = readString(dis);

					this.src_db_schema = readString(dis);

					this.tgt_db_type = readString(dis);

					this.tgt_db_nme = readString(dis);

					this.tgt_db_schema = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.table_nme, dos);

				// String

				writeString(this.src_db_type, dos);

				// String

				writeString(this.src_db_nme, dos);

				// String

				writeString(this.src_db_schema, dos);

				// String

				writeString(this.tgt_db_type, dos);

				// String

				writeString(this.tgt_db_nme, dos);

				// String

				writeString(this.tgt_db_schema, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("table_nme=" + table_nme);
			sb.append(",src_db_type=" + src_db_type);
			sb.append(",src_db_nme=" + src_db_nme);
			sb.append(",src_db_schema=" + src_db_schema);
			sb.append(",tgt_db_type=" + tgt_db_type);
			sb.append(",tgt_db_nme=" + tgt_db_nme);
			sb.append(",tgt_db_schema=" + tgt_db_schema);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (table_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(table_nme);
			}

			sb.append("|");

			if (src_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_type);
			}

			sb.append("|");

			if (src_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_nme);
			}

			sb.append("|");

			if (src_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_schema);
			}

			sb.append("|");

			if (tgt_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_type);
			}

			sb.append("|");

			if (tgt_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_nme);
			}

			sb.append("|");

			if (tgt_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_schema);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row9Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row8Struct implements
			routines.system.IPersistableRow<row8Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String table_nme;

		public String getTable_nme() {
			return this.table_nme;
		}

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String tgt_db_type;

		public String getTgt_db_type() {
			return this.tgt_db_type;
		}

		public String tgt_db_nme;

		public String getTgt_db_nme() {
			return this.tgt_db_nme;
		}

		public String tgt_db_schema;

		public String getTgt_db_schema() {
			return this.tgt_db_schema;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.table_nme = readString(dis);

					this.src_db_type = readString(dis);

					this.src_db_nme = readString(dis);

					this.src_db_schema = readString(dis);

					this.tgt_db_type = readString(dis);

					this.tgt_db_nme = readString(dis);

					this.tgt_db_schema = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.table_nme, dos);

				// String

				writeString(this.src_db_type, dos);

				// String

				writeString(this.src_db_nme, dos);

				// String

				writeString(this.src_db_schema, dos);

				// String

				writeString(this.tgt_db_type, dos);

				// String

				writeString(this.tgt_db_nme, dos);

				// String

				writeString(this.tgt_db_schema, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("table_nme=" + table_nme);
			sb.append(",src_db_type=" + src_db_type);
			sb.append(",src_db_nme=" + src_db_nme);
			sb.append(",src_db_schema=" + src_db_schema);
			sb.append(",tgt_db_type=" + tgt_db_type);
			sb.append(",tgt_db_nme=" + tgt_db_nme);
			sb.append(",tgt_db_schema=" + tgt_db_schema);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (table_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(table_nme);
			}

			sb.append("|");

			if (src_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_type);
			}

			sb.append("|");

			if (src_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_nme);
			}

			sb.append("|");

			if (src_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_schema);
			}

			sb.append("|");

			if (tgt_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_type);
			}

			sb.append("|");

			if (tgt_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_nme);
			}

			sb.append("|");

			if (tgt_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(tgt_db_schema);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row8Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputExcel_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row8Struct row8 = new row8Struct();
				row9Struct row9 = new row9Struct();
				row1Struct row1 = new row1Struct();
				out1Struct out1 = new out1Struct();
				row10Struct row10 = new row10Struct();

				/**
				 * [tFlowToIterate_1 begin ] start
				 */

				int NB_ITERATE_tMSSqlInput_2 = 0; // for statistics

				ok_Hash.put("tFlowToIterate_1", false);
				start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tFlowToIterate_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tFlowToIterate_1";

				int tos_count_tFlowToIterate_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFlowToIterate_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
				log4jParamters_tFlowToIterate_1.append("Parameters:");
				log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = "
						+ "true");
				log4jParamters_tFlowToIterate_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFlowToIterate_1 - "
							+ log4jParamters_tFlowToIterate_1);

				int nb_line_tFlowToIterate_1 = 0;
				int counter_tFlowToIterate_1 = 0;

				/**
				 * [tFlowToIterate_1 begin ] stop
				 */

				/**
				 * [tJavaRow_3 begin ] start
				 */

				ok_Hash.put("tJavaRow_3", false);
				start_Hash.put("tJavaRow_3", System.currentTimeMillis());

				currentComponent = "tJavaRow_3";

				int tos_count_tJavaRow_3 = 0;

				int nb_line_tJavaRow_3 = 0;

				/**
				 * [tJavaRow_3 begin ] stop
				 */

				/**
				 * [tFileInputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileInputExcel_1", false);
				start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tFileInputExcel_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tFileInputExcel_1";

				int tos_count_tFileInputExcel_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
				log4jParamters_tFileInputExcel_1.append("Parameters:");
				log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = "
						+ "true");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FILENAME" + " = "
						+ "context.file_param_execute");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = "
						+ "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("SHEETLIST" + " = "
						+ "[{USE_REGEX=" + ("false") + ", SHEETNAME="
						+ ("\"Sheet1\"") + "}]");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = "
						+ "1");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = "
						+ "");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = "
						+ "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("TRIMSELECT" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("table_nme") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("src_db_type") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("src_db_nme")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("src_db_schema") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("tgt_db_type") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("tgt_db_nme")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("tgt_db_schema") + "}]");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("CONVERTDATETOSTRING"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW"
						+ " = " + "false");
				log4jParamters_tFileInputExcel_1.append(" | ");
				log4jParamters_tFileInputExcel_1.append("GENERATION_MODE"
						+ " = " + "USER_MODE");
				log4jParamters_tFileInputExcel_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - "
							+ log4jParamters_tFileInputExcel_1);

				class RegexUtil_tFileInputExcel_1 {

					public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(
							org.apache.poi.xssf.usermodel.XSSFWorkbook workbook,
							String oneSheetName, boolean useRegex) {

						java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();

						if (useRegex) {// this part process the regex issue

							java.util.regex.Pattern pattern = java.util.regex.Pattern
									.compile(oneSheetName);
							for (org.apache.poi.xssf.usermodel.XSSFSheet sheet : workbook) {
								String sheetName = sheet.getSheetName();
								java.util.regex.Matcher matcher = pattern
										.matcher(sheetName);
								if (matcher.matches()) {
									if (sheet != null) {
										list.add(sheet);
									}
								}
							}

						} else {
							org.apache.poi.xssf.usermodel.XSSFSheet sheet = workbook
									.getSheet(oneSheetName);
							if (sheet != null) {
								list.add(sheet);
							}

						}

						return list;
					}

					public java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> getSheets(
							org.apache.poi.xssf.usermodel.XSSFWorkbook workbook,
							int index, boolean useRegex) {
						java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> list = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
						org.apache.poi.xssf.usermodel.XSSFSheet sheet = workbook
								.getSheetAt(index);
						if (sheet != null) {
							list.add(sheet);
						}
						return list;
					}

				}
				RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();

				Object source_tFileInputExcel_1 = context.file_param_execute;
				org.apache.poi.xssf.usermodel.XSSFWorkbook workbook_tFileInputExcel_1 = null;

				if (source_tFileInputExcel_1 instanceof String) {
					workbook_tFileInputExcel_1 = new org.apache.poi.xssf.usermodel.XSSFWorkbook(
							(String) source_tFileInputExcel_1);
				} else if (source_tFileInputExcel_1 instanceof java.io.InputStream) {
					workbook_tFileInputExcel_1 = new org.apache.poi.xssf.usermodel.XSSFWorkbook(
							(java.io.InputStream) source_tFileInputExcel_1);
				} else {
					workbook_tFileInputExcel_1 = null;
					throw new java.lang.Exception(
							"The data source should be specified as Inputstream or File Path!");
				}
				try {

					java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
					sheetList_tFileInputExcel_1
							.addAll(regexUtil_tFileInputExcel_1
									.getSheets(workbook_tFileInputExcel_1,
											"Sheet1", false));
					if (sheetList_tFileInputExcel_1.size() <= 0) {
						throw new RuntimeException("Special sheets not exist!");
					}

					java.util.List<org.apache.poi.xssf.usermodel.XSSFSheet> sheetList_FilterNull_tFileInputExcel_1 = new java.util.ArrayList<org.apache.poi.xssf.usermodel.XSSFSheet>();
					for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
						if (sheet_FilterNull_tFileInputExcel_1 != null
								&& sheetList_FilterNull_tFileInputExcel_1
										.iterator() != null
								&& sheet_FilterNull_tFileInputExcel_1
										.iterator().hasNext()) {
							sheetList_FilterNull_tFileInputExcel_1
									.add(sheet_FilterNull_tFileInputExcel_1);
						}
					}
					sheetList_tFileInputExcel_1 = sheetList_FilterNull_tFileInputExcel_1;
					if (sheetList_tFileInputExcel_1.size() > 0) {
						int nb_line_tFileInputExcel_1 = 0;

						int begin_line_tFileInputExcel_1 = 1;

						int footer_input_tFileInputExcel_1 = 0;

						int end_line_tFileInputExcel_1 = 0;
						for (org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 : sheetList_tFileInputExcel_1) {
							end_line_tFileInputExcel_1 += (sheet_tFileInputExcel_1
									.getLastRowNum() + 1);
						}
						end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
						int limit_tFileInputExcel_1 = -1;
						int start_column_tFileInputExcel_1 = 1 - 1;
						int end_column_tFileInputExcel_1 = -1;

						org.apache.poi.xssf.usermodel.XSSFRow row_tFileInputExcel_1 = null;
						org.apache.poi.xssf.usermodel.XSSFSheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
								.get(0);
						int rowCount_tFileInputExcel_1 = 0;
						int sheetIndex_tFileInputExcel_1 = 0;
						int currentRows_tFileInputExcel_1 = (sheetList_tFileInputExcel_1
								.get(0).getLastRowNum() + 1);

						// for the number format
						java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat(
								"#.####################################");
						char decimalChar_tFileInputExcel_1 = df_tFileInputExcel_1
								.getDecimalFormatSymbols()
								.getDecimalSeparator();
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");

						for (int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++) {

							int emptyColumnCount_tFileInputExcel_1 = 0;

							if (limit_tFileInputExcel_1 != -1
									&& nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
								break;
							}

							while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1
									+ currentRows_tFileInputExcel_1) {
								rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
								sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1
										.get(++sheetIndex_tFileInputExcel_1);
								currentRows_tFileInputExcel_1 = (sheet_tFileInputExcel_1
										.getLastRowNum() + 1);
							}
							globalMap.put("tFileInputExcel_1_CURRENT_SHEET",
									sheet_tFileInputExcel_1.getSheetName());
							if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
								row_tFileInputExcel_1 = sheet_tFileInputExcel_1
										.getRow(i_tFileInputExcel_1
												- rowCount_tFileInputExcel_1);
							}
							row8 = null;
							int tempRowLength_tFileInputExcel_1 = 7;

							int columnIndex_tFileInputExcel_1 = 0;

							String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
							int excel_end_column_tFileInputExcel_1;
							if (row_tFileInputExcel_1 == null) {
								excel_end_column_tFileInputExcel_1 = 0;
							} else {
								excel_end_column_tFileInputExcel_1 = row_tFileInputExcel_1
										.getLastCellNum();
							}
							int actual_end_column_tFileInputExcel_1;
							if (end_column_tFileInputExcel_1 == -1) {
								actual_end_column_tFileInputExcel_1 = excel_end_column_tFileInputExcel_1;
							} else {
								actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 > excel_end_column_tFileInputExcel_1 ? excel_end_column_tFileInputExcel_1
										: end_column_tFileInputExcel_1;
							}
							org.apache.poi.ss.formula.eval.NumberEval ne_tFileInputExcel_1 = null;
							for (int i = 0; i < tempRowLength_tFileInputExcel_1; i++) {
								if (i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1) {
									org.apache.poi.ss.usermodel.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1
											.getCell(i
													+ start_column_tFileInputExcel_1);
									if (cell_tFileInputExcel_1 != null) {
										switch (cell_tFileInputExcel_1
												.getCellType()) {
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
											temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
													.getRichStringCellValue()
													.getString();
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
											if (org.apache.poi.ss.usermodel.DateUtil
													.isCellDateFormatted(cell_tFileInputExcel_1)) {
												temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
														.getDateCellValue()
														.toString();
											} else {
												temp_row_tFileInputExcel_1[i] = df_tFileInputExcel_1
														.format(cell_tFileInputExcel_1
																.getNumericCellValue());
											}
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BOOLEAN:
											temp_row_tFileInputExcel_1[i] = String
													.valueOf(cell_tFileInputExcel_1
															.getBooleanCellValue());
											break;
										case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_FORMULA:
											switch (cell_tFileInputExcel_1
													.getCachedFormulaResultType()) {
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
												temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
														.getRichStringCellValue()
														.getString();
												break;
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
												if (org.apache.poi.ss.usermodel.DateUtil
														.isCellDateFormatted(cell_tFileInputExcel_1)) {
													temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1
															.getDateCellValue()
															.toString();
												} else {
													ne_tFileInputExcel_1 = new org.apache.poi.ss.formula.eval.NumberEval(
															cell_tFileInputExcel_1
																	.getNumericCellValue());
													temp_row_tFileInputExcel_1[i] = ne_tFileInputExcel_1
															.getStringValue();
												}
												break;
											case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BOOLEAN:
												temp_row_tFileInputExcel_1[i] = String
														.valueOf(cell_tFileInputExcel_1
																.getBooleanCellValue());
												break;
											default:
												temp_row_tFileInputExcel_1[i] = "";
											}
											break;
										default:
											temp_row_tFileInputExcel_1[i] = "";
										}
									} else {
										temp_row_tFileInputExcel_1[i] = "";
									}

								} else {
									temp_row_tFileInputExcel_1[i] = "";
								}
							}
							boolean whetherReject_tFileInputExcel_1 = false;
							row8 = new row8Struct();
							int curColNum_tFileInputExcel_1 = -1;
							String curColName_tFileInputExcel_1 = "";
							try {
								columnIndex_tFileInputExcel_1 = 0;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "table_nme";

									row8.table_nme = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.table_nme = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 1;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "src_db_type";

									row8.src_db_type = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.src_db_type = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 2;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "src_db_nme";

									row8.src_db_nme = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.src_db_nme = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 3;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "src_db_schema";

									row8.src_db_schema = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.src_db_schema = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 4;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "tgt_db_type";

									row8.tgt_db_type = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.tgt_db_type = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 5;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "tgt_db_nme";

									row8.tgt_db_nme = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.tgt_db_nme = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								columnIndex_tFileInputExcel_1 = 6;

								if (temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1]
										.length() > 0) {
									curColNum_tFileInputExcel_1 = columnIndex_tFileInputExcel_1
											+ start_column_tFileInputExcel_1
											+ 1;
									curColName_tFileInputExcel_1 = "tgt_db_schema";

									row8.tgt_db_schema = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
								} else {
									row8.tgt_db_schema = null;
									emptyColumnCount_tFileInputExcel_1++;
								}
								nb_line_tFileInputExcel_1++;

								log.debug("tFileInputExcel_1 - Retrieving the record "
										+ (nb_line_tFileInputExcel_1) + ".");

							} catch (java.lang.Exception e) {
								whetherReject_tFileInputExcel_1 = true;
								log.error("tFileInputExcel_1 - "
										+ e.getMessage());

								System.err.println(e.getMessage());
								row8 = null;
							}

							/**
							 * [tFileInputExcel_1 begin ] stop
							 */

							/**
							 * [tFileInputExcel_1 main ] start
							 */

							currentComponent = "tFileInputExcel_1";

							tos_count_tFileInputExcel_1++;

							/**
							 * [tFileInputExcel_1 main ] stop
							 */
							// Start of branch "row8"
							if (row8 != null) {

								/**
								 * [tJavaRow_3 main ] start
								 */

								currentComponent = "tJavaRow_3";

								if (log.isTraceEnabled()) {
									log.trace("row8 - "
											+ (row8 == null ? "" : row8
													.toLogString()));
								}

								// Code generated according to input schema and
								// output schema

								row9.table_nme = row8.table_nme;
								row9.src_db_type = row8.src_db_type;
								row9.src_db_nme = row8.src_db_nme;
								row9.src_db_schema = row8.src_db_schema;
								row9.tgt_db_type = row8.tgt_db_type;
								row9.tgt_db_nme = row8.tgt_db_nme;
								row9.tgt_db_schema = row8.tgt_db_schema;

								context.table_nme = row8.table_nme;
								context.src_db_type = row8.src_db_type;
								context.src_db_nme = row8.src_db_nme;
								context.src_db_schema = row8.src_db_schema;
								context.tgt_db_type = row8.tgt_db_type;
								context.tgt_db_nme = row8.tgt_db_nme;
								context.tgt_db_schema = row8.tgt_db_schema;

								Numeric.resetSequence("cnt", 0);

								System.out
										.println(TalendDate
												.getDate("yyyy-MM-dd HH:mm:ss")
												+ "|********** Data Masking Started For the Table: "
												+ row8.table_nme
												+ " **********");
								nb_line_tJavaRow_3++;

								tos_count_tJavaRow_3++;

								/**
								 * [tJavaRow_3 main ] stop
								 */

								/**
								 * [tFlowToIterate_1 main ] start
								 */

								currentComponent = "tFlowToIterate_1";

								if (log.isTraceEnabled()) {
									log.trace("row9 - "
											+ (row9 == null ? "" : row9
													.toLogString()));
								}

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.table_nme, value="
											+ row9.table_nme + ".");
								globalMap.put("row9.table_nme", row9.table_nme);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.src_db_type, value="
											+ row9.src_db_type + ".");
								globalMap.put("row9.src_db_type",
										row9.src_db_type);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.src_db_nme, value="
											+ row9.src_db_nme + ".");
								globalMap.put("row9.src_db_nme",
										row9.src_db_nme);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.src_db_schema, value="
											+ row9.src_db_schema + ".");
								globalMap.put("row9.src_db_schema",
										row9.src_db_schema);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.tgt_db_type, value="
											+ row9.tgt_db_type + ".");
								globalMap.put("row9.tgt_db_type",
										row9.tgt_db_type);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.tgt_db_nme, value="
											+ row9.tgt_db_nme + ".");
								globalMap.put("row9.tgt_db_nme",
										row9.tgt_db_nme);
								nb_line_tFlowToIterate_1++;

								if (log.isTraceEnabled())
									log.trace("tFlowToIterate_1 - "
											+ "Set global var, key=row9.tgt_db_schema, value="
											+ row9.tgt_db_schema + ".");
								globalMap.put("row9.tgt_db_schema",
										row9.tgt_db_schema);
								nb_line_tFlowToIterate_1++;

								counter_tFlowToIterate_1++;
								if (log.isDebugEnabled())
									log.debug("tFlowToIterate_1 - "
											+ "Current iteration is: "
											+ counter_tFlowToIterate_1 + ".");
								globalMap.put(
										"tFlowToIterate_1_CURRENT_ITERATION",
										counter_tFlowToIterate_1);

								tos_count_tFlowToIterate_1++;

								/**
								 * [tFlowToIterate_1 main ] stop
								 */
								NB_ITERATE_tMSSqlInput_2++;

								/**
								 * [tDenormalize_1_DenormalizeOut begin ] start
								 */

								ok_Hash.put("tDenormalize_1_DenormalizeOut",
										false);
								start_Hash.put("tDenormalize_1_DenormalizeOut",
										System.currentTimeMillis());

								talendStats_STATS.addMessage("begin",
										"tDenormalize_1_DenormalizeOut");
								talendStats_STATSProcess(globalMap);

								currentVirtualComponent = "tDenormalize_1";

								currentComponent = "tDenormalize_1_DenormalizeOut";

								int tos_count_tDenormalize_1_DenormalizeOut = 0;

								if (log.isDebugEnabled())
									log.debug("tDenormalize_1_DenormalizeOut - "
											+ "Start to work.");
								StringBuilder log4jParamters_tDenormalize_1_DenormalizeOut = new StringBuilder();
								log4jParamters_tDenormalize_1_DenormalizeOut
										.append("Parameters:");
								log4jParamters_tDenormalize_1_DenormalizeOut
										.append("DESTINATION" + " = "
												+ "tDenormalize_1");
								log4jParamters_tDenormalize_1_DenormalizeOut
										.append(" | ");
								log4jParamters_tDenormalize_1_DenormalizeOut
										.append("DENORMALIZE_COLUMNS" + " = "
												+ "[{MERGE=" + ("true")
												+ ", INPUT_COLUMN="
												+ ("col_rule") + ", DELIMITER="
												+ ("\"~\"") + "}]");
								log4jParamters_tDenormalize_1_DenormalizeOut
										.append(" | ");
								if (log.isDebugEnabled())
									log.debug("tDenormalize_1_DenormalizeOut - "
											+ log4jParamters_tDenormalize_1_DenormalizeOut);

								class DenormalizeStructtDenormalize_1_DenormalizeOut {
									java.util.List<String> col_rule = new java.util.ArrayList<String>();
								}
								DenormalizeStructtDenormalize_1_DenormalizeOut denormalize_result_tDenormalize_1_DenormalizeOut = null;

								/**
								 * [tDenormalize_1_DenormalizeOut begin ] stop
								 */

								/**
								 * [tMap_2 begin ] start
								 */

								ok_Hash.put("tMap_2", false);
								start_Hash.put("tMap_2",
										System.currentTimeMillis());

								currentComponent = "tMap_2";

								int tos_count_tMap_2 = 0;

								if (log.isDebugEnabled())
									log.debug("tMap_2 - " + "Start to work.");
								StringBuilder log4jParamters_tMap_2 = new StringBuilder();
								log4jParamters_tMap_2.append("Parameters:");
								log4jParamters_tMap_2.append("LINK_STYLE"
										+ " = " + "AUTO");
								log4jParamters_tMap_2.append(" | ");
								log4jParamters_tMap_2
										.append("TEMPORARY_DATA_DIRECTORY"
												+ " = " + "");
								log4jParamters_tMap_2.append(" | ");
								log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE"
										+ " = " + "2000000");
								log4jParamters_tMap_2.append(" | ");
								log4jParamters_tMap_2
										.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL"
												+ " = " + "false");
								log4jParamters_tMap_2.append(" | ");
								if (log.isDebugEnabled())
									log.debug("tMap_2 - "
											+ log4jParamters_tMap_2);

								// ###############################
								// # Lookup's keys initialization
								int count_row1_tMap_2 = 0;

								// ###############################

								// ###############################
								// # Vars initialization
								class Var__tMap_2__Struct {
								}
								Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
								// ###############################

								// ###############################
								// # Outputs initialization
								int count_out1_tMap_2 = 0;

								out1Struct out1_tmp = new out1Struct();
								// ###############################

								/**
								 * [tMap_2 begin ] stop
								 */

								/**
								 * [tMSSqlInput_2 begin ] start
								 */

								ok_Hash.put("tMSSqlInput_2", false);
								start_Hash.put("tMSSqlInput_2",
										System.currentTimeMillis());

								talendStats_STATS.addMessage("begin",
										"tMSSqlInput_2");
								talendStats_STATSProcess(globalMap);

								currentComponent = "tMSSqlInput_2";

								int tos_count_tMSSqlInput_2 = 0;

								if (log.isDebugEnabled())
									log.debug("tMSSqlInput_2 - "
											+ "Start to work.");
								StringBuilder log4jParamters_tMSSqlInput_2 = new StringBuilder();
								log4jParamters_tMSSqlInput_2
										.append("Parameters:");
								log4jParamters_tMSSqlInput_2
										.append("USE_EXISTING_CONNECTION"
												+ " = " + "false");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("HOST"
										+ " = " + "context.metadata_host");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("PORT"
										+ " = " + "context.metadata_port");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("DB_SCHEMA"
										+ " = " + "context.metadata_db_schema");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("DBNAME"
										+ " = " + "context.metadata_db_name");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("USER"
										+ " = " + "context.metadata_db_user");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("PASS"
												+ " = "
												+ String.valueOf(
														routines.system.PasswordEncryptUtil
																.encryptPassword(context.metadata_db_pass))
														.substring(0, 4)
												+ "...");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2.append("TABLE"
										+ " = " + "\"rule_details\"");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("QUERYSTORE" + " = " + "\"\"");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("QUERY"
												+ " = "
												+ "\"SELECT src_db_type,  		src_db_nme,  		src_db_schema,  		table_nme,  		col_nme,  		rule_def,  		active  FROM	rule_details  where active=1 and src_db_type=\"+\"\\'\"+context.src_db_type+\"\\'\"+\" and \"+\"src_db_nme=\"+\"\\'\"+context.src_db_nme+\"\\'\"+\" and \"+\"src_db_schema=\"+\"\\'\"+context.src_db_schema+\"\\'\"+\" and \"+\"table_nme=\"+\"\\'\"+context.table_nme+\"\\'\"");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("SPECIFY_DATASOURCE_ALIAS"
												+ " = " + "false");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("PROPERTIES" + " = " + "\"\"");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("TRIM_ALL_COLUMN" + " = "
												+ "false");
								log4jParamters_tMSSqlInput_2.append(" | ");
								log4jParamters_tMSSqlInput_2
										.append("TRIM_COLUMN" + " = "
												+ "[{TRIM=" + ("false")
												+ ", SCHEMA_COLUMN="
												+ ("src_db_type") + "}, {TRIM="
												+ ("false")
												+ ", SCHEMA_COLUMN="
												+ ("src_db_nme") + "}, {TRIM="
												+ ("false")
												+ ", SCHEMA_COLUMN="
												+ ("src_db_schema")
												+ "}, {TRIM=" + ("false")
												+ ", SCHEMA_COLUMN="
												+ ("table_nme") + "}, {TRIM="
												+ ("false")
												+ ", SCHEMA_COLUMN="
												+ ("col_nme") + "}, {TRIM="
												+ ("false")
												+ ", SCHEMA_COLUMN="
												+ ("rule_def") + "}, {TRIM="
												+ ("false")
												+ ", SCHEMA_COLUMN="
												+ ("active") + "}]");
								log4jParamters_tMSSqlInput_2.append(" | ");
								if (log.isDebugEnabled())
									log.debug("tMSSqlInput_2 - "
											+ log4jParamters_tMSSqlInput_2);

								org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
										.getMSSqlGenerateTimestampUtil();

								java.util.List<String> talendToDBList_tMSSqlInput_2 = new java.util.ArrayList();
								String[] talendToDBArray_tMSSqlInput_2 = new String[] {
										"FLOAT", "NUMERIC", "NUMERIC IDENTITY",
										"DECIMAL", "DECIMAL IDENTITY", "REAL" };
								java.util.Collections.addAll(
										talendToDBList_tMSSqlInput_2,
										talendToDBArray_tMSSqlInput_2);
								int nb_line_tMSSqlInput_2 = 0;
								java.sql.Connection conn_tMSSqlInput_2 = null;
								String driverClass_tMSSqlInput_2 = "net.sourceforge.jtds.jdbc.Driver";
								java.lang.Class
										.forName(driverClass_tMSSqlInput_2);
								String dbUser_tMSSqlInput_2 = context.metadata_db_user;

								final String decryptedPassword_tMSSqlInput_2 = context.metadata_db_pass;

								String dbPwd_tMSSqlInput_2 = decryptedPassword_tMSSqlInput_2;

								String port_tMSSqlInput_2 = context.metadata_port;
								String dbname_tMSSqlInput_2 = context.metadata_db_name;
								String url_tMSSqlInput_2 = "jdbc:jtds:sqlserver://"
										+ context.metadata_host;
								if (!"".equals(port_tMSSqlInput_2)) {
									url_tMSSqlInput_2 += ":"
											+ context.metadata_port;
								}
								if (!"".equals(dbname_tMSSqlInput_2)) {
									url_tMSSqlInput_2 += "//"
											+ context.metadata_db_name;
								}
								url_tMSSqlInput_2 += ";appName=" + projectName
										+ ";" + "";
								String dbschema_tMSSqlInput_2 = context.metadata_db_schema;

								log.debug("tMSSqlInput_2 - Driver ClassName: "
										+ driverClass_tMSSqlInput_2 + ".");

								log.debug("tMSSqlInput_2 - Connection attempt to '"
										+ url_tMSSqlInput_2
										+ "' with the username '"
										+ dbUser_tMSSqlInput_2 + "'.");

								conn_tMSSqlInput_2 = java.sql.DriverManager
										.getConnection(url_tMSSqlInput_2,
												dbUser_tMSSqlInput_2,
												dbPwd_tMSSqlInput_2);
								log.debug("tMSSqlInput_2 - Connection to '"
										+ url_tMSSqlInput_2
										+ "' has succeeded.");

								java.sql.Statement stmt_tMSSqlInput_2 = conn_tMSSqlInput_2
										.createStatement();

								String dbquery_tMSSqlInput_2 = "SELECT src_db_type,\n		src_db_nme,\n		src_db_schema,\n		table_nme,\n		col_nme,\n		rule_def,\n		active\nFROM	rule_details\nwhere active=1 and src_db_type="
										+ "\'"
										+ context.src_db_type
										+ "\'"
										+ " and "
										+ "src_db_nme="
										+ "\'"
										+ context.src_db_nme
										+ "\'"
										+ " and "
										+ "src_db_schema="
										+ "\'"
										+ context.src_db_schema
										+ "\'"
										+ " and "
										+ "table_nme="
										+ "\'"
										+ context.table_nme + "\'";

								log.debug("tMSSqlInput_2 - Executing the query: '"
										+ dbquery_tMSSqlInput_2 + "'.");

								globalMap.put("tMSSqlInput_2_QUERY",
										dbquery_tMSSqlInput_2);

								java.sql.ResultSet rs_tMSSqlInput_2 = null;
								try {
									rs_tMSSqlInput_2 = stmt_tMSSqlInput_2
											.executeQuery(dbquery_tMSSqlInput_2);
									java.sql.ResultSetMetaData rsmd_tMSSqlInput_2 = rs_tMSSqlInput_2
											.getMetaData();
									int colQtyInRs_tMSSqlInput_2 = rsmd_tMSSqlInput_2
											.getColumnCount();

									String tmpContent_tMSSqlInput_2 = null;

									log.debug("tMSSqlInput_2 - Retrieving records from the database.");

									while (rs_tMSSqlInput_2.next()) {
										nb_line_tMSSqlInput_2++;

										if (colQtyInRs_tMSSqlInput_2 < 1) {
											row1.src_db_type = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(1);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		1)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.src_db_type = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.src_db_type = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.src_db_type = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 2) {
											row1.src_db_nme = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(2);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		2)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.src_db_nme = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.src_db_nme = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.src_db_nme = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 3) {
											row1.src_db_schema = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(3);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		3)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.src_db_schema = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.src_db_schema = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.src_db_schema = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 4) {
											row1.table_nme = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(4);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		4)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.table_nme = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.table_nme = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.table_nme = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 5) {
											row1.col_nme = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(5);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		5)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.col_nme = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.col_nme = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.col_nme = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 6) {
											row1.rule_def = null;
										} else {

											tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2
													.getString(6);
											if (tmpContent_tMSSqlInput_2 != null) {
												if (talendToDBList_tMSSqlInput_2
														.contains(rsmd_tMSSqlInput_2
																.getColumnTypeName(
																		6)
																.toUpperCase(
																		java.util.Locale.ENGLISH))) {
													row1.rule_def = FormatterUtils
															.formatUnwithE(tmpContent_tMSSqlInput_2);
												} else {
													row1.rule_def = tmpContent_tMSSqlInput_2;
												}
											} else {
												row1.rule_def = null;
											}
										}
										if (colQtyInRs_tMSSqlInput_2 < 7) {
											row1.active = null;
										} else {

											if (rs_tMSSqlInput_2.getObject(7) != null) {
												row1.active = rs_tMSSqlInput_2
														.getInt(7);
											} else {
												row1.active = null;
											}
										}

										log.debug("tMSSqlInput_2 - Retrieving the record "
												+ nb_line_tMSSqlInput_2 + ".");

										/**
										 * [tMSSqlInput_2 begin ] stop
										 */

										/**
										 * [tMSSqlInput_2 main ] start
										 */

										currentComponent = "tMSSqlInput_2";

										tos_count_tMSSqlInput_2++;

										/**
										 * [tMSSqlInput_2 main ] stop
										 */

										/**
										 * [tMap_2 main ] start
										 */

										currentComponent = "tMap_2";

										if (log.isTraceEnabled()) {
											log.trace("row1 - "
													+ (row1 == null ? "" : row1
															.toLogString()));
										}

										boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

										// ###############################
										// # Input tables (lookups)
										boolean rejectedInnerJoin_tMap_2 = false;
										boolean mainRowRejected_tMap_2 = false;

										// ###############################
										{ // start of Var scope

											// ###############################
											// # Vars tables

											Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
											// ###############################
											// # Output tables

											out1 = null;

											// # Output table : 'out1'
											count_out1_tMap_2++;

											out1_tmp.col_rule = row1.col_nme
													+ "%" + row1.rule_def;
											out1 = out1_tmp;
											log.debug("tMap_2 - Outputting the record "
													+ count_out1_tMap_2
													+ " of the output table 'out1'.");

											// ###############################

										} // end of Var scope

										rejectedInnerJoin_tMap_2 = false;

										tos_count_tMap_2++;

										/**
										 * [tMap_2 main ] stop
										 */
										// Start of branch "out1"
										if (out1 != null) {

											/**
											 * [tDenormalize_1_DenormalizeOut
											 * main ] start
											 */

											currentVirtualComponent = "tDenormalize_1";

											currentComponent = "tDenormalize_1_DenormalizeOut";

											if (log.isTraceEnabled()) {
												log.trace("out1 - "
														+ (out1 == null ? ""
																: out1.toLogString()));
											}

											if (denormalize_result_tDenormalize_1_DenormalizeOut == null) {
												denormalize_result_tDenormalize_1_DenormalizeOut = new DenormalizeStructtDenormalize_1_DenormalizeOut();
												if (!denormalize_result_tDenormalize_1_DenormalizeOut.col_rule
														.contains(out1.col_rule)) {
													denormalize_result_tDenormalize_1_DenormalizeOut.col_rule
															.add(out1.col_rule);
												}
											} else {
												if (!denormalize_result_tDenormalize_1_DenormalizeOut.col_rule
														.contains(out1.col_rule)) {
													denormalize_result_tDenormalize_1_DenormalizeOut.col_rule
															.add(out1.col_rule);
												}
											}

											tos_count_tDenormalize_1_DenormalizeOut++;

											/**
											 * [tDenormalize_1_DenormalizeOut
											 * main ] stop
											 */

										} // End of branch "out1"

										/**
										 * [tMSSqlInput_2 end ] start
										 */

										currentComponent = "tMSSqlInput_2";

									}
								} finally {
									stmt_tMSSqlInput_2.close();

									if (conn_tMSSqlInput_2 != null
											&& !conn_tMSSqlInput_2.isClosed()) {

										log.debug("tMSSqlInput_2 - Closing the connection to the database.");

										conn_tMSSqlInput_2.close();

										log.debug("tMSSqlInput_2 - Connection to the database closed.");

									}
								}
								globalMap.put("tMSSqlInput_2_NB_LINE",
										nb_line_tMSSqlInput_2);
								log.debug("tMSSqlInput_2 - Retrieved records count: "
										+ nb_line_tMSSqlInput_2 + " .");

								if (log.isDebugEnabled())
									log.debug("tMSSqlInput_2 - " + "Done.");

								ok_Hash.put("tMSSqlInput_2", true);
								end_Hash.put("tMSSqlInput_2",
										System.currentTimeMillis());

								talendStats_STATS.addMessage(
										"end",
										"tMSSqlInput_2",
										end_Hash.get("tMSSqlInput_2")
												- start_Hash
														.get("tMSSqlInput_2"));
								talendStats_STATSProcess(globalMap);
								tMSSqlInput_4Process(globalMap);
								tMSSqlInput_5Process(globalMap);
								tMSSqlInput_3Process(globalMap);

								/**
								 * [tMSSqlInput_2 end ] stop
								 */

								/**
								 * [tMap_2 end ] start
								 */

								currentComponent = "tMap_2";

								// ###############################
								// # Lookup hashes releasing
								// ###############################
								log.debug("tMap_2 - Written records count in the table 'out1': "
										+ count_out1_tMap_2 + ".");

								if (log.isDebugEnabled())
									log.debug("tMap_2 - " + "Done.");

								ok_Hash.put("tMap_2", true);
								end_Hash.put("tMap_2",
										System.currentTimeMillis());

								/**
								 * [tMap_2 end ] stop
								 */

								/**
								 * [tDenormalize_1_DenormalizeOut end ] start
								 */

								currentVirtualComponent = "tDenormalize_1";

								currentComponent = "tDenormalize_1_DenormalizeOut";

								java.util.List<OnRowsEndStructtDenormalize_1> result_list_tDenormalize_1_DenormalizeOut = new java.util.ArrayList<OnRowsEndStructtDenormalize_1>();
								if (denormalize_result_tDenormalize_1_DenormalizeOut != null) {
									StringBuilder sb_tDenormalize_1_DenormalizeOut = null;

									// generate result begin
									OnRowsEndStructtDenormalize_1 denormalize_row_tDenormalize_1_DenormalizeOut = new OnRowsEndStructtDenormalize_1();

									for (String temp_tDenormalize_1_DenormalizeOut : denormalize_result_tDenormalize_1_DenormalizeOut.col_rule) {

										if (sb_tDenormalize_1_DenormalizeOut == null) {

											sb_tDenormalize_1_DenormalizeOut = new StringBuilder();
											sb_tDenormalize_1_DenormalizeOut
													.append(temp_tDenormalize_1_DenormalizeOut);

										} else {
											sb_tDenormalize_1_DenormalizeOut
													.append("~")
													.append(temp_tDenormalize_1_DenormalizeOut);

										}

									}

									denormalize_row_tDenormalize_1_DenormalizeOut.col_rule = sb_tDenormalize_1_DenormalizeOut
											.toString();

									sb_tDenormalize_1_DenormalizeOut = null;

									// in the deepest end

									result_list_tDenormalize_1_DenormalizeOut
											.add(denormalize_row_tDenormalize_1_DenormalizeOut);

								}
								// generate result end
								globalMap
										.put("tDenormalize_1",
												result_list_tDenormalize_1_DenormalizeOut);
								globalMap
										.put("tDenormalize_1_DenormalizeOut_NB_LINE",
												result_list_tDenormalize_1_DenormalizeOut
														.size());
								log.info("tDenormalize_1_DenormalizeOut - Generated records count: "
										+ result_list_tDenormalize_1_DenormalizeOut
												.size() + " .");

								if (log.isDebugEnabled())
									log.debug("tDenormalize_1_DenormalizeOut - "
											+ "Done.");

								ok_Hash.put("tDenormalize_1_DenormalizeOut",
										true);
								end_Hash.put("tDenormalize_1_DenormalizeOut",
										System.currentTimeMillis());

								talendStats_STATS
										.addMessage(
												"end",
												"tDenormalize_1_DenormalizeOut",
												end_Hash.get("tDenormalize_1_DenormalizeOut")
														- start_Hash
																.get("tDenormalize_1_DenormalizeOut"));
								talendStats_STATSProcess(globalMap);

								/**
								 * [tDenormalize_1_DenormalizeOut end ] stop
								 */

								/**
								 * [tJavaRow_4 begin ] start
								 */

								ok_Hash.put("tJavaRow_4", false);
								start_Hash.put("tJavaRow_4",
										System.currentTimeMillis());

								currentComponent = "tJavaRow_4";

								int tos_count_tJavaRow_4 = 0;

								int nb_line_tJavaRow_4 = 0;

								/**
								 * [tJavaRow_4 begin ] stop
								 */

								/**
								 * [tDenormalize_1_ArrayIn begin ] start
								 */

								ok_Hash.put("tDenormalize_1_ArrayIn", false);
								start_Hash.put("tDenormalize_1_ArrayIn",
										System.currentTimeMillis());

								talendStats_STATS.addMessage("begin",
										"tDenormalize_1_ArrayIn");
								talendStats_STATSProcess(globalMap);

								currentVirtualComponent = "tDenormalize_1";

								currentComponent = "tDenormalize_1_ArrayIn";

								int tos_count_tDenormalize_1_ArrayIn = 0;

								int nb_line_tDenormalize_1_ArrayIn = 0;
								java.util.List<OnRowsEndStructtDenormalize_1> list_tDenormalize_1_ArrayIn = (java.util.List<OnRowsEndStructtDenormalize_1>) globalMap
										.get("tDenormalize_1");
								if (list_tDenormalize_1_ArrayIn == null) {
									list_tDenormalize_1_ArrayIn = new java.util.ArrayList<OnRowsEndStructtDenormalize_1>();
								}
								for (OnRowsEndStructtDenormalize_1 row_tDenormalize_1_ArrayIn : list_tDenormalize_1_ArrayIn) {

									row10.col_rule = row_tDenormalize_1_ArrayIn.col_rule;

									/**
									 * [tDenormalize_1_ArrayIn begin ] stop
									 */

									/**
									 * [tDenormalize_1_ArrayIn main ] start
									 */

									currentVirtualComponent = "tDenormalize_1";

									currentComponent = "tDenormalize_1_ArrayIn";

									tos_count_tDenormalize_1_ArrayIn++;

									/**
									 * [tDenormalize_1_ArrayIn main ] stop
									 */

									/**
									 * [tJavaRow_4 main ] start
									 */

									currentComponent = "tJavaRow_4";

									if (log.isTraceEnabled()) {
										log.trace("row10 - "
												+ (row10 == null ? "" : row10
														.toLogString()));
									}

									// Code generated according to input schema
									// and output schema
									// output_row.col_rule = row10.col_rule;

									context.rules = row10.col_rule;

									DMLogger.log("***************************************************************************************");

									DMLogger.log(String
											.format(">>>>>> Connecting to Server:%s On Port:%s",
													context.src_host,
													context.src_port));

									DMLogger.log(String
											.format(">>>>>> Starting Table Extraction,Source DB Type:%s,Source DB:%s,Source Schema:%s,Source Table:%s",
													context.src_db_type,
													context.src_db_nme,
													context.src_db_schema,
													context.table_nme));

									DMLogger.log(String.format(
											">>>>>> SQL Being Run:%s",
											context.src_sql));

									DMLogger.log(String.format(
											">>>>>> Rules In Play:%s",
											context.rules));

									DMLogger.log(String
											.format(">>>>>> Target System ,Target DB Type:%s,Target DB:%s,Target Schema:%s,Target Table:%s$",
													context.tgt_db_type,
													context.tgt_db_nme,
													context.tgt_db_schema,
													context.table_nme));

									DMLogger.log("***************************************************************************************");

									nb_line_tJavaRow_4++;

									tos_count_tJavaRow_4++;

									/**
									 * [tJavaRow_4 main ] stop
									 */

									/**
									 * [tDenormalize_1_ArrayIn end ] start
									 */

									currentVirtualComponent = "tDenormalize_1";

									currentComponent = "tDenormalize_1_ArrayIn";

									nb_line_tDenormalize_1_ArrayIn++;
								}
								globalMap.put("tDenormalize_1_ArrayIn_NB_LINE",
										nb_line_tDenormalize_1_ArrayIn);

								ok_Hash.put("tDenormalize_1_ArrayIn", true);
								end_Hash.put("tDenormalize_1_ArrayIn",
										System.currentTimeMillis());

								talendStats_STATS
										.addMessage(
												"end",
												"tDenormalize_1_ArrayIn",
												end_Hash.get("tDenormalize_1_ArrayIn")
														- start_Hash
																.get("tDenormalize_1_ArrayIn"));
								talendStats_STATSProcess(globalMap);

								/**
								 * [tDenormalize_1_ArrayIn end ] stop
								 */

								/**
								 * [tJavaRow_4 end ] start
								 */

								currentComponent = "tJavaRow_4";

								globalMap.put("tJavaRow_4_NB_LINE",
										nb_line_tJavaRow_4);

								ok_Hash.put("tJavaRow_4", true);
								end_Hash.put("tJavaRow_4",
										System.currentTimeMillis());

								if (context.src_db_type.equals("MSSQL")) {

									tMSSqlInput_1Process(globalMap);
								}

								/**
								 * [tJavaRow_4 end ] stop
								 */

							} // End of branch "row8"

							/**
							 * [tFileInputExcel_1 end ] start
							 */

							currentComponent = "tFileInputExcel_1";

						}

						log.debug("tFileInputExcel_1 - Retrieved records count: "
								+ nb_line_tFileInputExcel_1 + " .");

						globalMap.put("tFileInputExcel_1_NB_LINE",
								nb_line_tFileInputExcel_1);

					}

				} finally {

					if (!(source_tFileInputExcel_1 instanceof java.io.InputStream)) {
						workbook_tFileInputExcel_1.getPackage().revert();
					}

				}

				if (log.isDebugEnabled())
					log.debug("tFileInputExcel_1 - " + "Done.");

				ok_Hash.put("tFileInputExcel_1", true);
				end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tFileInputExcel_1",
						end_Hash.get("tFileInputExcel_1")
								- start_Hash.get("tFileInputExcel_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tFileInputExcel_1 end ] stop
				 */

				/**
				 * [tJavaRow_3 end ] start
				 */

				currentComponent = "tJavaRow_3";

				globalMap.put("tJavaRow_3_NB_LINE", nb_line_tJavaRow_3);

				ok_Hash.put("tJavaRow_3", true);
				end_Hash.put("tJavaRow_3", System.currentTimeMillis());

				/**
				 * [tJavaRow_3 end ] stop
				 */

				/**
				 * [tFlowToIterate_1 end ] start
				 */

				currentComponent = "tFlowToIterate_1";

				globalMap.put("tFlowToIterate_1_NB_LINE",
						nb_line_tFlowToIterate_1);

				if (log.isDebugEnabled())
					log.debug("tFlowToIterate_1 - " + "Done.");

				ok_Hash.put("tFlowToIterate_1", true);
				end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tFlowToIterate_1",
						end_Hash.get("tFlowToIterate_1")
								- start_Hash.get("tFlowToIterate_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tFlowToIterate_1 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			// free memory for "tDenormalize_1_ArrayIn"
			globalMap.remove("tDenormalize_1");

			try {

				/**
				 * [tFileInputExcel_1 finally ] start
				 */

				currentComponent = "tFileInputExcel_1";

				/**
				 * [tFileInputExcel_1 finally ] stop
				 */

				/**
				 * [tJavaRow_3 finally ] start
				 */

				currentComponent = "tJavaRow_3";

				/**
				 * [tJavaRow_3 finally ] stop
				 */

				/**
				 * [tFlowToIterate_1 finally ] start
				 */

				currentComponent = "tFlowToIterate_1";

				/**
				 * [tFlowToIterate_1 finally ] stop
				 */

				/**
				 * [tMSSqlInput_2 finally ] start
				 */

				currentComponent = "tMSSqlInput_2";

				/**
				 * [tMSSqlInput_2 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tDenormalize_1_DenormalizeOut finally ] start
				 */

				currentVirtualComponent = "tDenormalize_1";

				currentComponent = "tDenormalize_1_DenormalizeOut";

				/**
				 * [tDenormalize_1_DenormalizeOut finally ] stop
				 */

				/**
				 * [tDenormalize_1_ArrayIn finally ] start
				 */

				currentVirtualComponent = "tDenormalize_1";

				currentComponent = "tDenormalize_1_ArrayIn";

				/**
				 * [tDenormalize_1_ArrayIn finally ] stop
				 */

				/**
				 * [tJavaRow_4 finally ] start
				 */

				currentComponent = "tJavaRow_4";

				/**
				 * [tJavaRow_4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements
			routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public routines.system.Dynamic dym_col;

		public routines.system.Dynamic getDym_col() {
			return this.dym_col;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.dym_col = (routines.system.Dynamic) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Dynamic

				dos.writeObject(this.dym_col);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dym_col=" + String.valueOf(dym_col));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dym_col == null) {
				sb.append("<null>");
			} else {
				sb.append(dym_col);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements
			routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public routines.system.Dynamic dym_col;

		public routines.system.Dynamic getDym_col() {
			return this.dym_col;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.dym_col = (routines.system.Dynamic) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Dynamic

				dos.writeObject(this.dym_col);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("dym_col=" + String.valueOf(dym_col));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (dym_col == null) {
				sb.append("<null>");
			} else {
				sb.append(dym_col);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tMSSqlInput_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();
				row3Struct row3 = new row3Struct();

				/**
				 * [tMSSqlOutput_1 begin ] start
				 */

				ok_Hash.put("tMSSqlOutput_1", false);
				start_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlOutput_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlOutput_1";

				int tos_count_tMSSqlOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlOutput_1 = new StringBuilder();
				log4jParamters_tMSSqlOutput_1.append("Parameters:");
				log4jParamters_tMSSqlOutput_1.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("HOST" + " = "
						+ "context.tgt_host");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("PORT" + " = "
						+ "context.tgt_port");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DB_SCHEMA" + " = "
						+ "context.tgt_db_schema");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DBNAME" + " = "
						+ "context.tgt_db_nme");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USER" + " = "
						+ "context.tgt_db_user");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("PASS"
						+ " = "
						+ String.valueOf(
								routines.system.PasswordEncryptUtil
										.encryptPassword(context.tgt_db_pass))
								.substring(0, 4) + "...");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("TABLE" + " = "
						+ "context.table_nme");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("TABLE_ACTION" + " = "
						+ "TRUNCATE");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("IDENTITY_INSERT" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DATA_ACTION" + " = "
						+ "INSERT");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("COMMIT_EVERY" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("ADD_COLS" + " = " + "[]");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USE_FIELD_OPTIONS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("IGNORE_DATE_OUTOF_RANGE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("ENABLE_DEBUG_MODE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("SUPPORT_NULL_WHERE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("USE_BATCH_SIZE" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				log4jParamters_tMSSqlOutput_1.append("BATCH_SIZE" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ log4jParamters_tMSSqlOutput_1);

				int nb_line_tMSSqlOutput_1 = 0;
				int nb_line_update_tMSSqlOutput_1 = 0;
				int nb_line_inserted_tMSSqlOutput_1 = 0;
				int nb_line_deleted_tMSSqlOutput_1 = 0;
				int nb_line_rejected_tMSSqlOutput_1 = 0;

				int deletedCount_tMSSqlOutput_1 = 0;
				int updatedCount_tMSSqlOutput_1 = 0;
				int insertedCount_tMSSqlOutput_1 = 0;
				int rejectedCount_tMSSqlOutput_1 = 0;
				String dbschema_tMSSqlOutput_1 = null;
				String tableName_tMSSqlOutput_1 = null;
				boolean whetherReject_tMSSqlOutput_1 = false;

				java.util.Calendar calendar_tMSSqlOutput_1 = java.util.Calendar
						.getInstance();
				long year1_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tMSSqlOutput_1 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tMSSqlOutput_1;

				java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tMSSqlOutput_1 = null;
				String dbUser_tMSSqlOutput_1 = null;
				dbschema_tMSSqlOutput_1 = context.tgt_db_schema;
				String driverClass_tMSSqlOutput_1 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Driver ClassName: "
							+ driverClass_tMSSqlOutput_1 + ".");
				java.lang.Class.forName(driverClass_tMSSqlOutput_1);
				String port_tMSSqlOutput_1 = context.tgt_port;
				String dbname_tMSSqlOutput_1 = context.tgt_db_nme;
				String url_tMSSqlOutput_1 = "jdbc:jtds:sqlserver://"
						+ context.tgt_host;
				if (!"".equals(port_tMSSqlOutput_1)) {
					url_tMSSqlOutput_1 += ":" + context.tgt_port;
				}
				if (!"".equals(dbname_tMSSqlOutput_1)) {
					url_tMSSqlOutput_1 += "//" + context.tgt_db_nme;
				}
				url_tMSSqlOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tMSSqlOutput_1 = context.tgt_db_user;

				final String decryptedPassword_tMSSqlOutput_1 = context.tgt_db_pass;

				String dbPwd_tMSSqlOutput_1 = decryptedPassword_tMSSqlOutput_1;
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Connection attempts to '"
							+ url_tMSSqlOutput_1 + "' with the username '"
							+ dbUser_tMSSqlOutput_1 + "'.");
				conn_tMSSqlOutput_1 = java.sql.DriverManager.getConnection(
						url_tMSSqlOutput_1, dbUser_tMSSqlOutput_1,
						dbPwd_tMSSqlOutput_1);
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Connection to '"
							+ url_tMSSqlOutput_1 + "' has succeeded.");

				resourceMap.put("conn_tMSSqlOutput_1", conn_tMSSqlOutput_1);

				conn_tMSSqlOutput_1.setAutoCommit(false);
				int commitEvery_tMSSqlOutput_1 = 10000;
				int commitCounter_tMSSqlOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection is set auto commit to '"
							+ conn_tMSSqlOutput_1.getAutoCommit() + "'.");
				int batchSize_tMSSqlOutput_1 = 10000;
				int batchSizeCounter_tMSSqlOutput_1 = 0;

				if (dbschema_tMSSqlOutput_1 == null
						|| dbschema_tMSSqlOutput_1.trim().length() == 0) {
					tableName_tMSSqlOutput_1 = context.table_nme;
				} else {
					tableName_tMSSqlOutput_1 = dbschema_tMSSqlOutput_1 + "].["
							+ context.table_nme;
				}
				java.sql.PreparedStatement pstmt_tMSSqlOutput_1 = null;
				java.sql.PreparedStatement pstmtInsert_tMSSqlOutput_1 = null;
				java.sql.PreparedStatement pstmtUpdate_tMSSqlOutput_1 = null;

				/**
				 * [tMSSqlOutput_1 begin ] stop
				 */

				/**
				 * [AST_rules_1_tJavaFlex_5 begin ] start
				 */

				ok_Hash.put("AST_rules_1_tJavaFlex_5", false);
				start_Hash.put("AST_rules_1_tJavaFlex_5",
						System.currentTimeMillis());

				talendStats_STATS
						.addMessage("begin", "AST_rules_1_tJavaFlex_5");
				talendStats_STATSProcess(globalMap);

				currentComponent = "AST_rules_1_tJavaFlex_5";

				int tos_count_AST_rules_1_tJavaFlex_5 = 0;

				// start part of your Java code
				HashMap rulesMap = new HashMap();
				boolean metaExtract = true;

				/**
				 * [AST_rules_1_tJavaFlex_5 begin ] stop
				 */

				/**
				 * [tMSSqlInput_1 begin ] start
				 */

				ok_Hash.put("tMSSqlInput_1", false);
				start_Hash.put("tMSSqlInput_1", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlInput_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlInput_1";

				int tos_count_tMSSqlInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlInput_1 = new StringBuilder();
				log4jParamters_tMSSqlInput_1.append("Parameters:");
				log4jParamters_tMSSqlInput_1.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("HOST" + " = "
						+ "context.src_host");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("PORT" + " = "
						+ "context.src_port");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("DB_SCHEMA" + " = "
						+ "context.src_db_schema");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("DBNAME" + " = "
						+ "context.src_db_nme");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("USER" + " = "
						+ "context.src_db_user");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("PASS"
						+ " = "
						+ String.valueOf(
								routines.system.PasswordEncryptUtil
										.encryptPassword(context.src_db_pass))
								.substring(0, 4) + "...");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TABLE" + " = "
						+ "context.table_nme");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("QUERY" + " = "
						+ "context.src_sql");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tMSSqlInput_1.append(" | ");
				log4jParamters_tMSSqlInput_1.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("dym_col") + "}]");
				log4jParamters_tMSSqlInput_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + log4jParamters_tMSSqlInput_1);

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tMSSqlInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tMSSqlInput_1 = new String[] {
						"FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tMSSqlInput_1,
						talendToDBArray_tMSSqlInput_1);
				int nb_line_tMSSqlInput_1 = 0;
				java.sql.Connection conn_tMSSqlInput_1 = null;
				String driverClass_tMSSqlInput_1 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class.forName(driverClass_tMSSqlInput_1);
				String dbUser_tMSSqlInput_1 = context.src_db_user;

				final String decryptedPassword_tMSSqlInput_1 = context.src_db_pass;

				String dbPwd_tMSSqlInput_1 = decryptedPassword_tMSSqlInput_1;

				String port_tMSSqlInput_1 = context.src_port;
				String dbname_tMSSqlInput_1 = context.src_db_nme;
				String url_tMSSqlInput_1 = "jdbc:jtds:sqlserver://"
						+ context.src_host;
				if (!"".equals(port_tMSSqlInput_1)) {
					url_tMSSqlInput_1 += ":" + context.src_port;
				}
				if (!"".equals(dbname_tMSSqlInput_1)) {
					url_tMSSqlInput_1 += "//" + context.src_db_nme;
				}
				url_tMSSqlInput_1 += ";appName=" + projectName + ";" + "";
				String dbschema_tMSSqlInput_1 = context.src_db_schema;

				log.debug("tMSSqlInput_1 - Driver ClassName: "
						+ driverClass_tMSSqlInput_1 + ".");

				log.debug("tMSSqlInput_1 - Connection attempt to '"
						+ url_tMSSqlInput_1 + "' with the username '"
						+ dbUser_tMSSqlInput_1 + "'.");

				conn_tMSSqlInput_1 = java.sql.DriverManager.getConnection(
						url_tMSSqlInput_1, dbUser_tMSSqlInput_1,
						dbPwd_tMSSqlInput_1);
				log.debug("tMSSqlInput_1 - Connection to '" + url_tMSSqlInput_1
						+ "' has succeeded.");

				java.sql.Statement stmt_tMSSqlInput_1 = conn_tMSSqlInput_1
						.createStatement();

				String dbquery_tMSSqlInput_1 = context.src_sql;

				log.debug("tMSSqlInput_1 - Executing the query: '"
						+ dbquery_tMSSqlInput_1 + "'.");

				globalMap.put("tMSSqlInput_1_QUERY", dbquery_tMSSqlInput_1);

				java.sql.ResultSet rs_tMSSqlInput_1 = null;
				try {
					rs_tMSSqlInput_1 = stmt_tMSSqlInput_1
							.executeQuery(dbquery_tMSSqlInput_1);
					java.sql.ResultSetMetaData rsmd_tMSSqlInput_1 = rs_tMSSqlInput_1
							.getMetaData();
					int colQtyInRs_tMSSqlInput_1 = rsmd_tMSSqlInput_1
							.getColumnCount();

					routines.system.Dynamic dcg_tMSSqlInput_1 = new routines.system.Dynamic();
					dcg_tMSSqlInput_1.setDbmsId("id_MSSQL");
					List<String> listSchema_tMSSqlInput_1 = new java.util.ArrayList<String>();

					int fixedColumnCount_tMSSqlInput_1 = 0;

					for (int i = 1; i <= rsmd_tMSSqlInput_1.getColumnCount() - 0; i++) {
						if (!(listSchema_tMSSqlInput_1
								.contains(rsmd_tMSSqlInput_1.getColumnLabel(i)
										.toUpperCase()))) {
							routines.system.DynamicMetadata dcm_tMSSqlInput_1 = new routines.system.DynamicMetadata();
							dcm_tMSSqlInput_1.setName(rsmd_tMSSqlInput_1
									.getColumnLabel(i));
							dcm_tMSSqlInput_1.setDbName(rsmd_tMSSqlInput_1
									.getColumnName(i));
							dcm_tMSSqlInput_1.setType(routines.system.Dynamic
									.getTalendTypeFromDBType("id_MSSQL",
											rsmd_tMSSqlInput_1
													.getColumnTypeName(i)
													.toUpperCase(),
											rsmd_tMSSqlInput_1.getPrecision(i),
											rsmd_tMSSqlInput_1.getScale(i)));
							dcm_tMSSqlInput_1.setDbType(rsmd_tMSSqlInput_1
									.getColumnTypeName(i));
							dcm_tMSSqlInput_1.setDbTypeId(rsmd_tMSSqlInput_1
									.getColumnType(i));
							dcm_tMSSqlInput_1.setFormat("dd-MM-yyyy");
							dcm_tMSSqlInput_1.setLength(rsmd_tMSSqlInput_1
									.getPrecision(i));
							dcm_tMSSqlInput_1.setPrecision(rsmd_tMSSqlInput_1
									.getScale(i));
							dcm_tMSSqlInput_1.setNullable(rsmd_tMSSqlInput_1
									.isNullable(i) == 0 ? false : true);
							dcm_tMSSqlInput_1.setKey(false);
							dcm_tMSSqlInput_1
									.setSourceType(DynamicMetadata.sourceTypes.database);
							dcm_tMSSqlInput_1.setColumnPosition(i);
							dcg_tMSSqlInput_1.metadatas.add(dcm_tMSSqlInput_1);
						}
					}
					String tmpContent_tMSSqlInput_1 = null;

					int column_index_tMSSqlInput_1 = 1;

					log.debug("tMSSqlInput_1 - Retrieving records from the database.");

					while (rs_tMSSqlInput_1.next()) {
						nb_line_tMSSqlInput_1++;

						column_index_tMSSqlInput_1 = 1;

						if (colQtyInRs_tMSSqlInput_1 < column_index_tMSSqlInput_1) {
							row2.dym_col = null;
						} else {
							row2.dym_col = dcg_tMSSqlInput_1;
							List<String> list_tMSSqlInput_1 = new java.util.ArrayList<String>();
							for (int i_tMSSqlInput_1 = 1; i_tMSSqlInput_1 <= rsmd_tMSSqlInput_1
									.getColumnCount(); i_tMSSqlInput_1++) {
								if ("NTEXT".equals(rsmd_tMSSqlInput_1
										.getColumnTypeName(i_tMSSqlInput_1)
										.toUpperCase())) {
									net.sourceforge.jtds.jdbc.ClobImpl clob_tMSSqlInput_1 = (net.sourceforge.jtds.jdbc.ClobImpl) rs_tMSSqlInput_1
											.getClob(i_tMSSqlInput_1);
									if (clob_tMSSqlInput_1 != null) {
										net.sourceforge.jtds.jdbc.TalendNTextImpl tNTextImpl_tMSSqlInput_1 = new net.sourceforge.jtds.jdbc.TalendNTextImpl(
												clob_tMSSqlInput_1);
										list_tMSSqlInput_1
												.add(tNTextImpl_tMSSqlInput_1
														.getValue());
									} else {
										list_tMSSqlInput_1.add(null);
									}
								}
							}
							routines.system.DynamicUtils
									.readColumnsFromDatabase_Mssql(
											row2.dym_col, rs_tMSSqlInput_1,
											fixedColumnCount_tMSSqlInput_1,
											list_tMSSqlInput_1, false);
						}

						log.debug("tMSSqlInput_1 - Retrieving the record "
								+ nb_line_tMSSqlInput_1 + ".");

						/**
						 * [tMSSqlInput_1 begin ] stop
						 */

						/**
						 * [tMSSqlInput_1 main ] start
						 */

						currentComponent = "tMSSqlInput_1";

						tos_count_tMSSqlInput_1++;

						/**
						 * [tMSSqlInput_1 main ] stop
						 */

						/**
						 * [AST_rules_1_tJavaFlex_5 main ] start
						 */

						currentComponent = "AST_rules_1_tJavaFlex_5";

						if (log.isTraceEnabled()) {
							log.trace("row2 - "
									+ (row2 == null ? "" : row2.toLogString()));
						}

						row3.dym_col = row2.dym_col;

						if (metaExtract) {

							// System.out.println(" context.rules " +
							// context.rules);

							String[] rules = context.rules.split("~");

							List<DynamicMetadata> dynamicColumns = row2.dym_col.metadatas;
							for (String rule : rules) {
								String[] colNames = rule.split("%")[0]
										.split(",");
								String ruleName = rule.split("%")[1];
								List<RuleColumn> ruleColumns = new ArrayList<RuleColumn>();
								for (String colName : colNames) {
									for (DynamicMetadata dmd : dynamicColumns) {
										if (dmd.getDbName().equalsIgnoreCase(
												colName)) {
											ruleColumns.add(new RuleColumn(
													colName, dmd));
											break;
										}
									}

								}
								if (rulesMap.get(ruleName) != null) {
									List<RuleColumn> ruleCols = (List<RuleColumn>) rulesMap
											.get(ruleName);
									for (RuleColumn ruleColumn : ruleColumns) {
										ruleCols.add(ruleColumn);
									}
									rulesMap.put(ruleName, ruleCols);
								} else {
									rulesMap.put(ruleName, ruleColumns);
								}

							}
							metaExtract = false;
						}

						Rules.Execute(rulesMap, row2.dym_col);

						tos_count_AST_rules_1_tJavaFlex_5++;

						/**
						 * [AST_rules_1_tJavaFlex_5 main ] stop
						 */

						/**
						 * [tMSSqlOutput_1 main ] start
						 */

						currentComponent = "tMSSqlOutput_1";

						if (log.isTraceEnabled()) {
							log.trace("row3 - "
									+ (row3 == null ? "" : row3.toLogString()));
						}

						if (nb_line_tMSSqlOutput_1 == 0) {

							java.sql.Statement stmtTruncCount_tMSSqlOutput_1 = conn_tMSSqlOutput_1
									.createStatement();
							java.sql.ResultSet rsTruncCount_tMSSqlOutput_1 = stmtTruncCount_tMSSqlOutput_1
									.executeQuery("SELECT COUNT(1) FROM ["
											+ tableName_tMSSqlOutput_1 + "]");
							int rsTruncCountNumber_tMSSqlOutput_1 = 0;
							if (rsTruncCount_tMSSqlOutput_1.next()) {
								rsTruncCountNumber_tMSSqlOutput_1 = rsTruncCount_tMSSqlOutput_1
										.getInt(1);
							}
							rsTruncCount_tMSSqlOutput_1.close();
							stmtTruncCount_tMSSqlOutput_1.close();
							java.sql.Statement stmtTrunc_tMSSqlOutput_1 = conn_tMSSqlOutput_1
									.createStatement();
							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - " + "Truncating"
										+ " table '" + tableName_tMSSqlOutput_1
										+ "'.");
							stmtTrunc_tMSSqlOutput_1
									.executeUpdate("TRUNCATE TABLE ["
											+ tableName_tMSSqlOutput_1 + "]");
							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - " + "Truncate"
										+ " table '" + tableName_tMSSqlOutput_1
										+ "' has succeeded.");
							deletedCount_tMSSqlOutput_1 += rsTruncCountNumber_tMSSqlOutput_1;
							stmtTrunc_tMSSqlOutput_1.close();
							String insert_tMSSqlOutput_1 = "INSERT INTO ["
									+ tableName_tMSSqlOutput_1
									+ "] ("
									+ DynamicUtils
											.getInsertIntoStmtColumnsList(
													row3.dym_col, "id_MSSQL")
									+ ") VALUES ("
									+ DynamicUtils
											.getInsertIntoStmtValuesList(row3.dym_col)
									+ ")";
							// String insert_tMSSqlOutput_1 = "INSERT INTO [" +
							// tableName_tMSSqlOutput_1 + "] () VALUES ()";
							pstmt_tMSSqlOutput_1 = conn_tMSSqlOutput_1
									.prepareStatement(insert_tMSSqlOutput_1);

						}

						whetherReject_tMSSqlOutput_1 = false;
						DynamicUtils.writeColumnsToDatabse(row3.dym_col,
								pstmt_tMSSqlOutput_1, 0, "id_MSSQL");

						pstmt_tMSSqlOutput_1.addBatch();
						nb_line_tMSSqlOutput_1++;

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_1 - "
									+ "Adding the record "
									+ nb_line_tMSSqlOutput_1 + " to the "
									+ "INSERT" + " batch.");
						batchSizeCounter_tMSSqlOutput_1++;

						if (!whetherReject_tMSSqlOutput_1) {
						}
						if ((batchSize_tMSSqlOutput_1 > 0)
								&& (batchSize_tMSSqlOutput_1 <= batchSizeCounter_tMSSqlOutput_1)) {
							try {
								int countSum_tMSSqlOutput_1 = 0;

								if (log.isDebugEnabled())
									log.debug("tMSSqlOutput_1 - "
											+ "Executing the " + "INSERT"
											+ " batch.");
								for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
										.executeBatch()) {
									if (countEach_tMSSqlOutput_1 == -2
											|| countEach_tMSSqlOutput_1 == -3) {
										break;
									}
									countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
								}

								if (log.isDebugEnabled())
									log.debug("tMSSqlOutput_1 - " + "The "
											+ "INSERT"
											+ " batch execution has succeeded.");

								insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

								batchSizeCounter_tMSSqlOutput_1 = 0;
							} catch (java.sql.BatchUpdateException e) {

								int countSum_tMSSqlOutput_1 = 0;
								for (int countEach_tMSSqlOutput_1 : e
										.getUpdateCounts()) {
									countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
											: countEach_tMSSqlOutput_1);
								}

								insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

								log.error("tMSSqlOutput_1 - " + e.getMessage());
								System.err.println(e.getMessage());

							}
						}

						commitCounter_tMSSqlOutput_1++;
						if (commitEvery_tMSSqlOutput_1 <= commitCounter_tMSSqlOutput_1) {
							if ((batchSize_tMSSqlOutput_1 > 0)
									&& (batchSizeCounter_tMSSqlOutput_1 > 0)) {
								try {
									int countSum_tMSSqlOutput_1 = 0;

									if (log.isDebugEnabled())
										log.debug("tMSSqlOutput_1 - "
												+ "Executing the " + "INSERT"
												+ " batch.");
									for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
											.executeBatch()) {
										if (countEach_tMSSqlOutput_1 == -2
												|| countEach_tMSSqlOutput_1 == -3) {
											break;
										}
										countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
									}

									if (log.isDebugEnabled())
										log.debug("tMSSqlOutput_1 - "
												+ "The "
												+ "INSERT"
												+ " batch execution has succeeded.");

									insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

									batchSizeCounter_tMSSqlOutput_1 = 0;
								} catch (java.sql.BatchUpdateException e) {

									int countSum_tMSSqlOutput_1 = 0;
									for (int countEach_tMSSqlOutput_1 : e
											.getUpdateCounts()) {
										countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
												: countEach_tMSSqlOutput_1);
									}

									insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

									log.error("tMSSqlOutput_1 - "
											+ e.getMessage());
									System.err.println(e.getMessage());

								}
							}

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Connection starting to commit "
										+ commitCounter_tMSSqlOutput_1
										+ " record(s).");
							conn_tMSSqlOutput_1.commit();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Connection commit has succeeded.");
							commitCounter_tMSSqlOutput_1 = 0;
						}

						tos_count_tMSSqlOutput_1++;

						/**
						 * [tMSSqlOutput_1 main ] stop
						 */

						/**
						 * [tMSSqlInput_1 end ] start
						 */

						currentComponent = "tMSSqlInput_1";

					}
				} finally {
					stmt_tMSSqlInput_1.close();

					if (conn_tMSSqlInput_1 != null
							&& !conn_tMSSqlInput_1.isClosed()) {

						log.debug("tMSSqlInput_1 - Closing the connection to the database.");

						conn_tMSSqlInput_1.close();

						log.debug("tMSSqlInput_1 - Connection to the database closed.");

					}
				}
				globalMap.put("tMSSqlInput_1_NB_LINE", nb_line_tMSSqlInput_1);
				log.debug("tMSSqlInput_1 - Retrieved records count: "
						+ nb_line_tMSSqlInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_1 - " + "Done.");

				ok_Hash.put("tMSSqlInput_1", true);
				end_Hash.put("tMSSqlInput_1", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlInput_1",
						end_Hash.get("tMSSqlInput_1")
								- start_Hash.get("tMSSqlInput_1"));
				talendStats_STATSProcess(globalMap);
				tJava_11Process(globalMap);

				/**
				 * [tMSSqlInput_1 end ] stop
				 */

				/**
				 * [AST_rules_1_tJavaFlex_5 end ] start
				 */

				currentComponent = "AST_rules_1_tJavaFlex_5";

				// end of the component, outside/closing the loop

				ok_Hash.put("AST_rules_1_tJavaFlex_5", true);
				end_Hash.put("AST_rules_1_tJavaFlex_5",
						System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"AST_rules_1_tJavaFlex_5",
						end_Hash.get("AST_rules_1_tJavaFlex_5")
								- start_Hash.get("AST_rules_1_tJavaFlex_5"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [AST_rules_1_tJavaFlex_5 end ] stop
				 */

				/**
				 * [tMSSqlOutput_1 end ] start
				 */

				currentComponent = "tMSSqlOutput_1";

				try {
					int countSum_tMSSqlOutput_1 = 0;
					if (pstmt_tMSSqlOutput_1 != null
							&& batchSizeCounter_tMSSqlOutput_1 > 0) {

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_1 - " + "Executing the "
									+ "INSERT" + " batch.");
						for (int countEach_tMSSqlOutput_1 : pstmt_tMSSqlOutput_1
								.executeBatch()) {
							if (countEach_tMSSqlOutput_1 == -2
									|| countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							countSum_tMSSqlOutput_1 += countEach_tMSSqlOutput_1;
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_1 - " + "The " + "INSERT"
									+ " batch execution has succeeded.");
					}

					insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tMSSqlOutput_1 = 0;
					for (int countEach_tMSSqlOutput_1 : e.getUpdateCounts()) {
						countSum_tMSSqlOutput_1 += (countEach_tMSSqlOutput_1 < 0 ? 0
								: countEach_tMSSqlOutput_1);
					}

					insertedCount_tMSSqlOutput_1 += countSum_tMSSqlOutput_1;

					log.error("tMSSqlOutput_1 - " + e.getMessage());
					System.err.println(e.getMessage());

				}
				if (pstmt_tMSSqlOutput_1 != null) {

					pstmt_tMSSqlOutput_1.close();

				}

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection starting to commit "
							+ commitCounter_tMSSqlOutput_1 + " record(s).");
				conn_tMSSqlOutput_1.commit();

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection commit has succeeded.");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Closing the connection to the database.");
				conn_tMSSqlOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - "
							+ "Connection to the database has closed.");
				resourceMap.put("finish_tMSSqlOutput_1", true);

				nb_line_deleted_tMSSqlOutput_1 = nb_line_deleted_tMSSqlOutput_1
						+ deletedCount_tMSSqlOutput_1;
				nb_line_update_tMSSqlOutput_1 = nb_line_update_tMSSqlOutput_1
						+ updatedCount_tMSSqlOutput_1;
				nb_line_inserted_tMSSqlOutput_1 = nb_line_inserted_tMSSqlOutput_1
						+ insertedCount_tMSSqlOutput_1;
				nb_line_rejected_tMSSqlOutput_1 = nb_line_rejected_tMSSqlOutput_1
						+ rejectedCount_tMSSqlOutput_1;

				globalMap.put("tMSSqlOutput_1_NB_LINE", nb_line_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_UPDATED",
						nb_line_update_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_INSERTED",
						nb_line_inserted_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_DELETED",
						nb_line_deleted_tMSSqlOutput_1);
				globalMap.put("tMSSqlOutput_1_NB_LINE_REJECTED",
						nb_line_rejected_tMSSqlOutput_1);

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Has " + "inserted" + " "
							+ nb_line_inserted_tMSSqlOutput_1 + " record(s).");

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_1 - " + "Done.");

				ok_Hash.put("tMSSqlOutput_1", true);
				end_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlOutput_1",
						end_Hash.get("tMSSqlOutput_1")
								- start_Hash.get("tMSSqlOutput_1"));
				talendStats_STATSProcess(globalMap);
				tJava_4Process(globalMap);
				tFixedFlowInput_1Process(globalMap);

				/**
				 * [tMSSqlOutput_1 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tMSSqlInput_1 finally ] start
				 */

				currentComponent = "tMSSqlInput_1";

				/**
				 * [tMSSqlInput_1 finally ] stop
				 */

				/**
				 * [AST_rules_1_tJavaFlex_5 finally ] start
				 */

				currentComponent = "AST_rules_1_tJavaFlex_5";

				/**
				 * [AST_rules_1_tJavaFlex_5 finally ] stop
				 */

				/**
				 * [tMSSqlOutput_1 finally ] start
				 */

				currentComponent = "tMSSqlOutput_1";

				if (resourceMap.get("finish_tMSSqlOutput_1") == null) {
					if (resourceMap.get("conn_tMSSqlOutput_1") != null) {
						try {

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Closing the connection to the database.");
							((java.sql.Connection) resourceMap
									.get("conn_tMSSqlOutput_1")).close();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_1 - "
										+ "Connection to the database has closed.");
						} catch (java.sql.SQLException sqlEx_tMSSqlOutput_1) {
							String errorMessage_tMSSqlOutput_1 = "failed to close the connection in tMSSqlOutput_1 :"
									+ sqlEx_tMSSqlOutput_1.getMessage();

							log.error("tMSSqlOutput_1 - "
									+ errorMessage_tMSSqlOutput_1);
							System.err.println(errorMessage_tMSSqlOutput_1);
						}
					}
				}

				/**
				 * [tMSSqlOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_4Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_4 begin ] start
				 */

				ok_Hash.put("tJava_4", false);
				start_Hash.put("tJava_4", System.currentTimeMillis());

				currentComponent = "tJava_4";

				int tos_count_tJava_4 = 0;

				System.out
						.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
								+ "|********** Data Masking Completed For the MSSQL Table: "
								+ context.table_nme + " **********");

				/**
				 * [tJava_4 begin ] stop
				 */

				/**
				 * [tJava_4 main ] start
				 */

				currentComponent = "tJava_4";

				tos_count_tJava_4++;

				/**
				 * [tJava_4 main ] stop
				 */

				/**
				 * [tJava_4 end ] start
				 */

				currentComponent = "tJava_4";

				ok_Hash.put("tJava_4", true);
				end_Hash.put("tJava_4", System.currentTimeMillis());

				/**
				 * [tJava_4 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_4 finally ] start
				 */

				currentComponent = "tJava_4";

				/**
				 * [tJava_4 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}

	public static class row15Struct implements
			routines.system.IPersistableRow<row15Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public java.util.Date Start_Time;

		public java.util.Date getStart_Time() {
			return this.Start_Time;
		}

		public java.util.Date EndTime;

		public java.util.Date getEndTime() {
			return this.EndTime;
		}

		public String Project_name;

		public String getProject_name() {
			return this.Project_name;
		}

		public String Job_name;

		public String getJob_name() {
			return this.Job_name;
		}

		public Integer SRC_Input_Rows;

		public Integer getSRC_Input_Rows() {
			return this.SRC_Input_Rows;
		}

		public Integer TGT_Output_Rows;

		public Integer getTGT_Output_Rows() {
			return this.TGT_Output_Rows;
		}

		public Integer Rows_inserted_target;

		public Integer getRows_inserted_target() {
			return this.Rows_inserted_target;
		}

		public Integer Rows_updated_target;

		public Integer getRows_updated_target() {
			return this.Rows_updated_target;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.Start_Time = readDate(dis);

					this.EndTime = readDate(dis);

					this.Project_name = readString(dis);

					this.Job_name = readString(dis);

					this.SRC_Input_Rows = readInteger(dis);

					this.TGT_Output_Rows = readInteger(dis);

					this.Rows_inserted_target = readInteger(dis);

					this.Rows_updated_target = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.Start_Time, dos);

				// java.util.Date

				writeDate(this.EndTime, dos);

				// String

				writeString(this.Project_name, dos);

				// String

				writeString(this.Job_name, dos);

				// Integer

				writeInteger(this.SRC_Input_Rows, dos);

				// Integer

				writeInteger(this.TGT_Output_Rows, dos);

				// Integer

				writeInteger(this.Rows_inserted_target, dos);

				// Integer

				writeInteger(this.Rows_updated_target, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Start_Time=" + String.valueOf(Start_Time));
			sb.append(",EndTime=" + String.valueOf(EndTime));
			sb.append(",Project_name=" + Project_name);
			sb.append(",Job_name=" + Job_name);
			sb.append(",SRC_Input_Rows=" + String.valueOf(SRC_Input_Rows));
			sb.append(",TGT_Output_Rows=" + String.valueOf(TGT_Output_Rows));
			sb.append(",Rows_inserted_target="
					+ String.valueOf(Rows_inserted_target));
			sb.append(",Rows_updated_target="
					+ String.valueOf(Rows_updated_target));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Start_Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_Time);
			}

			sb.append("|");

			if (EndTime == null) {
				sb.append("<null>");
			} else {
				sb.append(EndTime);
			}

			sb.append("|");

			if (Project_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Project_name);
			}

			sb.append("|");

			if (Job_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Job_name);
			}

			sb.append("|");

			if (SRC_Input_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(SRC_Input_Rows);
			}

			sb.append("|");

			if (TGT_Output_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(TGT_Output_Rows);
			}

			sb.append("|");

			if (Rows_inserted_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_inserted_target);
			}

			sb.append("|");

			if (Rows_updated_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_updated_target);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row15Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row16Struct implements
			routines.system.IPersistableRow<row16Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public java.util.Date Start_Time;

		public java.util.Date getStart_Time() {
			return this.Start_Time;
		}

		public java.util.Date EndTime;

		public java.util.Date getEndTime() {
			return this.EndTime;
		}

		public String Project_name;

		public String getProject_name() {
			return this.Project_name;
		}

		public String Job_name;

		public String getJob_name() {
			return this.Job_name;
		}

		public Integer SRC_Input_Rows;

		public Integer getSRC_Input_Rows() {
			return this.SRC_Input_Rows;
		}

		public Integer TGT_Output_Rows;

		public Integer getTGT_Output_Rows() {
			return this.TGT_Output_Rows;
		}

		public Integer Rows_inserted_target;

		public Integer getRows_inserted_target() {
			return this.Rows_inserted_target;
		}

		public Integer Rows_updated_target;

		public Integer getRows_updated_target() {
			return this.Rows_updated_target;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.Start_Time = readDate(dis);

					this.EndTime = readDate(dis);

					this.Project_name = readString(dis);

					this.Job_name = readString(dis);

					this.SRC_Input_Rows = readInteger(dis);

					this.TGT_Output_Rows = readInteger(dis);

					this.Rows_inserted_target = readInteger(dis);

					this.Rows_updated_target = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.Start_Time, dos);

				// java.util.Date

				writeDate(this.EndTime, dos);

				// String

				writeString(this.Project_name, dos);

				// String

				writeString(this.Job_name, dos);

				// Integer

				writeInteger(this.SRC_Input_Rows, dos);

				// Integer

				writeInteger(this.TGT_Output_Rows, dos);

				// Integer

				writeInteger(this.Rows_inserted_target, dos);

				// Integer

				writeInteger(this.Rows_updated_target, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Start_Time=" + String.valueOf(Start_Time));
			sb.append(",EndTime=" + String.valueOf(EndTime));
			sb.append(",Project_name=" + Project_name);
			sb.append(",Job_name=" + Job_name);
			sb.append(",SRC_Input_Rows=" + String.valueOf(SRC_Input_Rows));
			sb.append(",TGT_Output_Rows=" + String.valueOf(TGT_Output_Rows));
			sb.append(",Rows_inserted_target="
					+ String.valueOf(Rows_inserted_target));
			sb.append(",Rows_updated_target="
					+ String.valueOf(Rows_updated_target));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Start_Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_Time);
			}

			sb.append("|");

			if (EndTime == null) {
				sb.append("<null>");
			} else {
				sb.append(EndTime);
			}

			sb.append("|");

			if (Project_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Project_name);
			}

			sb.append("|");

			if (Job_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Job_name);
			}

			sb.append("|");

			if (SRC_Input_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(SRC_Input_Rows);
			}

			sb.append("|");

			if (TGT_Output_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(TGT_Output_Rows);
			}

			sb.append("|");

			if (Rows_inserted_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_inserted_target);
			}

			sb.append("|");

			if (Rows_updated_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_updated_target);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row16Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row13Struct implements
			routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public java.util.Date Start_Time;

		public java.util.Date getStart_Time() {
			return this.Start_Time;
		}

		public java.util.Date EndTime;

		public java.util.Date getEndTime() {
			return this.EndTime;
		}

		public String Project_name;

		public String getProject_name() {
			return this.Project_name;
		}

		public String Job_name;

		public String getJob_name() {
			return this.Job_name;
		}

		public Integer SRC_Input_Rows;

		public Integer getSRC_Input_Rows() {
			return this.SRC_Input_Rows;
		}

		public Integer TGT_Output_Rows;

		public Integer getTGT_Output_Rows() {
			return this.TGT_Output_Rows;
		}

		public Integer Rows_inserted_target;

		public Integer getRows_inserted_target() {
			return this.Rows_inserted_target;
		}

		public Integer Rows_updated_target;

		public Integer getRows_updated_target() {
			return this.Rows_updated_target;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.Start_Time = readDate(dis);

					this.EndTime = readDate(dis);

					this.Project_name = readString(dis);

					this.Job_name = readString(dis);

					this.SRC_Input_Rows = readInteger(dis);

					this.TGT_Output_Rows = readInteger(dis);

					this.Rows_inserted_target = readInteger(dis);

					this.Rows_updated_target = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.Start_Time, dos);

				// java.util.Date

				writeDate(this.EndTime, dos);

				// String

				writeString(this.Project_name, dos);

				// String

				writeString(this.Job_name, dos);

				// Integer

				writeInteger(this.SRC_Input_Rows, dos);

				// Integer

				writeInteger(this.TGT_Output_Rows, dos);

				// Integer

				writeInteger(this.Rows_inserted_target, dos);

				// Integer

				writeInteger(this.Rows_updated_target, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Start_Time=" + String.valueOf(Start_Time));
			sb.append(",EndTime=" + String.valueOf(EndTime));
			sb.append(",Project_name=" + Project_name);
			sb.append(",Job_name=" + Job_name);
			sb.append(",SRC_Input_Rows=" + String.valueOf(SRC_Input_Rows));
			sb.append(",TGT_Output_Rows=" + String.valueOf(TGT_Output_Rows));
			sb.append(",Rows_inserted_target="
					+ String.valueOf(Rows_inserted_target));
			sb.append(",Rows_updated_target="
					+ String.valueOf(Rows_updated_target));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Start_Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Start_Time);
			}

			sb.append("|");

			if (EndTime == null) {
				sb.append("<null>");
			} else {
				sb.append(EndTime);
			}

			sb.append("|");

			if (Project_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Project_name);
			}

			sb.append("|");

			if (Job_name == null) {
				sb.append("<null>");
			} else {
				sb.append(Job_name);
			}

			sb.append("|");

			if (SRC_Input_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(SRC_Input_Rows);
			}

			sb.append("|");

			if (TGT_Output_Rows == null) {
				sb.append("<null>");
			} else {
				sb.append(TGT_Output_Rows);
			}

			sb.append("|");

			if (Rows_inserted_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_inserted_target);
			}

			sb.append("|");

			if (Rows_updated_target == null) {
				sb.append("<null>");
			} else {
				sb.append(Rows_updated_target);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFixedFlowInput_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row13Struct row13 = new row13Struct();
				row15Struct row15 = new row15Struct();
				row16Struct row16 = new row16Struct();

				/**
				 * [tMSSqlOutput_2 begin ] start
				 */

				ok_Hash.put("tMSSqlOutput_2", false);
				start_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlOutput_2");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlOutput_2";

				int tos_count_tMSSqlOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlOutput_2 = new StringBuilder();
				log4jParamters_tMSSqlOutput_2.append("Parameters:");
				log4jParamters_tMSSqlOutput_2.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("TABLE" + " = "
						+ "\"rows_stat\"");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("TABLE_ACTION" + " = "
						+ "CREATE_IF_NOT_EXISTS");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("IDENTITY_INSERT" + " = "
						+ "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DATA_ACTION" + " = "
						+ "INSERT");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("SPECIFY_IDENTITY_FIELD"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("DIE_ON_ERROR" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("COMMIT_EVERY" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("ADD_COLS" + " = " + "[]");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USE_FIELD_OPTIONS"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("IGNORE_DATE_OUTOF_RANGE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("ENABLE_DEBUG_MODE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("SUPPORT_NULL_WHERE"
						+ " = " + "false");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("USE_BATCH_SIZE" + " = "
						+ "true");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				log4jParamters_tMSSqlOutput_2.append("BATCH_SIZE" + " = "
						+ "10000");
				log4jParamters_tMSSqlOutput_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ log4jParamters_tMSSqlOutput_2);

				int nb_line_tMSSqlOutput_2 = 0;
				int nb_line_update_tMSSqlOutput_2 = 0;
				int nb_line_inserted_tMSSqlOutput_2 = 0;
				int nb_line_deleted_tMSSqlOutput_2 = 0;
				int nb_line_rejected_tMSSqlOutput_2 = 0;

				int deletedCount_tMSSqlOutput_2 = 0;
				int updatedCount_tMSSqlOutput_2 = 0;
				int insertedCount_tMSSqlOutput_2 = 0;
				int rejectedCount_tMSSqlOutput_2 = 0;
				String dbschema_tMSSqlOutput_2 = null;
				String tableName_tMSSqlOutput_2 = null;
				boolean whetherReject_tMSSqlOutput_2 = false;

				java.util.Calendar calendar_tMSSqlOutput_2 = java.util.Calendar
						.getInstance();
				long year1_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd",
						"0001-01-01").getTime();
				long year2_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd",
						"1753-01-01").getTime();
				long year10000_tMSSqlOutput_2 = TalendDate.parseDate(
						"yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00").getTime();
				long date_tMSSqlOutput_2;

				java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_2 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				java.sql.Connection conn_tMSSqlOutput_2 = null;
				String dbUser_tMSSqlOutput_2 = null;
				dbschema_tMSSqlOutput_2 = context.metadata_db_schema;
				String driverClass_tMSSqlOutput_2 = "net.sourceforge.jtds.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Driver ClassName: "
							+ driverClass_tMSSqlOutput_2 + ".");
				java.lang.Class.forName(driverClass_tMSSqlOutput_2);
				String port_tMSSqlOutput_2 = context.metadata_port;
				String dbname_tMSSqlOutput_2 = context.metadata_db_name;
				String url_tMSSqlOutput_2 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlOutput_2)) {
					url_tMSSqlOutput_2 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlOutput_2)) {
					url_tMSSqlOutput_2 += "//" + context.metadata_db_name;
				}
				url_tMSSqlOutput_2 += ";appName=" + projectName + ";" + "";
				dbUser_tMSSqlOutput_2 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlOutput_2 = context.metadata_db_pass;

				String dbPwd_tMSSqlOutput_2 = decryptedPassword_tMSSqlOutput_2;
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Connection attempts to '"
							+ url_tMSSqlOutput_2 + "' with the username '"
							+ dbUser_tMSSqlOutput_2 + "'.");
				conn_tMSSqlOutput_2 = java.sql.DriverManager.getConnection(
						url_tMSSqlOutput_2, dbUser_tMSSqlOutput_2,
						dbPwd_tMSSqlOutput_2);
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Connection to '"
							+ url_tMSSqlOutput_2 + "' has succeeded.");

				resourceMap.put("conn_tMSSqlOutput_2", conn_tMSSqlOutput_2);

				conn_tMSSqlOutput_2.setAutoCommit(false);
				int commitEvery_tMSSqlOutput_2 = 10000;
				int commitCounter_tMSSqlOutput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection is set auto commit to '"
							+ conn_tMSSqlOutput_2.getAutoCommit() + "'.");
				int batchSize_tMSSqlOutput_2 = 10000;
				int batchSizeCounter_tMSSqlOutput_2 = 0;

				if (dbschema_tMSSqlOutput_2 == null
						|| dbschema_tMSSqlOutput_2.trim().length() == 0) {
					tableName_tMSSqlOutput_2 = "rows_stat";
				} else {
					tableName_tMSSqlOutput_2 = dbschema_tMSSqlOutput_2 + "].["
							+ "rows_stat";
				}
				int count_tMSSqlOutput_2 = 0;

				java.sql.Statement isExistStmt_tMSSqlOutput_2 = conn_tMSSqlOutput_2
						.createStatement();
				boolean whetherExist_tMSSqlOutput_2 = false;
				try {
					isExistStmt_tMSSqlOutput_2.execute("SELECT TOP 1 1 FROM ["
							+ tableName_tMSSqlOutput_2 + "]");
					whetherExist_tMSSqlOutput_2 = true;
				} catch (java.lang.Exception e) {
					whetherExist_tMSSqlOutput_2 = false;
				}
				isExistStmt_tMSSqlOutput_2.close();
				if (!whetherExist_tMSSqlOutput_2) {
					java.sql.Statement stmtCreate_tMSSqlOutput_2 = conn_tMSSqlOutput_2
							.createStatement();
					if (log.isDebugEnabled())
						log.debug("tMSSqlOutput_2 - " + "Creating" + " table '"
								+ tableName_tMSSqlOutput_2 + "'.");
					stmtCreate_tMSSqlOutput_2
							.execute("CREATE TABLE ["
									+ tableName_tMSSqlOutput_2
									+ "]([Start_Time] DATETIME ,[EndTime] DATETIME ,[Project_name] VARCHAR(100)  ,[Job_name] VARCHAR(100)  ,[SRC_Input_Rows] INT ,[TGT_Output_Rows] INT ,[Rows_inserted_target] INT ,[Rows_updated_target] INT )");
					if (log.isDebugEnabled())
						log.debug("tMSSqlOutput_2 - " + "Create" + " table '"
								+ tableName_tMSSqlOutput_2 + "' has succeeded.");
					stmtCreate_tMSSqlOutput_2.close();
				}
				String insert_tMSSqlOutput_2 = "INSERT INTO ["
						+ tableName_tMSSqlOutput_2
						+ "] ([Start_Time],[EndTime],[Project_name],[Job_name],[SRC_Input_Rows],[TGT_Output_Rows],[Rows_inserted_target],[Rows_updated_target]) VALUES (?,?,?,?,?,?,?,?)";
				java.sql.PreparedStatement pstmt_tMSSqlOutput_2 = conn_tMSSqlOutput_2
						.prepareStatement(insert_tMSSqlOutput_2);

				/**
				 * [tMSSqlOutput_2 begin ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1",
						System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tFileOutputDelimited_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tFileOutputDelimited_1";

				int tos_count_tFileOutputDelimited_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputDelimited_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileOutputDelimited_1 = new StringBuilder();
				log4jParamters_tFileOutputDelimited_1.append("Parameters:");
				log4jParamters_tFileOutputDelimited_1.append("USESTREAM"
						+ " = " + "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("FILENAME" + " = "
						+ "context.file_ref_stat");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("ROWSEPARATOR"
						+ " = " + "\"\\n\"");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("FIELDSEPARATOR"
						+ " = " + "\";\"");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("APPEND" + " = "
						+ "true");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("INCLUDEHEADER"
						+ " = " + "true");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1
						.append("ADVANCED_SEPARATOR" + " = " + "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("CSV_OPTION"
						+ " = " + "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("CREATE" + " = "
						+ "true");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("SPLIT" + " = "
						+ "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("FLUSHONROW"
						+ " = " + "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("ROW_MODE" + " = "
						+ "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				log4jParamters_tFileOutputDelimited_1.append("DELETE_EMPTYFILE"
						+ " = " + "false");
				log4jParamters_tFileOutputDelimited_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileOutputDelimited_1 - "
							+ log4jParamters_tFileOutputDelimited_1);

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						context.file_ref_stat)).getAbsolutePath().replace("\\",
						"/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(0, fileName_tFileOutputDelimited_1
										.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1
										.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
							.substring(0, fileName_tFileOutputDelimited_1
									.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(0, fileName_tFileOutputDelimited_1
										.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1
										.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(
						fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",
						fileName_tFileOutputDelimited_1);
				if (filetFileOutputDelimited_1.exists()) {
					isFileGenerated_tFileOutputDelimited_1 = false;
				}
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitEvery_tFileOutputDelimited_1 = 1000;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /**
				 * Start field
				 * tFileOutputDelimited_1:FIELDSEPARATOR
				 */
				";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
				 * Start
				 * field tFileOutputDelimited_1:ROWSEPARATOR
				 */
				"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null
						&& directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(
							directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						log.info("tFileOutputDelimited_1 - Creating directory '"
								+ dir_tFileOutputDelimited_1.getCanonicalPath()
								+ "'.");
						dir_tFileOutputDelimited_1.mkdirs();
						log.info("tFileOutputDelimited_1 - The directory '"
								+ dir_tFileOutputDelimited_1.getCanonicalPath()
								+ "' has been created successfully.");
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				outtFileOutputDelimited_1 = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_tFileOutputDelimited_1, true),
								"ISO-8859-15"));
				synchronized (multiThreadLockWrite) {
					if (filetFileOutputDelimited_1.length() == 0) {
						outtFileOutputDelimited_1.write("Start_Time");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("EndTime");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("Project_name");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("Job_name");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("SRC_Input_Rows");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("TGT_Output_Rows");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("Rows_inserted_target");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.write("Rows_updated_target");
						outtFileOutputDelimited_1
								.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
						outtFileOutputDelimited_1.flush();
					}
				}

				resourceMap.put("out_tFileOutputDelimited_1",
						outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1",
						nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tReplicate_1 begin ] start
				 */

				ok_Hash.put("tReplicate_1", false);
				start_Hash.put("tReplicate_1", System.currentTimeMillis());

				currentComponent = "tReplicate_1";

				int tos_count_tReplicate_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tReplicate_1 - " + "Start to work.");
				StringBuilder log4jParamters_tReplicate_1 = new StringBuilder();
				log4jParamters_tReplicate_1.append("Parameters:");
				if (log.isDebugEnabled())
					log.debug("tReplicate_1 - " + log4jParamters_tReplicate_1);

				/**
				 * [tReplicate_1 begin ] stop
				 */

				/**
				 * [tFixedFlowInput_1 begin ] start
				 */

				ok_Hash.put("tFixedFlowInput_1", false);
				start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());

				currentComponent = "tFixedFlowInput_1";

				int tos_count_tFixedFlowInput_1 = 0;

				for (int i_tFixedFlowInput_1 = 0; i_tFixedFlowInput_1 < 1; i_tFixedFlowInput_1++) {

					row13.Start_Time = TalendDate.getCurrentDate();

					row13.EndTime = TalendDate.getCurrentDate();

					row13.Project_name = projectName;

					row13.Job_name = jobName;

					row13.SRC_Input_Rows = ((Integer) globalMap
							.get("tMSSqlInput_1_NB_LINE"));

					row13.TGT_Output_Rows = ((Integer) globalMap
							.get("tMSSqlOutput_1_NB_LINE"));

					row13.Rows_inserted_target = ((Integer) globalMap
							.get("tMSSqlOutput_1_NB_LINE_INSERTED"));

					row13.Rows_updated_target = ((Integer) globalMap
							.get("tMSSqlOutput_1_NB_LINE_UPDATED"));

					/**
					 * [tFixedFlowInput_1 begin ] stop
					 */

					/**
					 * [tFixedFlowInput_1 main ] start
					 */

					currentComponent = "tFixedFlowInput_1";

					tos_count_tFixedFlowInput_1++;

					/**
					 * [tFixedFlowInput_1 main ] stop
					 */

					/**
					 * [tReplicate_1 main ] start
					 */

					currentComponent = "tReplicate_1";

					if (log.isTraceEnabled()) {
						log.trace("row13 - "
								+ (row13 == null ? "" : row13.toLogString()));
					}

					row15 = new row15Struct();

					row15.Start_Time = row13.Start_Time;
					row15.EndTime = row13.EndTime;
					row15.Project_name = row13.Project_name;
					row15.Job_name = row13.Job_name;
					row15.SRC_Input_Rows = row13.SRC_Input_Rows;
					row15.TGT_Output_Rows = row13.TGT_Output_Rows;
					row15.Rows_inserted_target = row13.Rows_inserted_target;
					row15.Rows_updated_target = row13.Rows_updated_target;
					row16 = new row16Struct();

					row16.Start_Time = row13.Start_Time;
					row16.EndTime = row13.EndTime;
					row16.Project_name = row13.Project_name;
					row16.Job_name = row13.Job_name;
					row16.SRC_Input_Rows = row13.SRC_Input_Rows;
					row16.TGT_Output_Rows = row13.TGT_Output_Rows;
					row16.Rows_inserted_target = row13.Rows_inserted_target;
					row16.Rows_updated_target = row13.Rows_updated_target;

					tos_count_tReplicate_1++;

					/**
					 * [tReplicate_1 main ] stop
					 */

					/**
					 * [tMSSqlOutput_2 main ] start
					 */

					currentComponent = "tMSSqlOutput_2";

					if (log.isTraceEnabled()) {
						log.trace("row15 - "
								+ (row15 == null ? "" : row15.toLogString()));
					}

					whetherReject_tMSSqlOutput_2 = false;
					if (row15.Start_Time != null) {
						pstmt_tMSSqlOutput_2.setTimestamp(
								1,
								new java.sql.Timestamp(row15.Start_Time
										.getTime()));
					} else {
						pstmt_tMSSqlOutput_2.setNull(1, java.sql.Types.DATE);
					}

					if (row15.EndTime != null) {
						pstmt_tMSSqlOutput_2
								.setTimestamp(2, new java.sql.Timestamp(
										row15.EndTime.getTime()));
					} else {
						pstmt_tMSSqlOutput_2.setNull(2, java.sql.Types.DATE);
					}

					if (row15.Project_name == null) {
						pstmt_tMSSqlOutput_2.setNull(3, java.sql.Types.VARCHAR);
					} else {
						pstmt_tMSSqlOutput_2.setString(3, row15.Project_name);
					}

					if (row15.Job_name == null) {
						pstmt_tMSSqlOutput_2.setNull(4, java.sql.Types.VARCHAR);
					} else {
						pstmt_tMSSqlOutput_2.setString(4, row15.Job_name);
					}

					if (row15.SRC_Input_Rows == null) {
						pstmt_tMSSqlOutput_2.setNull(5, java.sql.Types.INTEGER);
					} else {
						pstmt_tMSSqlOutput_2.setInt(5, row15.SRC_Input_Rows);
					}

					if (row15.TGT_Output_Rows == null) {
						pstmt_tMSSqlOutput_2.setNull(6, java.sql.Types.INTEGER);
					} else {
						pstmt_tMSSqlOutput_2.setInt(6, row15.TGT_Output_Rows);
					}

					if (row15.Rows_inserted_target == null) {
						pstmt_tMSSqlOutput_2.setNull(7, java.sql.Types.INTEGER);
					} else {
						pstmt_tMSSqlOutput_2.setInt(7,
								row15.Rows_inserted_target);
					}

					if (row15.Rows_updated_target == null) {
						pstmt_tMSSqlOutput_2.setNull(8, java.sql.Types.INTEGER);
					} else {
						pstmt_tMSSqlOutput_2.setInt(8,
								row15.Rows_updated_target);
					}

					pstmt_tMSSqlOutput_2.addBatch();
					nb_line_tMSSqlOutput_2++;

					if (log.isDebugEnabled())
						log.debug("tMSSqlOutput_2 - " + "Adding the record "
								+ nb_line_tMSSqlOutput_2 + " to the "
								+ "INSERT" + " batch.");
					batchSizeCounter_tMSSqlOutput_2++;

					if ((batchSize_tMSSqlOutput_2 > 0)
							&& (batchSize_tMSSqlOutput_2 <= batchSizeCounter_tMSSqlOutput_2)) {
						try {
							int countSum_tMSSqlOutput_2 = 0;

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - "
										+ "Executing the " + "INSERT"
										+ " batch.");
							for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
									.executeBatch()) {
								if (countEach_tMSSqlOutput_2 == -2
										|| countEach_tMSSqlOutput_2 == -3) {
									break;
								}
								countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
							}

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - " + "The "
										+ "INSERT"
										+ " batch execution has succeeded.");

							insertedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

							batchSizeCounter_tMSSqlOutput_2 = 0;
						} catch (java.sql.BatchUpdateException e) {

							throw (e);

						}
					}

					commitCounter_tMSSqlOutput_2++;
					if (commitEvery_tMSSqlOutput_2 <= commitCounter_tMSSqlOutput_2) {
						if ((batchSize_tMSSqlOutput_2 > 0)
								&& (batchSizeCounter_tMSSqlOutput_2 > 0)) {
							try {
								int countSum_tMSSqlOutput_2 = 0;

								if (log.isDebugEnabled())
									log.debug("tMSSqlOutput_2 - "
											+ "Executing the " + "INSERT"
											+ " batch.");
								for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
										.executeBatch()) {
									if (countEach_tMSSqlOutput_2 == -2
											|| countEach_tMSSqlOutput_2 == -3) {
										break;
									}
									countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
								}

								if (log.isDebugEnabled())
									log.debug("tMSSqlOutput_2 - " + "The "
											+ "INSERT"
											+ " batch execution has succeeded.");

								insertedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

								batchSizeCounter_tMSSqlOutput_2 = 0;
							} catch (java.sql.BatchUpdateException e) {

								throw (e);

							}
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - "
									+ "Connection starting to commit "
									+ commitCounter_tMSSqlOutput_2
									+ " record(s).");
						conn_tMSSqlOutput_2.commit();

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - "
									+ "Connection commit has succeeded.");
						commitCounter_tMSSqlOutput_2 = 0;
					}

					tos_count_tMSSqlOutput_2++;

					/**
					 * [tMSSqlOutput_2 main ] stop
					 */

					/**
					 * [tFileOutputDelimited_1 main ] start
					 */

					currentComponent = "tFileOutputDelimited_1";

					if (log.isTraceEnabled()) {
						log.trace("row16 - "
								+ (row16 == null ? "" : row16.toLogString()));
					}

					StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
					if (row16.Start_Time != null) {
						sb_tFileOutputDelimited_1.append(FormatterUtils
								.format_Date(row16.Start_Time,
										"yyyy-MM-dd-HH-mm"));
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.EndTime != null) {
						sb_tFileOutputDelimited_1
								.append(FormatterUtils.format_Date(
										row16.EndTime, "yyyy-MM-dd-HH-mm"));
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.Project_name != null) {
						sb_tFileOutputDelimited_1.append(row16.Project_name);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.Job_name != null) {
						sb_tFileOutputDelimited_1.append(row16.Job_name);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.SRC_Input_Rows != null) {
						sb_tFileOutputDelimited_1.append(row16.SRC_Input_Rows);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.TGT_Output_Rows != null) {
						sb_tFileOutputDelimited_1.append(row16.TGT_Output_Rows);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.Rows_inserted_target != null) {
						sb_tFileOutputDelimited_1
								.append(row16.Rows_inserted_target);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_tFileOutputDelimited_1);
					if (row16.Rows_updated_target != null) {
						sb_tFileOutputDelimited_1
								.append(row16.Rows_updated_target);
					}
					sb_tFileOutputDelimited_1
							.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

					synchronized (multiThreadLockWrite) {
						nb_line_tFileOutputDelimited_1++;
						resourceMap.put("nb_line_tFileOutputDelimited_1",
								nb_line_tFileOutputDelimited_1);

						outtFileOutputDelimited_1
								.write(sb_tFileOutputDelimited_1.toString());
						log.debug("tFileOutputDelimited_1 - Writing the record "
								+ nb_line_tFileOutputDelimited_1 + ".");

					}

					tos_count_tFileOutputDelimited_1++;

					/**
					 * [tFileOutputDelimited_1 main ] stop
					 */

					/**
					 * [tFixedFlowInput_1 end ] start
					 */

					currentComponent = "tFixedFlowInput_1";

				}
				globalMap.put("tFixedFlowInput_1_NB_LINE", 1);

				ok_Hash.put("tFixedFlowInput_1", true);
				end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());

				/**
				 * [tFixedFlowInput_1 end ] stop
				 */

				/**
				 * [tReplicate_1 end ] start
				 */

				currentComponent = "tReplicate_1";

				if (log.isDebugEnabled())
					log.debug("tReplicate_1 - " + "Done.");

				ok_Hash.put("tReplicate_1", true);
				end_Hash.put("tReplicate_1", System.currentTimeMillis());

				/**
				 * [tReplicate_1 end ] stop
				 */

				/**
				 * [tMSSqlOutput_2 end ] start
				 */

				currentComponent = "tMSSqlOutput_2";

				try {
					int countSum_tMSSqlOutput_2 = 0;
					if (pstmt_tMSSqlOutput_2 != null
							&& batchSizeCounter_tMSSqlOutput_2 > 0) {

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - " + "Executing the "
									+ "INSERT" + " batch.");
						for (int countEach_tMSSqlOutput_2 : pstmt_tMSSqlOutput_2
								.executeBatch()) {
							if (countEach_tMSSqlOutput_2 == -2
									|| countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							countSum_tMSSqlOutput_2 += countEach_tMSSqlOutput_2;
						}

						if (log.isDebugEnabled())
							log.debug("tMSSqlOutput_2 - " + "The " + "INSERT"
									+ " batch execution has succeeded.");
					}

					insertedCount_tMSSqlOutput_2 += countSum_tMSSqlOutput_2;

				} catch (java.sql.BatchUpdateException e) {

					throw (e);

				}
				if (pstmt_tMSSqlOutput_2 != null) {

					pstmt_tMSSqlOutput_2.close();

				}

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection starting to commit "
							+ commitCounter_tMSSqlOutput_2 + " record(s).");
				conn_tMSSqlOutput_2.commit();

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection commit has succeeded.");
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Closing the connection to the database.");
				conn_tMSSqlOutput_2.close();
				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - "
							+ "Connection to the database has closed.");
				resourceMap.put("finish_tMSSqlOutput_2", true);

				nb_line_deleted_tMSSqlOutput_2 = nb_line_deleted_tMSSqlOutput_2
						+ deletedCount_tMSSqlOutput_2;
				nb_line_update_tMSSqlOutput_2 = nb_line_update_tMSSqlOutput_2
						+ updatedCount_tMSSqlOutput_2;
				nb_line_inserted_tMSSqlOutput_2 = nb_line_inserted_tMSSqlOutput_2
						+ insertedCount_tMSSqlOutput_2;
				nb_line_rejected_tMSSqlOutput_2 = nb_line_rejected_tMSSqlOutput_2
						+ rejectedCount_tMSSqlOutput_2;

				globalMap.put("tMSSqlOutput_2_NB_LINE", nb_line_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_UPDATED",
						nb_line_update_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_INSERTED",
						nb_line_inserted_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_DELETED",
						nb_line_deleted_tMSSqlOutput_2);
				globalMap.put("tMSSqlOutput_2_NB_LINE_REJECTED",
						nb_line_rejected_tMSSqlOutput_2);

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Has " + "inserted" + " "
							+ nb_line_inserted_tMSSqlOutput_2 + " record(s).");

				if (log.isDebugEnabled())
					log.debug("tMSSqlOutput_2 - " + "Done.");

				ok_Hash.put("tMSSqlOutput_2", true);
				end_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlOutput_2",
						end_Hash.get("tMSSqlOutput_2")
								- start_Hash.get("tMSSqlOutput_2"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tMSSqlOutput_2 end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				synchronized (multiThreadLockWrite) {

					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

					globalMap.put("tFileOutputDelimited_1_NB_LINE",
							nb_line_tFileOutputDelimited_1);
					globalMap.put("tFileOutputDelimited_1_FILE_NAME",
							fileName_tFileOutputDelimited_1);

				}

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				log.debug("tFileOutputDelimited_1 - Written records count: "
						+ nb_line_tFileOutputDelimited_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tFileOutputDelimited_1 - " + "Done.");

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1",
						System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tFileOutputDelimited_1",
						end_Hash.get("tFileOutputDelimited_1")
								- start_Hash.get("tFileOutputDelimited_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tFixedFlowInput_1 finally ] start
				 */

				currentComponent = "tFixedFlowInput_1";

				/**
				 * [tFixedFlowInput_1 finally ] stop
				 */

				/**
				 * [tReplicate_1 finally ] start
				 */

				currentComponent = "tReplicate_1";

				/**
				 * [tReplicate_1 finally ] stop
				 */

				/**
				 * [tMSSqlOutput_2 finally ] start
				 */

				currentComponent = "tMSSqlOutput_2";

				if (resourceMap.get("finish_tMSSqlOutput_2") == null) {
					if (resourceMap.get("conn_tMSSqlOutput_2") != null) {
						try {

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - "
										+ "Closing the connection to the database.");
							((java.sql.Connection) resourceMap
									.get("conn_tMSSqlOutput_2")).close();

							if (log.isDebugEnabled())
								log.debug("tMSSqlOutput_2 - "
										+ "Connection to the database has closed.");
						} catch (java.sql.SQLException sqlEx_tMSSqlOutput_2) {
							String errorMessage_tMSSqlOutput_2 = "failed to close the connection in tMSSqlOutput_2 :"
									+ sqlEx_tMSSqlOutput_2.getMessage();

							log.error("tMSSqlOutput_2 - "
									+ errorMessage_tMSSqlOutput_2);
							System.err.println(errorMessage_tMSSqlOutput_2);
						}
					}
				}

				/**
				 * [tMSSqlOutput_2 finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					synchronized (multiThreadLockWrite) {

						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
								.get("out_tFileOutputDelimited_1");
						if (outtFileOutputDelimited_1 != null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}

					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_11Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_11_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_11 begin ] start
				 */

				ok_Hash.put("tJava_11", false);
				start_Hash.put("tJava_11", System.currentTimeMillis());

				currentComponent = "tJava_11";

				int tos_count_tJava_11 = 0;

				System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
						+ "|********** MSSQL SRC Table : " + context.table_nme
						+ " Read Successfully!!!!! **********");

				System.out
						.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
								+ "|********** Data Masking Rule Implementation started For the MSSQL Table: "
								+ context.table_nme + " **********");

				/**
				 * [tJava_11 begin ] stop
				 */

				/**
				 * [tJava_11 main ] start
				 */

				currentComponent = "tJava_11";

				tos_count_tJava_11++;

				/**
				 * [tJava_11 main ] stop
				 */

				/**
				 * [tJava_11 end ] start
				 */

				currentComponent = "tJava_11";

				ok_Hash.put("tJava_11", true);
				end_Hash.put("tJava_11", System.currentTimeMillis());

				/**
				 * [tJava_11 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_11 finally ] start
				 */

				currentComponent = "tJava_11";

				/**
				 * [tJava_11 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_11_SUBPROCESS_STATE", 1);
	}

	public static class row11Struct implements
			routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tMSSqlInput_4Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tMSSqlInput_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row11Struct row11 = new row11Struct();

				/**
				 * [tJavaRow_2 begin ] start
				 */

				ok_Hash.put("tJavaRow_2", false);
				start_Hash.put("tJavaRow_2", System.currentTimeMillis());

				currentComponent = "tJavaRow_2";

				int tos_count_tJavaRow_2 = 0;

				int nb_line_tJavaRow_2 = 0;

				/**
				 * [tJavaRow_2 begin ] stop
				 */

				/**
				 * [tMSSqlInput_4 begin ] start
				 */

				ok_Hash.put("tMSSqlInput_4", false);
				start_Hash.put("tMSSqlInput_4", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlInput_4");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlInput_4";

				int tos_count_tMSSqlInput_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_4 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlInput_4 = new StringBuilder();
				log4jParamters_tMSSqlInput_4.append("Parameters:");
				log4jParamters_tMSSqlInput_4.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4
						.append("QUERY"
								+ " = "
								+ "\"SELECT db_type,  		db_nme,  		db_schema,  		host,  		port,  		db_user,  		db_pass,  		active  FROM	schema_connection_details  where active=1 and db_type=\"+\"\\'\"+context.tgt_db_type+\"\\'\"+\" and \"+\"db_nme=\"+\"\\'\"+context.tgt_db_nme+\"\\'\"+\" and \"+\"db_schema=\"+\"\\'\"+context.tgt_db_schema+\"\\'\"");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tMSSqlInput_4.append(" | ");
				log4jParamters_tMSSqlInput_4.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_type") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("db_nme") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_schema")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("host") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("port") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_user")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_pass") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("active") + "}]");
				log4jParamters_tMSSqlInput_4.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_4 - " + log4jParamters_tMSSqlInput_4);

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tMSSqlInput_4 = new java.util.ArrayList();
				String[] talendToDBArray_tMSSqlInput_4 = new String[] {
						"FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tMSSqlInput_4,
						talendToDBArray_tMSSqlInput_4);
				int nb_line_tMSSqlInput_4 = 0;
				java.sql.Connection conn_tMSSqlInput_4 = null;
				String driverClass_tMSSqlInput_4 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class.forName(driverClass_tMSSqlInput_4);
				String dbUser_tMSSqlInput_4 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlInput_4 = context.metadata_db_pass;

				String dbPwd_tMSSqlInput_4 = decryptedPassword_tMSSqlInput_4;

				String port_tMSSqlInput_4 = context.metadata_port;
				String dbname_tMSSqlInput_4 = context.metadata_db_name;
				String url_tMSSqlInput_4 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlInput_4)) {
					url_tMSSqlInput_4 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlInput_4)) {
					url_tMSSqlInput_4 += "//" + context.metadata_db_name;
				}
				url_tMSSqlInput_4 += ";appName=" + projectName + ";" + "";
				String dbschema_tMSSqlInput_4 = context.metadata_db_schema;

				log.debug("tMSSqlInput_4 - Driver ClassName: "
						+ driverClass_tMSSqlInput_4 + ".");

				log.debug("tMSSqlInput_4 - Connection attempt to '"
						+ url_tMSSqlInput_4 + "' with the username '"
						+ dbUser_tMSSqlInput_4 + "'.");

				conn_tMSSqlInput_4 = java.sql.DriverManager.getConnection(
						url_tMSSqlInput_4, dbUser_tMSSqlInput_4,
						dbPwd_tMSSqlInput_4);
				log.debug("tMSSqlInput_4 - Connection to '" + url_tMSSqlInput_4
						+ "' has succeeded.");

				java.sql.Statement stmt_tMSSqlInput_4 = conn_tMSSqlInput_4
						.createStatement();

				String dbquery_tMSSqlInput_4 = "SELECT db_type,\n		db_nme,\n		db_schema,\n		host,\n		port,\n		db_user,\n		db_pass,\n		active\nFROM	schema_connection_details\nwhere active=1 and db_type="
						+ "\'"
						+ context.tgt_db_type
						+ "\'"
						+ " and "
						+ "db_nme="
						+ "\'"
						+ context.tgt_db_nme
						+ "\'"
						+ " and "
						+ "db_schema="
						+ "\'"
						+ context.tgt_db_schema
						+ "\'";

				log.debug("tMSSqlInput_4 - Executing the query: '"
						+ dbquery_tMSSqlInput_4 + "'.");

				globalMap.put("tMSSqlInput_4_QUERY", dbquery_tMSSqlInput_4);

				java.sql.ResultSet rs_tMSSqlInput_4 = null;
				try {
					rs_tMSSqlInput_4 = stmt_tMSSqlInput_4
							.executeQuery(dbquery_tMSSqlInput_4);
					java.sql.ResultSetMetaData rsmd_tMSSqlInput_4 = rs_tMSSqlInput_4
							.getMetaData();
					int colQtyInRs_tMSSqlInput_4 = rsmd_tMSSqlInput_4
							.getColumnCount();

					String tmpContent_tMSSqlInput_4 = null;

					log.debug("tMSSqlInput_4 - Retrieving records from the database.");

					while (rs_tMSSqlInput_4.next()) {
						nb_line_tMSSqlInput_4++;

						if (colQtyInRs_tMSSqlInput_4 < 1) {
							row11.db_type = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(1);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(1)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.db_type = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.db_type = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.db_type = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 2) {
							row11.db_nme = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(2);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(2)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.db_nme = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.db_nme = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.db_nme = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 3) {
							row11.db_schema = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(3);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(3)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.db_schema = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.db_schema = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.db_schema = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 4) {
							row11.host = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(4);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(4)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.host = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.host = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.host = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 5) {
							row11.port = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(5);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(5)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.port = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.port = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.port = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 6) {
							row11.db_user = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(6);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(6)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.db_user = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.db_user = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.db_user = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 7) {
							row11.db_pass = null;
						} else {

							tmpContent_tMSSqlInput_4 = rs_tMSSqlInput_4
									.getString(7);
							if (tmpContent_tMSSqlInput_4 != null) {
								if (talendToDBList_tMSSqlInput_4
										.contains(rsmd_tMSSqlInput_4
												.getColumnTypeName(7)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row11.db_pass = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_4);
								} else {
									row11.db_pass = tmpContent_tMSSqlInput_4;
								}
							} else {
								row11.db_pass = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_4 < 8) {
							row11.active = null;
						} else {

							if (rs_tMSSqlInput_4.getObject(8) != null) {
								row11.active = rs_tMSSqlInput_4.getInt(8);
							} else {
								row11.active = null;
							}
						}

						log.debug("tMSSqlInput_4 - Retrieving the record "
								+ nb_line_tMSSqlInput_4 + ".");

						/**
						 * [tMSSqlInput_4 begin ] stop
						 */

						/**
						 * [tMSSqlInput_4 main ] start
						 */

						currentComponent = "tMSSqlInput_4";

						tos_count_tMSSqlInput_4++;

						/**
						 * [tMSSqlInput_4 main ] stop
						 */

						/**
						 * [tJavaRow_2 main ] start
						 */

						currentComponent = "tJavaRow_2";

						if (log.isTraceEnabled()) {
							log.trace("row11 - "
									+ (row11 == null ? "" : row11.toLogString()));
						}

						// Code generated according to input schema and output
						// schema
						/*
						 * output_row.db_type = row11.db_type; output_row.db_nme
						 * = row11.db_nme; output_row.db_schema =
						 * row11.db_schema; output_row.host = row11.host;
						 * output_row.port = row11.port; output_row.db_user =
						 * row11.db_user; output_row.db_pass = row11.db_pass;
						 * //output_row.active = row11.active;
						 */

						context.tgt_db_type = row11.db_type;
						context.tgt_db_nme = row11.db_nme;
						context.tgt_db_schema = row11.db_schema;
						context.tgt_host = row11.host;
						context.tgt_port = row11.port;
						context.tgt_db_user = row11.db_user;
						context.tgt_db_pass = row11.db_pass;

						nb_line_tJavaRow_2++;

						tos_count_tJavaRow_2++;

						/**
						 * [tJavaRow_2 main ] stop
						 */

						/**
						 * [tMSSqlInput_4 end ] start
						 */

						currentComponent = "tMSSqlInput_4";

					}
				} finally {
					stmt_tMSSqlInput_4.close();

					if (conn_tMSSqlInput_4 != null
							&& !conn_tMSSqlInput_4.isClosed()) {

						log.debug("tMSSqlInput_4 - Closing the connection to the database.");

						conn_tMSSqlInput_4.close();

						log.debug("tMSSqlInput_4 - Connection to the database closed.");

					}
				}
				globalMap.put("tMSSqlInput_4_NB_LINE", nb_line_tMSSqlInput_4);
				log.debug("tMSSqlInput_4 - Retrieved records count: "
						+ nb_line_tMSSqlInput_4 + " .");

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_4 - " + "Done.");

				ok_Hash.put("tMSSqlInput_4", true);
				end_Hash.put("tMSSqlInput_4", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlInput_4",
						end_Hash.get("tMSSqlInput_4")
								- start_Hash.get("tMSSqlInput_4"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tMSSqlInput_4 end ] stop
				 */

				/**
				 * [tJavaRow_2 end ] start
				 */

				currentComponent = "tJavaRow_2";

				globalMap.put("tJavaRow_2_NB_LINE", nb_line_tJavaRow_2);

				ok_Hash.put("tJavaRow_2", true);
				end_Hash.put("tJavaRow_2", System.currentTimeMillis());

				/**
				 * [tJavaRow_2 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tMSSqlInput_4 finally ] start
				 */

				currentComponent = "tMSSqlInput_4";

				/**
				 * [tMSSqlInput_4 finally ] stop
				 */

				/**
				 * [tJavaRow_2 finally ] start
				 */

				currentComponent = "tJavaRow_2";

				/**
				 * [tJavaRow_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMSSqlInput_4_SUBPROCESS_STATE", 1);
	}

	public static class row14Struct implements
			routines.system.IPersistableRow<row14Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String table_nme;

		public String getTable_nme() {
			return this.table_nme;
		}

		public String src_filter;

		public String getSrc_filter() {
			return this.src_filter;
		}

		public String src_custom_sql;

		public String getSrc_custom_sql() {
			return this.src_custom_sql;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.src_db_type = readString(dis);

					this.src_db_nme = readString(dis);

					this.src_db_schema = readString(dis);

					this.table_nme = readString(dis);

					this.src_filter = readString(dis);

					this.src_custom_sql = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.src_db_type, dos);

				// String

				writeString(this.src_db_nme, dos);

				// String

				writeString(this.src_db_schema, dos);

				// String

				writeString(this.table_nme, dos);

				// String

				writeString(this.src_filter, dos);

				// String

				writeString(this.src_custom_sql, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("src_db_type=" + src_db_type);
			sb.append(",src_db_nme=" + src_db_nme);
			sb.append(",src_db_schema=" + src_db_schema);
			sb.append(",table_nme=" + table_nme);
			sb.append(",src_filter=" + src_filter);
			sb.append(",src_custom_sql=" + src_custom_sql);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (src_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_type);
			}

			sb.append("|");

			if (src_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_nme);
			}

			sb.append("|");

			if (src_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_schema);
			}

			sb.append("|");

			if (table_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(table_nme);
			}

			sb.append("|");

			if (src_filter == null) {
				sb.append("<null>");
			} else {
				sb.append(src_filter);
			}

			sb.append("|");

			if (src_custom_sql == null) {
				sb.append("<null>");
			} else {
				sb.append(src_custom_sql);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row14Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tMSSqlInput_5Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tMSSqlInput_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row14Struct row14 = new row14Struct();

				/**
				 * [tJavaRow_6 begin ] start
				 */

				ok_Hash.put("tJavaRow_6", false);
				start_Hash.put("tJavaRow_6", System.currentTimeMillis());

				currentComponent = "tJavaRow_6";

				int tos_count_tJavaRow_6 = 0;

				int nb_line_tJavaRow_6 = 0;

				/**
				 * [tJavaRow_6 begin ] stop
				 */

				/**
				 * [tMSSqlInput_5 begin ] start
				 */

				ok_Hash.put("tMSSqlInput_5", false);
				start_Hash.put("tMSSqlInput_5", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlInput_5");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlInput_5";

				int tos_count_tMSSqlInput_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_5 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlInput_5 = new StringBuilder();
				log4jParamters_tMSSqlInput_5.append("Parameters:");
				log4jParamters_tMSSqlInput_5.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("TABLE" + " = "
						+ "\"custom_sql_details\"");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5
						.append("QUERY"
								+ " = "
								+ "\"SELECT src_db_type,  		src_db_nme,  		src_db_schema,  		table_nme,  		src_filter,  		src_custom_sql,  		active  FROM	custom_sql_details  where active=1 and src_db_type=\"+\"\\'\"+context.src_db_type+\"\\'\"+\" and \"+\"src_db_nme=\"+\"\\'\"+context.src_db_nme+\"\\'\"+\" and \"+\"src_db_schema=\"+\"\\'\"+context.src_db_schema+\"\\'\"+\" and \"+\"table_nme=\"+\"\\'\"+context.table_nme+\"\\'\"");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tMSSqlInput_5.append(" | ");
				log4jParamters_tMSSqlInput_5.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("src_db_type") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("src_db_nme") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("src_db_schema")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("table_nme") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("src_filter") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("src_custom_sql")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("active") + "}]");
				log4jParamters_tMSSqlInput_5.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_5 - " + log4jParamters_tMSSqlInput_5);

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_5 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tMSSqlInput_5 = new java.util.ArrayList();
				String[] talendToDBArray_tMSSqlInput_5 = new String[] {
						"FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tMSSqlInput_5,
						talendToDBArray_tMSSqlInput_5);
				int nb_line_tMSSqlInput_5 = 0;
				java.sql.Connection conn_tMSSqlInput_5 = null;
				String driverClass_tMSSqlInput_5 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class.forName(driverClass_tMSSqlInput_5);
				String dbUser_tMSSqlInput_5 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlInput_5 = context.metadata_db_pass;

				String dbPwd_tMSSqlInput_5 = decryptedPassword_tMSSqlInput_5;

				String port_tMSSqlInput_5 = context.metadata_port;
				String dbname_tMSSqlInput_5 = context.metadata_db_name;
				String url_tMSSqlInput_5 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlInput_5)) {
					url_tMSSqlInput_5 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlInput_5)) {
					url_tMSSqlInput_5 += "//" + context.metadata_db_name;
				}
				url_tMSSqlInput_5 += ";appName=" + projectName + ";" + "";
				String dbschema_tMSSqlInput_5 = context.metadata_db_schema;

				log.debug("tMSSqlInput_5 - Driver ClassName: "
						+ driverClass_tMSSqlInput_5 + ".");

				log.debug("tMSSqlInput_5 - Connection attempt to '"
						+ url_tMSSqlInput_5 + "' with the username '"
						+ dbUser_tMSSqlInput_5 + "'.");

				conn_tMSSqlInput_5 = java.sql.DriverManager.getConnection(
						url_tMSSqlInput_5, dbUser_tMSSqlInput_5,
						dbPwd_tMSSqlInput_5);
				log.debug("tMSSqlInput_5 - Connection to '" + url_tMSSqlInput_5
						+ "' has succeeded.");

				java.sql.Statement stmt_tMSSqlInput_5 = conn_tMSSqlInput_5
						.createStatement();

				String dbquery_tMSSqlInput_5 = "SELECT src_db_type,\n		src_db_nme,\n		src_db_schema,\n		table_nme,\n		src_filter,\n		src_custom_sql,\n		active\nFROM	custom_sql_details\nwhere active=1 and src_db_type="
						+ "\'"
						+ context.src_db_type
						+ "\'"
						+ " and "
						+ "src_db_nme="
						+ "\'"
						+ context.src_db_nme
						+ "\'"
						+ " and "
						+ "src_db_schema="
						+ "\'"
						+ context.src_db_schema
						+ "\'"
						+ " and "
						+ "table_nme="
						+ "\'" + context.table_nme + "\'";

				log.debug("tMSSqlInput_5 - Executing the query: '"
						+ dbquery_tMSSqlInput_5 + "'.");

				globalMap.put("tMSSqlInput_5_QUERY", dbquery_tMSSqlInput_5);

				java.sql.ResultSet rs_tMSSqlInput_5 = null;
				try {
					rs_tMSSqlInput_5 = stmt_tMSSqlInput_5
							.executeQuery(dbquery_tMSSqlInput_5);
					java.sql.ResultSetMetaData rsmd_tMSSqlInput_5 = rs_tMSSqlInput_5
							.getMetaData();
					int colQtyInRs_tMSSqlInput_5 = rsmd_tMSSqlInput_5
							.getColumnCount();

					String tmpContent_tMSSqlInput_5 = null;

					log.debug("tMSSqlInput_5 - Retrieving records from the database.");

					while (rs_tMSSqlInput_5.next()) {
						nb_line_tMSSqlInput_5++;

						if (colQtyInRs_tMSSqlInput_5 < 1) {
							row14.src_db_type = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(1);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(1)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.src_db_type = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.src_db_type = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.src_db_type = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 2) {
							row14.src_db_nme = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(2);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(2)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.src_db_nme = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.src_db_nme = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.src_db_nme = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 3) {
							row14.src_db_schema = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(3);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(3)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.src_db_schema = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.src_db_schema = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.src_db_schema = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 4) {
							row14.table_nme = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(4);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(4)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.table_nme = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.table_nme = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.table_nme = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 5) {
							row14.src_filter = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(5);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(5)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.src_filter = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.src_filter = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.src_filter = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 6) {
							row14.src_custom_sql = null;
						} else {

							tmpContent_tMSSqlInput_5 = rs_tMSSqlInput_5
									.getString(6);
							if (tmpContent_tMSSqlInput_5 != null) {
								if (talendToDBList_tMSSqlInput_5
										.contains(rsmd_tMSSqlInput_5
												.getColumnTypeName(6)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row14.src_custom_sql = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_5);
								} else {
									row14.src_custom_sql = tmpContent_tMSSqlInput_5;
								}
							} else {
								row14.src_custom_sql = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_5 < 7) {
							row14.active = null;
						} else {

							if (rs_tMSSqlInput_5.getObject(7) != null) {
								row14.active = rs_tMSSqlInput_5.getInt(7);
							} else {
								row14.active = null;
							}
						}

						log.debug("tMSSqlInput_5 - Retrieving the record "
								+ nb_line_tMSSqlInput_5 + ".");

						/**
						 * [tMSSqlInput_5 begin ] stop
						 */

						/**
						 * [tMSSqlInput_5 main ] start
						 */

						currentComponent = "tMSSqlInput_5";

						tos_count_tMSSqlInput_5++;

						/**
						 * [tMSSqlInput_5 main ] stop
						 */

						/**
						 * [tJavaRow_6 main ] start
						 */

						currentComponent = "tJavaRow_6";

						if (log.isTraceEnabled()) {
							log.trace("row14 - "
									+ (row14 == null ? "" : row14.toLogString()));
						}

						if (row14.src_custom_sql == null) {
							if (row14.src_filter == null) {

								context.src_sql = "SELECT * FROM "
										+ row14.table_nme;
							} else {
								context.src_sql = "SELECT * FROM "
										+ row14.table_nme
										+ " "
										+ SQLFilters.getSQL(globalMap,
												row14.src_filter);
							}
						} else {
							context.src_sql = "SELECT * FROM "
									+ row14.table_nme
									+ " "
									+ SQLFilters.getSQL(globalMap,
											row14.src_custom_sql);
						}
						nb_line_tJavaRow_6++;

						tos_count_tJavaRow_6++;

						/**
						 * [tJavaRow_6 main ] stop
						 */

						/**
						 * [tMSSqlInput_5 end ] start
						 */

						currentComponent = "tMSSqlInput_5";

					}
				} finally {
					stmt_tMSSqlInput_5.close();

					if (conn_tMSSqlInput_5 != null
							&& !conn_tMSSqlInput_5.isClosed()) {

						log.debug("tMSSqlInput_5 - Closing the connection to the database.");

						conn_tMSSqlInput_5.close();

						log.debug("tMSSqlInput_5 - Connection to the database closed.");

					}
				}
				globalMap.put("tMSSqlInput_5_NB_LINE", nb_line_tMSSqlInput_5);
				log.debug("tMSSqlInput_5 - Retrieved records count: "
						+ nb_line_tMSSqlInput_5 + " .");

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_5 - " + "Done.");

				ok_Hash.put("tMSSqlInput_5", true);
				end_Hash.put("tMSSqlInput_5", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlInput_5",
						end_Hash.get("tMSSqlInput_5")
								- start_Hash.get("tMSSqlInput_5"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tMSSqlInput_5 end ] stop
				 */

				/**
				 * [tJavaRow_6 end ] start
				 */

				currentComponent = "tJavaRow_6";

				globalMap.put("tJavaRow_6_NB_LINE", nb_line_tJavaRow_6);

				ok_Hash.put("tJavaRow_6", true);
				end_Hash.put("tJavaRow_6", System.currentTimeMillis());

				/**
				 * [tJavaRow_6 end ] stop
				 */

			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tMSSqlInput_5:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tJava_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tMSSqlInput_5 finally ] start
				 */

				currentComponent = "tMSSqlInput_5";

				/**
				 * [tMSSqlInput_5 finally ] stop
				 */

				/**
				 * [tJavaRow_6 finally ] start
				 */

				currentComponent = "tJavaRow_6";

				/**
				 * [tJavaRow_6 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMSSqlInput_5_SUBPROCESS_STATE", 1);
	}

	public void tJava_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_1 begin ] start
				 */

				ok_Hash.put("tJava_1", false);
				start_Hash.put("tJava_1", System.currentTimeMillis());

				currentComponent = "tJava_1";

				int tos_count_tJava_1 = 0;

				if (context.src_sql.isEmpty())
					context.src_sql = "SELECT * FROM " + context.table_nme;

				/**
				 * [tJava_1 begin ] stop
				 */

				/**
				 * [tJava_1 main ] start
				 */

				currentComponent = "tJava_1";

				tos_count_tJava_1++;

				/**
				 * [tJava_1 main ] stop
				 */

				/**
				 * [tJava_1 end ] start
				 */

				currentComponent = "tJava_1";

				ok_Hash.put("tJava_1", true);
				end_Hash.put("tJava_1", System.currentTimeMillis());

				/**
				 * [tJava_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_1 finally ] start
				 */

				currentComponent = "tJava_1";

				/**
				 * [tJava_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}

	public static class out3Struct implements
			routines.system.IPersistableRow<out3Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String src_db_type;

		public String getSrc_db_type() {
			return this.src_db_type;
		}

		public String src_db_nme;

		public String getSrc_db_nme() {
			return this.src_db_nme;
		}

		public String src_db_schema;

		public String getSrc_db_schema() {
			return this.src_db_schema;
		}

		public String src_host;

		public String getSrc_host() {
			return this.src_host;
		}

		public String src_port;

		public String getSrc_port() {
			return this.src_port;
		}

		public String src_db_user;

		public String getSrc_db_user() {
			return this.src_db_user;
		}

		public String src_db_pass;

		public String getSrc_db_pass() {
			return this.src_db_pass;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.src_db_type = readString(dis);

					this.src_db_nme = readString(dis);

					this.src_db_schema = readString(dis);

					this.src_host = readString(dis);

					this.src_port = readString(dis);

					this.src_db_user = readString(dis);

					this.src_db_pass = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.src_db_type, dos);

				// String

				writeString(this.src_db_nme, dos);

				// String

				writeString(this.src_db_schema, dos);

				// String

				writeString(this.src_host, dos);

				// String

				writeString(this.src_port, dos);

				// String

				writeString(this.src_db_user, dos);

				// String

				writeString(this.src_db_pass, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("src_db_type=" + src_db_type);
			sb.append(",src_db_nme=" + src_db_nme);
			sb.append(",src_db_schema=" + src_db_schema);
			sb.append(",src_host=" + src_host);
			sb.append(",src_port=" + src_port);
			sb.append(",src_db_user=" + src_db_user);
			sb.append(",src_db_pass=" + src_db_pass);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (src_db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_type);
			}

			sb.append("|");

			if (src_db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_nme);
			}

			sb.append("|");

			if (src_db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_schema);
			}

			sb.append("|");

			if (src_host == null) {
				sb.append("<null>");
			} else {
				sb.append(src_host);
			}

			sb.append("|");

			if (src_port == null) {
				sb.append("<null>");
			} else {
				sb.append(src_port);
			}

			sb.append("|");

			if (src_db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_user);
			}

			sb.append("|");

			if (src_db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(src_db_pass);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12Struct implements
			routines.system.IPersistableRow<row12Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String db_type;

		public String getDb_type() {
			return this.db_type;
		}

		public String db_nme;

		public String getDb_nme() {
			return this.db_nme;
		}

		public String db_schema;

		public String getDb_schema() {
			return this.db_schema;
		}

		public String host;

		public String getHost() {
			return this.host;
		}

		public String port;

		public String getPort() {
			return this.port;
		}

		public String db_user;

		public String getDb_user() {
			return this.db_user;
		}

		public String db_pass;

		public String getDb_pass() {
			return this.db_pass;
		}

		public Integer active;

		public Integer getActive() {
			return this.active;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.db_type = readString(dis);

					this.db_nme = readString(dis);

					this.db_schema = readString(dis);

					this.host = readString(dis);

					this.port = readString(dis);

					this.db_user = readString(dis);

					this.db_pass = readString(dis);

					this.active = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.db_type, dos);

				// String

				writeString(this.db_nme, dos);

				// String

				writeString(this.db_schema, dos);

				// String

				writeString(this.host, dos);

				// String

				writeString(this.port, dos);

				// String

				writeString(this.db_user, dos);

				// String

				writeString(this.db_pass, dos);

				// Integer

				writeInteger(this.active, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("db_type=" + db_type);
			sb.append(",db_nme=" + db_nme);
			sb.append(",db_schema=" + db_schema);
			sb.append(",host=" + host);
			sb.append(",port=" + port);
			sb.append(",db_user=" + db_user);
			sb.append(",db_pass=" + db_pass);
			sb.append(",active=" + String.valueOf(active));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (db_type == null) {
				sb.append("<null>");
			} else {
				sb.append(db_type);
			}

			sb.append("|");

			if (db_nme == null) {
				sb.append("<null>");
			} else {
				sb.append(db_nme);
			}

			sb.append("|");

			if (db_schema == null) {
				sb.append("<null>");
			} else {
				sb.append(db_schema);
			}

			sb.append("|");

			if (host == null) {
				sb.append("<null>");
			} else {
				sb.append(host);
			}

			sb.append("|");

			if (port == null) {
				sb.append("<null>");
			} else {
				sb.append(port);
			}

			sb.append("|");

			if (db_user == null) {
				sb.append("<null>");
			} else {
				sb.append(db_user);
			}

			sb.append("|");

			if (db_pass == null) {
				sb.append("<null>");
			} else {
				sb.append(db_pass);
			}

			sb.append("|");

			if (active == null) {
				sb.append("<null>");
			} else {
				sb.append(active);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tMSSqlInput_3Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row12Struct row12 = new row12Struct();
				out3Struct out3 = new out3Struct();

				/**
				 * [tJavaRow_5 begin ] start
				 */

				ok_Hash.put("tJavaRow_5", false);
				start_Hash.put("tJavaRow_5", System.currentTimeMillis());

				currentComponent = "tJavaRow_5";

				int tos_count_tJavaRow_5 = 0;

				int nb_line_tJavaRow_5 = 0;

				/**
				 * [tJavaRow_5 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_1 = new StringBuilder();
				log4jParamters_tMap_1.append("Parameters:");
				log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_1.append(" | ");
				log4jParamters_tMap_1
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + log4jParamters_tMap_1);

				// ###############################
				// # Lookup's keys initialization
				int count_row12_tMap_1 = 0;

				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_out3_tMap_1 = 0;

				out3Struct out3_tmp = new out3Struct();
				// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tMSSqlInput_3 begin ] start
				 */

				ok_Hash.put("tMSSqlInput_3", false);
				start_Hash.put("tMSSqlInput_3", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tMSSqlInput_3");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tMSSqlInput_3";

				int tos_count_tMSSqlInput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_3 - " + "Start to work.");
				StringBuilder log4jParamters_tMSSqlInput_3 = new StringBuilder();
				log4jParamters_tMSSqlInput_3.append("Parameters:");
				log4jParamters_tMSSqlInput_3.append("USE_EXISTING_CONNECTION"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("HOST" + " = "
						+ "context.metadata_host");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("PORT" + " = "
						+ "context.metadata_port");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("DB_SCHEMA" + " = "
						+ "context.metadata_db_schema");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("DBNAME" + " = "
						+ "context.metadata_db_name");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("USER" + " = "
						+ "context.metadata_db_user");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3
						.append("PASS"
								+ " = "
								+ String.valueOf(
										routines.system.PasswordEncryptUtil
												.encryptPassword(context.metadata_db_pass))
										.substring(0, 4) + "...");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("TABLE" + " = "
						+ "\"schema_connection_details\"");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("QUERYSTORE" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3
						.append("QUERY"
								+ " = "
								+ "\"SELECT db_type,  		db_nme,  		db_schema,  		host,  		port,  		db_user,  		db_pass,  		active  FROM	schema_connection_details  where active=1 and db_type=\"+\"\\'\"+context.src_db_type+\"\\'\"+\" and \"+\"db_nme=\"+\"\\'\"+context.src_db_nme+\"\\'\"+\" and \"+\"db_schema=\"+\"\\'\"+context.src_db_schema+\"\\'\"");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("SPECIFY_DATASOURCE_ALIAS"
						+ " = " + "false");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("PROPERTIES" + " = "
						+ "\"\"");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("TRIM_ALL_COLUMN" + " = "
						+ "false");
				log4jParamters_tMSSqlInput_3.append(" | ");
				log4jParamters_tMSSqlInput_3.append("TRIM_COLUMN" + " = "
						+ "[{TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_type") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("db_nme") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_schema")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("host") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("port") + "}, {TRIM="
						+ ("false") + ", SCHEMA_COLUMN=" + ("db_user")
						+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
						+ ("db_pass") + "}, {TRIM=" + ("false")
						+ ", SCHEMA_COLUMN=" + ("active") + "}]");
				log4jParamters_tMSSqlInput_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_3 - " + log4jParamters_tMSSqlInput_3);

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tMSSqlInput_3 = new java.util.ArrayList();
				String[] talendToDBArray_tMSSqlInput_3 = new String[] {
						"FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tMSSqlInput_3,
						talendToDBArray_tMSSqlInput_3);
				int nb_line_tMSSqlInput_3 = 0;
				java.sql.Connection conn_tMSSqlInput_3 = null;
				String driverClass_tMSSqlInput_3 = "net.sourceforge.jtds.jdbc.Driver";
				java.lang.Class.forName(driverClass_tMSSqlInput_3);
				String dbUser_tMSSqlInput_3 = context.metadata_db_user;

				final String decryptedPassword_tMSSqlInput_3 = context.metadata_db_pass;

				String dbPwd_tMSSqlInput_3 = decryptedPassword_tMSSqlInput_3;

				String port_tMSSqlInput_3 = context.metadata_port;
				String dbname_tMSSqlInput_3 = context.metadata_db_name;
				String url_tMSSqlInput_3 = "jdbc:jtds:sqlserver://"
						+ context.metadata_host;
				if (!"".equals(port_tMSSqlInput_3)) {
					url_tMSSqlInput_3 += ":" + context.metadata_port;
				}
				if (!"".equals(dbname_tMSSqlInput_3)) {
					url_tMSSqlInput_3 += "//" + context.metadata_db_name;
				}
				url_tMSSqlInput_3 += ";appName=" + projectName + ";" + "";
				String dbschema_tMSSqlInput_3 = context.metadata_db_schema;

				log.debug("tMSSqlInput_3 - Driver ClassName: "
						+ driverClass_tMSSqlInput_3 + ".");

				log.debug("tMSSqlInput_3 - Connection attempt to '"
						+ url_tMSSqlInput_3 + "' with the username '"
						+ dbUser_tMSSqlInput_3 + "'.");

				conn_tMSSqlInput_3 = java.sql.DriverManager.getConnection(
						url_tMSSqlInput_3, dbUser_tMSSqlInput_3,
						dbPwd_tMSSqlInput_3);
				log.debug("tMSSqlInput_3 - Connection to '" + url_tMSSqlInput_3
						+ "' has succeeded.");

				java.sql.Statement stmt_tMSSqlInput_3 = conn_tMSSqlInput_3
						.createStatement();

				String dbquery_tMSSqlInput_3 = "SELECT db_type,\n		db_nme,\n		db_schema,\n		host,\n		port,\n		db_user,\n		db_pass,\n		active\nFROM	schema_connection_details\nwhere active=1 and db_type="
						+ "\'"
						+ context.src_db_type
						+ "\'"
						+ " and "
						+ "db_nme="
						+ "\'"
						+ context.src_db_nme
						+ "\'"
						+ " and "
						+ "db_schema="
						+ "\'"
						+ context.src_db_schema
						+ "\'";

				log.debug("tMSSqlInput_3 - Executing the query: '"
						+ dbquery_tMSSqlInput_3 + "'.");

				globalMap.put("tMSSqlInput_3_QUERY", dbquery_tMSSqlInput_3);

				java.sql.ResultSet rs_tMSSqlInput_3 = null;
				try {
					rs_tMSSqlInput_3 = stmt_tMSSqlInput_3
							.executeQuery(dbquery_tMSSqlInput_3);
					java.sql.ResultSetMetaData rsmd_tMSSqlInput_3 = rs_tMSSqlInput_3
							.getMetaData();
					int colQtyInRs_tMSSqlInput_3 = rsmd_tMSSqlInput_3
							.getColumnCount();

					String tmpContent_tMSSqlInput_3 = null;

					log.debug("tMSSqlInput_3 - Retrieving records from the database.");

					while (rs_tMSSqlInput_3.next()) {
						nb_line_tMSSqlInput_3++;

						if (colQtyInRs_tMSSqlInput_3 < 1) {
							row12.db_type = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(1);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(1)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.db_type = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.db_type = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.db_type = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 2) {
							row12.db_nme = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(2);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(2)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.db_nme = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.db_nme = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.db_nme = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 3) {
							row12.db_schema = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(3);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(3)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.db_schema = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.db_schema = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.db_schema = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 4) {
							row12.host = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(4);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(4)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.host = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.host = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.host = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 5) {
							row12.port = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(5);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(5)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.port = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.port = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.port = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 6) {
							row12.db_user = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(6);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(6)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.db_user = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.db_user = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.db_user = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 7) {
							row12.db_pass = null;
						} else {

							tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3
									.getString(7);
							if (tmpContent_tMSSqlInput_3 != null) {
								if (talendToDBList_tMSSqlInput_3
										.contains(rsmd_tMSSqlInput_3
												.getColumnTypeName(7)
												.toUpperCase(
														java.util.Locale.ENGLISH))) {
									row12.db_pass = FormatterUtils
											.formatUnwithE(tmpContent_tMSSqlInput_3);
								} else {
									row12.db_pass = tmpContent_tMSSqlInput_3;
								}
							} else {
								row12.db_pass = null;
							}
						}
						if (colQtyInRs_tMSSqlInput_3 < 8) {
							row12.active = null;
						} else {

							if (rs_tMSSqlInput_3.getObject(8) != null) {
								row12.active = rs_tMSSqlInput_3.getInt(8);
							} else {
								row12.active = null;
							}
						}

						log.debug("tMSSqlInput_3 - Retrieving the record "
								+ nb_line_tMSSqlInput_3 + ".");

						/**
						 * [tMSSqlInput_3 begin ] stop
						 */

						/**
						 * [tMSSqlInput_3 main ] start
						 */

						currentComponent = "tMSSqlInput_3";

						tos_count_tMSSqlInput_3++;

						/**
						 * [tMSSqlInput_3 main ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (log.isTraceEnabled()) {
							log.trace("row12 - "
									+ (row12 == null ? "" : row12.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							out3 = null;

							// # Output table : 'out3'
							count_out3_tMap_1++;

							out3_tmp.src_db_type = row12.db_type;
							out3_tmp.src_db_nme = row12.db_nme;
							out3_tmp.src_db_schema = row12.db_schema;
							out3_tmp.src_host = row12.host;
							out3_tmp.src_port = row12.port;
							out3_tmp.src_db_user = row12.db_user;
							out3_tmp.src_db_pass = row12.db_pass;
							out3 = out3_tmp;
							log.debug("tMap_1 - Outputting the record "
									+ count_out3_tMap_1
									+ " of the output table 'out3'.");

							// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */
						// Start of branch "out3"
						if (out3 != null) {

							/**
							 * [tJavaRow_5 main ] start
							 */

							currentComponent = "tJavaRow_5";

							if (log.isTraceEnabled()) {
								log.trace("out3 - "
										+ (out3 == null ? "" : out3
												.toLogString()));
							}

							// Code generated according to input schema and
							// output schema
							/*
							 * output_row.src_db_type = out3.src_db_type;
							 * output_row.src_db_nme = out3.src_db_nme;
							 * output_row.src_db_schema = out3.src_db_schema;
							 * output_row.src_host = out3.src_host;
							 * output_row.src_port = out3.src_port;
							 * output_row.src_db_user = out3.src_db_user;
							 * output_row.src_db_pass = out3.src_db_pass;
							 * output_row.table_nme = out3.table_nme;
							 * output_row.seq = out3.seq;
							 */

							context.src_db_type = out3.src_db_type;
							context.src_db_nme = out3.src_db_nme;
							context.src_db_schema = out3.src_db_schema;
							context.src_host = out3.src_host;
							context.src_port = out3.src_port;
							context.src_db_user = out3.src_db_user;
							context.src_db_pass = out3.src_db_pass;
							// context.table_nme = out3.table_nme;
							nb_line_tJavaRow_5++;

							tos_count_tJavaRow_5++;

							/**
							 * [tJavaRow_5 main ] stop
							 */

						} // End of branch "out3"

						/**
						 * [tMSSqlInput_3 end ] start
						 */

						currentComponent = "tMSSqlInput_3";

					}
				} finally {
					stmt_tMSSqlInput_3.close();

					if (conn_tMSSqlInput_3 != null
							&& !conn_tMSSqlInput_3.isClosed()) {

						log.debug("tMSSqlInput_3 - Closing the connection to the database.");

						conn_tMSSqlInput_3.close();

						log.debug("tMSSqlInput_3 - Connection to the database closed.");

					}
				}
				globalMap.put("tMSSqlInput_3_NB_LINE", nb_line_tMSSqlInput_3);
				log.debug("tMSSqlInput_3 - Retrieved records count: "
						+ nb_line_tMSSqlInput_3 + " .");

				if (log.isDebugEnabled())
					log.debug("tMSSqlInput_3 - " + "Done.");

				ok_Hash.put("tMSSqlInput_3", true);
				end_Hash.put("tMSSqlInput_3", System.currentTimeMillis());

				talendStats_STATS.addMessage(
						"end",
						"tMSSqlInput_3",
						end_Hash.get("tMSSqlInput_3")
								- start_Hash.get("tMSSqlInput_3"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tMSSqlInput_3 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

				// ###############################
				// # Lookup hashes releasing
				// ###############################
				log.debug("tMap_1 - Written records count in the table 'out3': "
						+ count_out3_tMap_1 + ".");

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + "Done.");

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tJavaRow_5 end ] start
				 */

				currentComponent = "tJavaRow_5";

				globalMap.put("tJavaRow_5_NB_LINE", nb_line_tJavaRow_5);

				ok_Hash.put("tJavaRow_5", true);
				end_Hash.put("tJavaRow_5", System.currentTimeMillis());

				/**
				 * [tJavaRow_5 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tMSSqlInput_3 finally ] start
				 */

				currentComponent = "tMSSqlInput_3";

				/**
				 * [tMSSqlInput_3 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tJavaRow_5 finally ] start
				 */

				currentComponent = "tJavaRow_5";

				/**
				 * [tJavaRow_5 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 1);
	}

	public void tPrejob_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tPrejob_1 begin ] start
				 */

				ok_Hash.put("tPrejob_1", false);
				start_Hash.put("tPrejob_1", System.currentTimeMillis());

				currentComponent = "tPrejob_1";

				int tos_count_tPrejob_1 = 0;

				/**
				 * [tPrejob_1 begin ] stop
				 */

				/**
				 * [tPrejob_1 main ] start
				 */

				currentComponent = "tPrejob_1";

				tos_count_tPrejob_1++;

				/**
				 * [tPrejob_1 main ] stop
				 */

				/**
				 * [tPrejob_1 end ] start
				 */

				currentComponent = "tPrejob_1";

				ok_Hash.put("tPrejob_1", true);
				end_Hash.put("tPrejob_1", System.currentTimeMillis());

				tJava_3Process(globalMap);

				/**
				 * [tPrejob_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tPrejob_1 finally ] start
				 */

				currentComponent = "tPrejob_1";

				/**
				 * [tPrejob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_3Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_3 begin ] start
				 */

				ok_Hash.put("tJava_3", false);
				start_Hash.put("tJava_3", System.currentTimeMillis());

				currentComponent = "tJava_3";

				int tos_count_tJava_3 = 0;

				context.logfile = (String) "AST_DATA_MASKING_JOB "
						+ TalendDate.getDate("yyyy-MM-dd-HH-mm-ss") + ".log";
				// System.out.println(context.LogFileDir+context.logfile);
				java.io.File file = new java.io.File(context.LogFileDir
						+ context.logfile);
				java.io.PrintStream ps = new java.io.PrintStream(
						new java.io.FileOutputStream(file));
				System.setOut(ps);

				// System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")+"|********** Log File Created at Location: "+context.LogFileDir+context.logfile
				// +" **********");

				/**
				 * [tJava_3 begin ] stop
				 */

				/**
				 * [tJava_3 main ] start
				 */

				currentComponent = "tJava_3";

				tos_count_tJava_3++;

				/**
				 * [tJava_3 main ] stop
				 */

				/**
				 * [tJava_3 end ] start
				 */

				currentComponent = "tJava_3";

				ok_Hash.put("tJava_3", true);
				end_Hash.put("tJava_3", System.currentTimeMillis());

				/**
				 * [tJava_3 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT",
						"CONNECTION:SUBJOB_OK:tJava_3:OnSubjobOk", "", Thread
								.currentThread().getId() + "", "", "", "", "",
						"");
			}

			tFileTouch_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_3 finally ] start
				 */

				currentComponent = "tJava_3";

				/**
				 * [tJava_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}

	public void tFileTouch_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileTouch_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tFileTouch_1 begin ] start
				 */

				ok_Hash.put("tFileTouch_1", false);
				start_Hash.put("tFileTouch_1", System.currentTimeMillis());

				currentComponent = "tFileTouch_1";

				int tos_count_tFileTouch_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileTouch_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileTouch_1 = new StringBuilder();
				log4jParamters_tFileTouch_1.append("Parameters:");
				log4jParamters_tFileTouch_1.append("FILENAME" + " = "
						+ "context.LogFileDir+context.logfile");
				log4jParamters_tFileTouch_1.append(" | ");
				log4jParamters_tFileTouch_1
						.append("CREATEDIR" + " = " + "true");
				log4jParamters_tFileTouch_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileTouch_1 - " + log4jParamters_tFileTouch_1);

				/**
				 * [tFileTouch_1 begin ] stop
				 */

				/**
				 * [tFileTouch_1 main ] start
				 */

				currentComponent = "tFileTouch_1";

				final StringBuffer log4jSb_tFileTouch_1 = new StringBuffer();

				java.io.File file_tFileTouch_1 = new java.io.File(
						(context.LogFileDir + context.logfile));
				java.io.File dir_tFileTouch_1 = file_tFileTouch_1
						.getParentFile();
				if (dir_tFileTouch_1 != null) {
					dir_tFileTouch_1.mkdirs();
				}

				// create new file
				boolean resulttFileTouch_1 = file_tFileTouch_1.createNewFile();
				// if file already exists, modify the last-modified-time of the
				// file
				if (!resulttFileTouch_1) {
					log.info("tFileTouch_1 - File : "
							+ file_tFileTouch_1.getAbsolutePath()
							+ " already exist, only modify the last-modified-time of the file.");

					file_tFileTouch_1.setLastModified((new Date()).getTime());
				} else {
					log.info("tFileTouch_1 - File : "
							+ file_tFileTouch_1.getAbsolutePath()
							+ " is created successfully");
				}

				tos_count_tFileTouch_1++;

				/**
				 * [tFileTouch_1 main ] stop
				 */

				/**
				 * [tFileTouch_1 end ] start
				 */

				currentComponent = "tFileTouch_1";

				if (log.isDebugEnabled())
					log.debug("tFileTouch_1 - " + "Done.");

				ok_Hash.put("tFileTouch_1", true);
				end_Hash.put("tFileTouch_1", System.currentTimeMillis());

				/**
				 * [tFileTouch_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog("CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tFileTouch_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "", "");
			}

			tParallelize_1Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tFileTouch_1 finally ] start
				 */

				currentComponent = "tFileTouch_1";

				/**
				 * [tFileTouch_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileTouch_1_SUBPROCESS_STATE", 1);
	}

	public void tParallelize_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tParallelize_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tParallelize_1 begin ] start
				 */

				ok_Hash.put("tParallelize_1", false);
				start_Hash.put("tParallelize_1", System.currentTimeMillis());

				currentComponent = "tParallelize_1";

				int tos_count_tParallelize_1 = 0;

				// call parallelized subjobs
				java.util.Map<String, Thread> mt_tParallelize_1 = new java.util.HashMap<String, Thread>();

				// clear the temporary values in the globalMap
				globalMap.remove("tRunJob_1_SUBPROCESS_STATE");
				globalMap.remove("tRunJob_2_SUBPROCESS_STATE");
				globalMap.remove("tRunJob_3_SUBPROCESS_STATE");
				globalMap.remove("tJava_2_SUBPROCESS_STATE");

				java.util.Map concurrentMap_temp_tParallelize_1;
				if (globalMap instanceof java.util.HashMap) {
					concurrentMap_temp_tParallelize_1 = java.util.Collections
							.synchronizedMap(globalMap);
				} else {
					concurrentMap_temp_tParallelize_1 = globalMap;
				}
				final java.util.Map concurrentMap_tParallelize_1 = concurrentMap_temp_tParallelize_1;

				runningThreadCount.add(1);
				String name_tRunJob_1 = "tParallelize_1_"
						+ java.util.UUID.randomUUID().toString();
				Thread thread_tRunJob_1 = new Thread(new ThreadGroup(
						name_tRunJob_1), name_tRunJob_1) {
					public void run() {
						java.util.Map threadRunResultMap = new java.util.HashMap();
						threadRunResultMap.put("errorCode", null);
						threadRunResultMap.put("status", "");
						threadLocal.set(threadRunResultMap);

						try {

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_1' starts.");

							tRunJob_1Process(concurrentMap_tParallelize_1);

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_1' is done.");

						} catch (TalendException e) {

							log.error("tParallelize_1 - " + e.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_1_SUBPROCESS_STATE", -1);
							e.printStackTrace();
						} catch (java.lang.Error error) {

							log.error("tParallelize_1 - " + error.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_1_SUBPROCESS_STATE", -1);
							error.printStackTrace();
						} finally {
							runningThreadCount.add(-1);
						}
					}
				};
				thread_tRunJob_1.start();
				mt_tParallelize_1.put("tRunJob_1", thread_tRunJob_1);
				runningThreadCount.add(1);
				String name_tRunJob_2 = "tParallelize_1_"
						+ java.util.UUID.randomUUID().toString();
				Thread thread_tRunJob_2 = new Thread(new ThreadGroup(
						name_tRunJob_2), name_tRunJob_2) {
					public void run() {
						java.util.Map threadRunResultMap = new java.util.HashMap();
						threadRunResultMap.put("errorCode", null);
						threadRunResultMap.put("status", "");
						threadLocal.set(threadRunResultMap);

						try {

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_2' starts.");

							tRunJob_2Process(concurrentMap_tParallelize_1);

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_2' is done.");

						} catch (TalendException e) {

							log.error("tParallelize_1 - " + e.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_2_SUBPROCESS_STATE", -1);
							e.printStackTrace();
						} catch (java.lang.Error error) {

							log.error("tParallelize_1 - " + error.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_2_SUBPROCESS_STATE", -1);
							error.printStackTrace();
						} finally {
							runningThreadCount.add(-1);
						}
					}
				};
				thread_tRunJob_2.start();
				mt_tParallelize_1.put("tRunJob_2", thread_tRunJob_2);
				runningThreadCount.add(1);
				String name_tRunJob_3 = "tParallelize_1_"
						+ java.util.UUID.randomUUID().toString();
				Thread thread_tRunJob_3 = new Thread(new ThreadGroup(
						name_tRunJob_3), name_tRunJob_3) {
					public void run() {
						java.util.Map threadRunResultMap = new java.util.HashMap();
						threadRunResultMap.put("errorCode", null);
						threadRunResultMap.put("status", "");
						threadLocal.set(threadRunResultMap);

						try {

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_3' starts.");

							tRunJob_3Process(concurrentMap_tParallelize_1);

							log.debug("tParallelize_1 - The subjob starting with the component 'tRunJob_3' is done.");

						} catch (TalendException e) {

							log.error("tParallelize_1 - " + e.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_3_SUBPROCESS_STATE", -1);
							e.printStackTrace();
						} catch (java.lang.Error error) {

							log.error("tParallelize_1 - " + error.getMessage());

							concurrentMap_tParallelize_1.put(
									"tRunJob_3_SUBPROCESS_STATE", -1);
							error.printStackTrace();
						} finally {
							runningThreadCount.add(-1);
						}
					}
				};
				thread_tRunJob_3.start();
				mt_tParallelize_1.put("tRunJob_3", thread_tRunJob_3);
				runningThreadCount.add(1);
				String name_tJava_2 = "tParallelize_1_"
						+ java.util.UUID.randomUUID().toString();
				Thread thread_tJava_2 = new Thread(
						new ThreadGroup(name_tJava_2), name_tJava_2) {
					public void run() {
						java.util.Map threadRunResultMap = new java.util.HashMap();
						threadRunResultMap.put("errorCode", null);
						threadRunResultMap.put("status", "");
						threadLocal.set(threadRunResultMap);

						try {

							log.debug("tParallelize_1 - The subjob starting with the component 'tJava_2' starts.");

							tJava_2Process(concurrentMap_tParallelize_1);

							log.debug("tParallelize_1 - The subjob starting with the component 'tJava_2' is done.");

						} catch (TalendException e) {

							log.error("tParallelize_1 - " + e.getMessage());

							concurrentMap_tParallelize_1.put(
									"tJava_2_SUBPROCESS_STATE", -1);
							e.printStackTrace();
						} catch (java.lang.Error error) {

							log.error("tParallelize_1 - " + error.getMessage());

							concurrentMap_tParallelize_1.put(
									"tJava_2_SUBPROCESS_STATE", -1);
							error.printStackTrace();
						} finally {
							runningThreadCount.add(-1);
						}
					}
				};
				thread_tJava_2.start();
				mt_tParallelize_1.put("tJava_2", thread_tJava_2);
				while ((((globalMap.get("tRunJob_1_SUBPROCESS_STATE") == null) ? true
						: ((Integer) globalMap
								.get("tRunJob_1_SUBPROCESS_STATE") == 0))
						|| ((globalMap.get("tRunJob_2_SUBPROCESS_STATE") == null) ? true
								: ((Integer) globalMap
										.get("tRunJob_2_SUBPROCESS_STATE") == 0))
						|| ((globalMap.get("tRunJob_3_SUBPROCESS_STATE") == null) ? true
								: ((Integer) globalMap
										.get("tRunJob_3_SUBPROCESS_STATE") == 0))
						|| ((globalMap.get("tJava_2_SUBPROCESS_STATE") == null) ? true
								: ((Integer) globalMap
										.get("tJava_2_SUBPROCESS_STATE") == 0)) || false)) {
					Thread.sleep(100);
				}

				// call next subprocesses

				/**
				 * [tParallelize_1 begin ] stop
				 */

				/**
				 * [tParallelize_1 main ] start
				 */

				currentComponent = "tParallelize_1";

				tos_count_tParallelize_1++;

				/**
				 * [tParallelize_1 main ] stop
				 */

				/**
				 * [tParallelize_1 end ] start
				 */

				currentComponent = "tParallelize_1";

				ok_Hash.put("tParallelize_1", true);
				end_Hash.put("tParallelize_1", System.currentTimeMillis());

				/**
				 * [tParallelize_1 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tParallelize_1 finally ] start
				 */

				currentComponent = "tParallelize_1";

				/**
				 * [tParallelize_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tParallelize_1_SUBPROCESS_STATE", 1);
	}

	public void tRunJob_1Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tRunJob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tRunJob_1 begin ] start
				 */

				ok_Hash.put("tRunJob_1", false);
				start_Hash.put("tRunJob_1", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tRunJob_1");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tRunJob_1";

				int tos_count_tRunJob_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tRunJob_1 - " + "Start to work.");
				StringBuilder log4jParamters_tRunJob_1 = new StringBuilder();
				log4jParamters_tRunJob_1.append("Parameters:");
				log4jParamters_tRunJob_1.append("USE_DYNAMIC_JOB" + " = "
						+ "false");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("PROCESS" + " = "
						+ "Data_Masking_Rule_Details");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("USE_INDEPENDENT_PROCESS"
						+ " = " + "false");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("DIE_ON_CHILD_ERROR" + " = "
						+ "true");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("TRANSMIT_WHOLE_CONTEXT"
						+ " = " + "false");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("CONTEXTPARAMS" + " = "
						+ "[{PARAM_NAME_COLUMN=" + ("file_rule_details")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.file_rule_details")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_host")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_host")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_port")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_port")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_schema")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_schema")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_name")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_name")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_user")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_user")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_pass")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_pass") + "}]");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("PROPAGATE_CHILD_RESULT"
						+ " = " + "false");
				log4jParamters_tRunJob_1.append(" | ");
				log4jParamters_tRunJob_1.append("PRINT_PARAMETER" + " = "
						+ "false");
				log4jParamters_tRunJob_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tRunJob_1 - " + log4jParamters_tRunJob_1);

				/**
				 * [tRunJob_1 begin ] stop
				 */

				/**
				 * [tRunJob_1 main ] start
				 */

				currentComponent = "tRunJob_1";

				java.util.List<String> paraList_tRunJob_1 = new java.util.ArrayList<String>();

				paraList_tRunJob_1.add("--father_pid=" + pid);

				paraList_tRunJob_1.add("--root_pid=" + rootPid);

				paraList_tRunJob_1.add("--father_node=tRunJob_1");

				paraList_tRunJob_1.add("--context=Default");

				if (!"".equals(log4jLevel)) {
					paraList_tRunJob_1.add("--log4jLevel=" + log4jLevel);
				}

				// for feature:10589

				paraList_tRunJob_1.add("--stat_port=" + portStats);

				if (resuming_logs_dir_path != null) {
					paraList_tRunJob_1.add("--resuming_logs_dir_path="
							+ resuming_logs_dir_path);
				}
				String childResumePath_tRunJob_1 = ResumeUtil
						.getChildJobCheckPointPath(resuming_checkpoint_path);
				String tRunJobName_tRunJob_1 = ResumeUtil
						.getRighttRunJob(resuming_checkpoint_path);
				if ("tRunJob_1".equals(tRunJobName_tRunJob_1)
						&& childResumePath_tRunJob_1 != null) {
					paraList_tRunJob_1
							.add("--resuming_checkpoint_path="
									+ ResumeUtil
											.getChildJobCheckPointPath(resuming_checkpoint_path));
				}
				paraList_tRunJob_1.add("--parent_part_launcher=JOB:" + jobName
						+ "/NODE:tRunJob_1");

				java.util.Map<String, Object> parentContextMap_tRunJob_1 = new java.util.HashMap<String, Object>();

				Object obj_tRunJob_1 = null;

				obj_tRunJob_1 = context.file_rule_details;
				paraList_tRunJob_1.add("--context_param file_rule_details="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("file_rule_details",
						obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_host;
				paraList_tRunJob_1.add("--context_param metadata_host="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_host", obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_port;
				paraList_tRunJob_1.add("--context_param metadata_port="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_port", obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_db_schema;
				paraList_tRunJob_1.add("--context_param metadata_db_schema="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_db_schema",
						obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_db_name;
				paraList_tRunJob_1.add("--context_param metadata_db_name="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_db_name",
						obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_db_user;
				paraList_tRunJob_1.add("--context_param metadata_db_user="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_db_user",
						obj_tRunJob_1);

				obj_tRunJob_1 = context.metadata_db_pass;
				paraList_tRunJob_1.add("--context_param metadata_db_pass="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));

				parentContextMap_tRunJob_1.put("metadata_db_pass",
						obj_tRunJob_1);

				talend_3rdi_git.data_masking_rule_details_0_1.Data_Masking_Rule_Details childJob_tRunJob_1 = new talend_3rdi_git.data_masking_rule_details_0_1.Data_Masking_Rule_Details();
				// pass DataSources
				java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_1 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
						.get(KEY_DB_DATASOURCES);
				if (null != talendDataSources_tRunJob_1) {
					java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_1 = new java.util.HashMap<String, javax.sql.DataSource>();
					for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_1 : talendDataSources_tRunJob_1
							.entrySet()) {
						dataSources_tRunJob_1.put(
								talendDataSourceEntry_tRunJob_1.getKey(),
								talendDataSourceEntry_tRunJob_1.getValue()
										.getRawDataSource());
					}
					childJob_tRunJob_1.setDataSources(dataSources_tRunJob_1);
				}

				childJob_tRunJob_1.parentContextMap = parentContextMap_tRunJob_1;

				log.info("tRunJob_1 - The child job 'talend_3rdi_git.data_masking_rule_details_0_1.Data_Masking_Rule_Details' starts on the version '0.1' with the context 'Default'.");

				String[][] childReturn_tRunJob_1 = childJob_tRunJob_1
						.runJob((String[]) paraList_tRunJob_1
								.toArray(new String[paraList_tRunJob_1.size()]));

				log.info("tRunJob_1 - The child job 'talend_3rdi_git.data_masking_rule_details_0_1.Data_Masking_Rule_Details' is done.");

				((java.util.Map) threadLocal.get()).put("errorCode",
						childJob_tRunJob_1.getErrorCode());

				if (childJob_tRunJob_1.getErrorCode() == null) {
					globalMap.put(
							"tRunJob_1_CHILD_RETURN_CODE",
							childJob_tRunJob_1.getStatus() != null
									&& ("failure").equals(childJob_tRunJob_1
											.getStatus()) ? 1 : 0);
				} else {
					globalMap.put("tRunJob_1_CHILD_RETURN_CODE",
							childJob_tRunJob_1.getErrorCode());
				}
				if (childJob_tRunJob_1.getExceptionStackTrace() != null) {
					globalMap.put("tRunJob_1_CHILD_EXCEPTION_STACKTRACE",
							childJob_tRunJob_1.getExceptionStackTrace());
				}

				if (childJob_tRunJob_1.getErrorCode() != null
						|| ("failure").equals(childJob_tRunJob_1.getStatus())) {
					throw new RuntimeException("Child job running failed");
				}

				tos_count_tRunJob_1++;

				/**
				 * [tRunJob_1 main ] stop
				 */

				/**
				 * [tRunJob_1 end ] start
				 */

				currentComponent = "tRunJob_1";

				if (log.isDebugEnabled())
					log.debug("tRunJob_1 - " + "Done.");

				ok_Hash.put("tRunJob_1", true);
				end_Hash.put("tRunJob_1", System.currentTimeMillis());

				talendStats_STATS
						.addMessage(
								"end",
								"tRunJob_1",
								end_Hash.get("tRunJob_1")
										- start_Hash.get("tRunJob_1"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tRunJob_1 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT",
						"CONNECTION:SUBJOB_OK:tRunJob_1:OnSubjobOk", "", Thread
								.currentThread().getId() + "", "", "", "", "",
						"");
			}

			tJava_8Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tRunJob_1 finally ] start
				 */

				currentComponent = "tRunJob_1";

				/**
				 * [tRunJob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tRunJob_1_SUBPROCESS_STATE", 1);
	}

	public void tJava_8Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_8 begin ] start
				 */

				ok_Hash.put("tJava_8", false);
				start_Hash.put("tJava_8", System.currentTimeMillis());

				currentComponent = "tJava_8";

				int tos_count_tJava_8 = 0;

				System.out
						.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
								+ "|********** Data Masking Rule Maintenance Child Job Completed  **********");

				/**
				 * [tJava_8 begin ] stop
				 */

				/**
				 * [tJava_8 main ] start
				 */

				currentComponent = "tJava_8";

				tos_count_tJava_8++;

				/**
				 * [tJava_8 main ] stop
				 */

				/**
				 * [tJava_8 end ] start
				 */

				currentComponent = "tJava_8";

				ok_Hash.put("tJava_8", true);
				end_Hash.put("tJava_8", System.currentTimeMillis());

				/**
				 * [tJava_8 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_8 finally ] start
				 */

				currentComponent = "tJava_8";

				/**
				 * [tJava_8 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}

	public void tRunJob_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tRunJob_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tRunJob_2 begin ] start
				 */

				ok_Hash.put("tRunJob_2", false);
				start_Hash.put("tRunJob_2", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tRunJob_2");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tRunJob_2";

				int tos_count_tRunJob_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tRunJob_2 - " + "Start to work.");
				StringBuilder log4jParamters_tRunJob_2 = new StringBuilder();
				log4jParamters_tRunJob_2.append("Parameters:");
				log4jParamters_tRunJob_2.append("USE_DYNAMIC_JOB" + " = "
						+ "false");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("PROCESS" + " = "
						+ "Data_Masking_Connection_Details");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("USE_INDEPENDENT_PROCESS"
						+ " = " + "false");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("DIE_ON_CHILD_ERROR" + " = "
						+ "true");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("TRANSMIT_WHOLE_CONTEXT"
						+ " = " + "false");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("CONTEXTPARAMS" + " = "
						+ "[{PARAM_NAME_COLUMN="
						+ ("file_schema_connection_details")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.file_schema_connection_details")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_host")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_host")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_port")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_port")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_schema")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_schema")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_name")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_name")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_user")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_user")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_pass")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_pass") + "}]");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("PROPAGATE_CHILD_RESULT"
						+ " = " + "false");
				log4jParamters_tRunJob_2.append(" | ");
				log4jParamters_tRunJob_2.append("PRINT_PARAMETER" + " = "
						+ "false");
				log4jParamters_tRunJob_2.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tRunJob_2 - " + log4jParamters_tRunJob_2);

				/**
				 * [tRunJob_2 begin ] stop
				 */

				/**
				 * [tRunJob_2 main ] start
				 */

				currentComponent = "tRunJob_2";

				java.util.List<String> paraList_tRunJob_2 = new java.util.ArrayList<String>();

				paraList_tRunJob_2.add("--father_pid=" + pid);

				paraList_tRunJob_2.add("--root_pid=" + rootPid);

				paraList_tRunJob_2.add("--father_node=tRunJob_2");

				paraList_tRunJob_2.add("--context=Default");

				if (!"".equals(log4jLevel)) {
					paraList_tRunJob_2.add("--log4jLevel=" + log4jLevel);
				}

				// for feature:10589

				paraList_tRunJob_2.add("--stat_port=" + portStats);

				if (resuming_logs_dir_path != null) {
					paraList_tRunJob_2.add("--resuming_logs_dir_path="
							+ resuming_logs_dir_path);
				}
				String childResumePath_tRunJob_2 = ResumeUtil
						.getChildJobCheckPointPath(resuming_checkpoint_path);
				String tRunJobName_tRunJob_2 = ResumeUtil
						.getRighttRunJob(resuming_checkpoint_path);
				if ("tRunJob_2".equals(tRunJobName_tRunJob_2)
						&& childResumePath_tRunJob_2 != null) {
					paraList_tRunJob_2
							.add("--resuming_checkpoint_path="
									+ ResumeUtil
											.getChildJobCheckPointPath(resuming_checkpoint_path));
				}
				paraList_tRunJob_2.add("--parent_part_launcher=JOB:" + jobName
						+ "/NODE:tRunJob_2");

				java.util.Map<String, Object> parentContextMap_tRunJob_2 = new java.util.HashMap<String, Object>();

				Object obj_tRunJob_2 = null;

				obj_tRunJob_2 = context.file_schema_connection_details;
				paraList_tRunJob_2
						.add("--context_param file_schema_connection_details="
								+ RuntimeUtils
										.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put(
						"file_schema_connection_details", obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_host;
				paraList_tRunJob_2.add("--context_param metadata_host="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_host", obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_port;
				paraList_tRunJob_2.add("--context_param metadata_port="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_port", obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_db_schema;
				paraList_tRunJob_2.add("--context_param metadata_db_schema="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_db_schema",
						obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_db_name;
				paraList_tRunJob_2.add("--context_param metadata_db_name="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_db_name",
						obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_db_user;
				paraList_tRunJob_2.add("--context_param metadata_db_user="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_db_user",
						obj_tRunJob_2);

				obj_tRunJob_2 = context.metadata_db_pass;
				paraList_tRunJob_2.add("--context_param metadata_db_pass="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));

				parentContextMap_tRunJob_2.put("metadata_db_pass",
						obj_tRunJob_2);

				talend_3rdi_git.data_masking_connection_details_0_1.Data_Masking_Connection_Details childJob_tRunJob_2 = new talend_3rdi_git.data_masking_connection_details_0_1.Data_Masking_Connection_Details();
				// pass DataSources
				java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_2 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
						.get(KEY_DB_DATASOURCES);
				if (null != talendDataSources_tRunJob_2) {
					java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_2 = new java.util.HashMap<String, javax.sql.DataSource>();
					for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_2 : talendDataSources_tRunJob_2
							.entrySet()) {
						dataSources_tRunJob_2.put(
								talendDataSourceEntry_tRunJob_2.getKey(),
								talendDataSourceEntry_tRunJob_2.getValue()
										.getRawDataSource());
					}
					childJob_tRunJob_2.setDataSources(dataSources_tRunJob_2);
				}

				childJob_tRunJob_2.parentContextMap = parentContextMap_tRunJob_2;

				log.info("tRunJob_2 - The child job 'talend_3rdi_git.data_masking_connection_details_0_1.Data_Masking_Connection_Details' starts on the version '0.1' with the context 'Default'.");

				String[][] childReturn_tRunJob_2 = childJob_tRunJob_2
						.runJob((String[]) paraList_tRunJob_2
								.toArray(new String[paraList_tRunJob_2.size()]));

				log.info("tRunJob_2 - The child job 'talend_3rdi_git.data_masking_connection_details_0_1.Data_Masking_Connection_Details' is done.");

				((java.util.Map) threadLocal.get()).put("errorCode",
						childJob_tRunJob_2.getErrorCode());

				if (childJob_tRunJob_2.getErrorCode() == null) {
					globalMap.put(
							"tRunJob_2_CHILD_RETURN_CODE",
							childJob_tRunJob_2.getStatus() != null
									&& ("failure").equals(childJob_tRunJob_2
											.getStatus()) ? 1 : 0);
				} else {
					globalMap.put("tRunJob_2_CHILD_RETURN_CODE",
							childJob_tRunJob_2.getErrorCode());
				}
				if (childJob_tRunJob_2.getExceptionStackTrace() != null) {
					globalMap.put("tRunJob_2_CHILD_EXCEPTION_STACKTRACE",
							childJob_tRunJob_2.getExceptionStackTrace());
				}

				if (childJob_tRunJob_2.getErrorCode() != null
						|| ("failure").equals(childJob_tRunJob_2.getStatus())) {
					throw new RuntimeException("Child job running failed");
				}

				tos_count_tRunJob_2++;

				/**
				 * [tRunJob_2 main ] stop
				 */

				/**
				 * [tRunJob_2 end ] start
				 */

				currentComponent = "tRunJob_2";

				if (log.isDebugEnabled())
					log.debug("tRunJob_2 - " + "Done.");

				ok_Hash.put("tRunJob_2", true);
				end_Hash.put("tRunJob_2", System.currentTimeMillis());

				talendStats_STATS
						.addMessage(
								"end",
								"tRunJob_2",
								end_Hash.get("tRunJob_2")
										- start_Hash.get("tRunJob_2"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tRunJob_2 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT",
						"CONNECTION:SUBJOB_OK:tRunJob_2:OnSubjobOk", "", Thread
								.currentThread().getId() + "", "", "", "", "",
						"");
			}

			tJava_9Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tRunJob_2 finally ] start
				 */

				currentComponent = "tRunJob_2";

				/**
				 * [tRunJob_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tRunJob_2_SUBPROCESS_STATE", 1);
	}

	public void tJava_9Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_9 begin ] start
				 */

				ok_Hash.put("tJava_9", false);
				start_Hash.put("tJava_9", System.currentTimeMillis());

				currentComponent = "tJava_9";

				int tos_count_tJava_9 = 0;

				System.out
						.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
								+ "|********** Data Masking Schema Connection Maintenance Child Job Completed  **********");

				/**
				 * [tJava_9 begin ] stop
				 */

				/**
				 * [tJava_9 main ] start
				 */

				currentComponent = "tJava_9";

				tos_count_tJava_9++;

				/**
				 * [tJava_9 main ] stop
				 */

				/**
				 * [tJava_9 end ] start
				 */

				currentComponent = "tJava_9";

				ok_Hash.put("tJava_9", true);
				end_Hash.put("tJava_9", System.currentTimeMillis());

				/**
				 * [tJava_9 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_9 finally ] start
				 */

				currentComponent = "tJava_9";

				/**
				 * [tJava_9 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}

	public void tRunJob_3Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tRunJob_3 begin ] start
				 */

				ok_Hash.put("tRunJob_3", false);
				start_Hash.put("tRunJob_3", System.currentTimeMillis());

				talendStats_STATS.addMessage("begin", "tRunJob_3");
				talendStats_STATSProcess(globalMap);

				currentComponent = "tRunJob_3";

				int tos_count_tRunJob_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tRunJob_3 - " + "Start to work.");
				StringBuilder log4jParamters_tRunJob_3 = new StringBuilder();
				log4jParamters_tRunJob_3.append("Parameters:");
				log4jParamters_tRunJob_3.append("USE_DYNAMIC_JOB" + " = "
						+ "false");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("PROCESS" + " = "
						+ "Data_Masking_Custom_SQL_Details");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("USE_INDEPENDENT_PROCESS"
						+ " = " + "false");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("DIE_ON_CHILD_ERROR" + " = "
						+ "true");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("TRANSMIT_WHOLE_CONTEXT"
						+ " = " + "false");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("CONTEXTPARAMS" + " = "
						+ "[{PARAM_NAME_COLUMN=" + ("file_custom_sql_details")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.file_custom_sql_details")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_host")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_host")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_port")
						+ ", PARAM_VALUE_COLUMN=" + ("context.metadata_port")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_schema")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_schema")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_name")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_name")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_user")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_user")
						+ "}, {PARAM_NAME_COLUMN=" + ("metadata_db_pass")
						+ ", PARAM_VALUE_COLUMN="
						+ ("context.metadata_db_pass") + "}]");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("PROPAGATE_CHILD_RESULT"
						+ " = " + "false");
				log4jParamters_tRunJob_3.append(" | ");
				log4jParamters_tRunJob_3.append("PRINT_PARAMETER" + " = "
						+ "false");
				log4jParamters_tRunJob_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tRunJob_3 - " + log4jParamters_tRunJob_3);

				/**
				 * [tRunJob_3 begin ] stop
				 */

				/**
				 * [tRunJob_3 main ] start
				 */

				currentComponent = "tRunJob_3";

				java.util.List<String> paraList_tRunJob_3 = new java.util.ArrayList<String>();

				paraList_tRunJob_3.add("--father_pid=" + pid);

				paraList_tRunJob_3.add("--root_pid=" + rootPid);

				paraList_tRunJob_3.add("--father_node=tRunJob_3");

				paraList_tRunJob_3.add("--context=Default");

				if (!"".equals(log4jLevel)) {
					paraList_tRunJob_3.add("--log4jLevel=" + log4jLevel);
				}

				// for feature:10589

				paraList_tRunJob_3.add("--stat_port=" + portStats);

				if (resuming_logs_dir_path != null) {
					paraList_tRunJob_3.add("--resuming_logs_dir_path="
							+ resuming_logs_dir_path);
				}
				String childResumePath_tRunJob_3 = ResumeUtil
						.getChildJobCheckPointPath(resuming_checkpoint_path);
				String tRunJobName_tRunJob_3 = ResumeUtil
						.getRighttRunJob(resuming_checkpoint_path);
				if ("tRunJob_3".equals(tRunJobName_tRunJob_3)
						&& childResumePath_tRunJob_3 != null) {
					paraList_tRunJob_3
							.add("--resuming_checkpoint_path="
									+ ResumeUtil
											.getChildJobCheckPointPath(resuming_checkpoint_path));
				}
				paraList_tRunJob_3.add("--parent_part_launcher=JOB:" + jobName
						+ "/NODE:tRunJob_3");

				java.util.Map<String, Object> parentContextMap_tRunJob_3 = new java.util.HashMap<String, Object>();

				Object obj_tRunJob_3 = null;

				obj_tRunJob_3 = context.file_custom_sql_details;
				paraList_tRunJob_3
						.add("--context_param file_custom_sql_details="
								+ RuntimeUtils
										.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("file_custom_sql_details",
						obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_host;
				paraList_tRunJob_3.add("--context_param metadata_host="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_host", obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_port;
				paraList_tRunJob_3.add("--context_param metadata_port="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_port", obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_db_schema;
				paraList_tRunJob_3.add("--context_param metadata_db_schema="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_db_schema",
						obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_db_name;
				paraList_tRunJob_3.add("--context_param metadata_db_name="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_db_name",
						obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_db_user;
				paraList_tRunJob_3.add("--context_param metadata_db_user="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_db_user",
						obj_tRunJob_3);

				obj_tRunJob_3 = context.metadata_db_pass;
				paraList_tRunJob_3.add("--context_param metadata_db_pass="
						+ RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));

				parentContextMap_tRunJob_3.put("metadata_db_pass",
						obj_tRunJob_3);

				talend_3rdi_git.data_masking_custom_sql_details_0_1.Data_Masking_Custom_SQL_Details childJob_tRunJob_3 = new talend_3rdi_git.data_masking_custom_sql_details_0_1.Data_Masking_Custom_SQL_Details();
				// pass DataSources
				java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_3 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
						.get(KEY_DB_DATASOURCES);
				if (null != talendDataSources_tRunJob_3) {
					java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_3 = new java.util.HashMap<String, javax.sql.DataSource>();
					for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_3 : talendDataSources_tRunJob_3
							.entrySet()) {
						dataSources_tRunJob_3.put(
								talendDataSourceEntry_tRunJob_3.getKey(),
								talendDataSourceEntry_tRunJob_3.getValue()
										.getRawDataSource());
					}
					childJob_tRunJob_3.setDataSources(dataSources_tRunJob_3);
				}

				childJob_tRunJob_3.parentContextMap = parentContextMap_tRunJob_3;

				log.info("tRunJob_3 - The child job 'talend_3rdi_git.data_masking_custom_sql_details_0_1.Data_Masking_Custom_SQL_Details' starts on the version '0.1' with the context 'Default'.");

				String[][] childReturn_tRunJob_3 = childJob_tRunJob_3
						.runJob((String[]) paraList_tRunJob_3
								.toArray(new String[paraList_tRunJob_3.size()]));

				log.info("tRunJob_3 - The child job 'talend_3rdi_git.data_masking_custom_sql_details_0_1.Data_Masking_Custom_SQL_Details' is done.");

				((java.util.Map) threadLocal.get()).put("errorCode",
						childJob_tRunJob_3.getErrorCode());

				if (childJob_tRunJob_3.getErrorCode() == null) {
					globalMap.put(
							"tRunJob_3_CHILD_RETURN_CODE",
							childJob_tRunJob_3.getStatus() != null
									&& ("failure").equals(childJob_tRunJob_3
											.getStatus()) ? 1 : 0);
				} else {
					globalMap.put("tRunJob_3_CHILD_RETURN_CODE",
							childJob_tRunJob_3.getErrorCode());
				}
				if (childJob_tRunJob_3.getExceptionStackTrace() != null) {
					globalMap.put("tRunJob_3_CHILD_EXCEPTION_STACKTRACE",
							childJob_tRunJob_3.getExceptionStackTrace());
				}

				if (childJob_tRunJob_3.getErrorCode() != null
						|| ("failure").equals(childJob_tRunJob_3.getStatus())) {
					throw new RuntimeException("Child job running failed");
				}

				tos_count_tRunJob_3++;

				/**
				 * [tRunJob_3 main ] stop
				 */

				/**
				 * [tRunJob_3 end ] start
				 */

				currentComponent = "tRunJob_3";

				if (log.isDebugEnabled())
					log.debug("tRunJob_3 - " + "Done.");

				ok_Hash.put("tRunJob_3", true);
				end_Hash.put("tRunJob_3", System.currentTimeMillis());

				talendStats_STATS
						.addMessage(
								"end",
								"tRunJob_3",
								end_Hash.get("tRunJob_3")
										- start_Hash.get("tRunJob_3"));
				talendStats_STATSProcess(globalMap);

				/**
				 * [tRunJob_3 end ] stop
				 */
			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT",
						"CONNECTION:SUBJOB_OK:tRunJob_3:OnSubjobOk", "", Thread
								.currentThread().getId() + "", "", "", "", "",
						"");
			}

			tJava_10Process(globalMap);

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tRunJob_3 finally ] start
				 */

				currentComponent = "tRunJob_3";

				/**
				 * [tRunJob_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 1);
	}

	public void tJava_10Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_10_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_10 begin ] start
				 */

				ok_Hash.put("tJava_10", false);
				start_Hash.put("tJava_10", System.currentTimeMillis());

				currentComponent = "tJava_10";

				int tos_count_tJava_10 = 0;

				System.out
						.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss")
								+ "|********** Data Masking Custom SQL Maintenance Child Job Completed  **********");

				/**
				 * [tJava_10 begin ] stop
				 */

				/**
				 * [tJava_10 main ] start
				 */

				currentComponent = "tJava_10";

				tos_count_tJava_10++;

				/**
				 * [tJava_10 main ] stop
				 */

				/**
				 * [tJava_10 end ] start
				 */

				currentComponent = "tJava_10";

				ok_Hash.put("tJava_10", true);
				end_Hash.put("tJava_10", System.currentTimeMillis());

				/**
				 * [tJava_10 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_10 finally ] start
				 */

				currentComponent = "tJava_10";

				/**
				 * [tJava_10 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_10_SUBPROCESS_STATE", 1);
	}

	public void tJava_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tJava_2 begin ] start
				 */

				ok_Hash.put("tJava_2", false);
				start_Hash.put("tJava_2", System.currentTimeMillis());

				currentComponent = "tJava_2";

				int tos_count_tJava_2 = 0;

				SQLFilters.initialize(globalMap, context.properties_file_path);

				/**
				 * [tJava_2 begin ] stop
				 */

				/**
				 * [tJava_2 main ] start
				 */

				currentComponent = "tJava_2";

				tos_count_tJava_2++;

				/**
				 * [tJava_2 main ] stop
				 */

				/**
				 * [tJava_2 end ] start
				 */

				currentComponent = "tJava_2";

				ok_Hash.put("tJava_2", true);
				end_Hash.put("tJava_2", System.currentTimeMillis());

				/**
				 * [tJava_2 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tJava_2 finally ] start
				 */

				currentComponent = "tJava_2";

				/**
				 * [tJava_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}

	public void tPostjob_2Process(final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tPostjob_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				/**
				 * [tPostjob_2 begin ] start
				 */

				ok_Hash.put("tPostjob_2", false);
				start_Hash.put("tPostjob_2", System.currentTimeMillis());

				currentComponent = "tPostjob_2";

				int tos_count_tPostjob_2 = 0;

				/**
				 * [tPostjob_2 begin ] stop
				 */

				/**
				 * [tPostjob_2 main ] start
				 */

				currentComponent = "tPostjob_2";

				tos_count_tPostjob_2++;

				/**
				 * [tPostjob_2 main ] stop
				 */

				/**
				 * [tPostjob_2 end ] start
				 */

				currentComponent = "tPostjob_2";

				ok_Hash.put("tPostjob_2", true);
				end_Hash.put("tPostjob_2", System.currentTimeMillis());

				tFileInputRaw_1Process(globalMap);

				/**
				 * [tPostjob_2 end ] stop
				 */
			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tPostjob_2 finally ] start
				 */

				currentComponent = "tPostjob_2";

				/**
				 * [tPostjob_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPostjob_2_SUBPROCESS_STATE", 1);
	}

	public static class row18Struct implements
			routines.system.IPersistableRow<row18Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String content;

		public String getContent() {
			return this.content;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.content = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.content, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("content=" + content);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (content == null) {
				sb.append("<null>");
			} else {
				sb.append(content);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row18Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out4Struct implements
			routines.system.IPersistableRow<out4Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public String content;

		public String getContent() {
			return this.content;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.content = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.content, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("content=" + content);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (content == null) {
				sb.append("<null>");
			} else {
				sb.append(content);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row17Struct implements
			routines.system.IPersistableRow<row17Struct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public Object content;

		public Object getContent() {
			return this.content;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.content = (Object) dis.readObject();

				} catch (IOException e) {
					throw new RuntimeException(e);

				} catch (ClassNotFoundException eCNFE) {
					throw new RuntimeException(eCNFE);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Object

				dos.writeObject(this.content);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("content=" + String.valueOf(content));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (content == null) {
				sb.append("<null>");
			} else {
				sb.append(content);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row17Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputRaw_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row17Struct row17 = new row17Struct();
				out4Struct out4 = new out4Struct();
				row18Struct row18 = new row18Struct();

				/**
				 * [tFileOutputRaw_1 begin ] start
				 */

				ok_Hash.put("tFileOutputRaw_1", false);
				start_Hash.put("tFileOutputRaw_1", System.currentTimeMillis());

				currentComponent = "tFileOutputRaw_1";

				int tos_count_tFileOutputRaw_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputRaw_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileOutputRaw_1 = new StringBuilder();
				log4jParamters_tFileOutputRaw_1.append("Parameters:");
				log4jParamters_tFileOutputRaw_1.append("FILENAME" + " = "
						+ "context.LogFileDir+context.logfile");
				log4jParamters_tFileOutputRaw_1.append(" | ");
				log4jParamters_tFileOutputRaw_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileOutputRaw_1.append(" | ");
				log4jParamters_tFileOutputRaw_1.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tFileOutputRaw_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileOutputRaw_1 - "
							+ log4jParamters_tFileOutputRaw_1);

				final StringBuffer log4jSb_tFileOutputRaw_1 = new StringBuffer();

				String fileName_tFileOutputRaw_1 = context.LogFileDir
						+ context.logfile;

				/**
				 * [tFileOutputRaw_1 begin ] stop
				 */

				/**
				 * [tReplace_1 begin ] start
				 */

				ok_Hash.put("tReplace_1", false);
				start_Hash.put("tReplace_1", System.currentTimeMillis());

				currentComponent = "tReplace_1";

				int tos_count_tReplace_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tReplace_1 - " + "Start to work.");
				StringBuilder log4jParamters_tReplace_1 = new StringBuilder();
				log4jParamters_tReplace_1.append("Parameters:");
				log4jParamters_tReplace_1
						.append("SIMPLE_MODE" + " = " + "true");
				log4jParamters_tReplace_1.append(" | ");
				log4jParamters_tReplace_1.append("SUBSTITUTIONS" + " = "
						+ "[{REPLACE_STRING=" + ("\"DB2_SRC_Input\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tDB2Input_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"DB2_TGT_Output\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tDB2Output_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tDenormalize_Rules_Denormalization\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tDenormalize_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tFileInputExcel_Param_Execute\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tFileInputExcel_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tFileOutputDelimited_Rows_Flow\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tFileOutputDelimited_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tFileTouch_Create_Log_File\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tFileTouch_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Building_SRC_Sql\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Initialize_SQLFilters_Routines\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Generating_Log_File_Name\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_3\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"tJava_Msg_Print_MSSQL\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_4\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_ORACLE\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_5\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"tJava_Msg_Print_DB2\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_6\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJavaRow_Loading_Tgt_Connection_Context\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJavaRow_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJavaRow_Loading_Context \"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJavaRow_3\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJavaRow_Loading_Rules_Context\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJavaRow_4\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJavaRow_Loading_Src_Connection_Context\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJavaRow_5\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJavaRow_Loading_Src_Custom_Sql_Context\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJavaRow_6\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"t_Map_SRC_Connection\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tMap_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"tMap_Rule_Details\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tMap_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"MSSQL_SRC_Input\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tMSSqlInput_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tMSSqlInput_Rule_Details\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tMSSqlInput_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tMSSqlInput_Src_Schema_Connection_Details\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tMSSqlInput_3\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tMSSqlInput_Tgt_Schema_Connection_Details\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tMSSqlInput_4\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tMSSqlInput_Src_Custom_Sql_Details\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tMSSqlInput_5\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"MSSQL_TGT_Output\"") + ", USE_GLOB=" + ("false")
						+ ", CASE_SENSITIVE=" + ("false") + ", SEARCH_PATTERN="
						+ ("\"tMSSqlOutput_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tMSSqlOutput_Rows_Flow\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tMSSqlOutput_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"ORACLE_SRC_Input\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN="
						+ ("\"tOracleInput_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"ORACLE_TGT_Output\"") + ", USE_GLOB=" + ("false")
						+ ", CASE_SENSITIVE=" + ("false") + ", SEARCH_PATTERN="
						+ ("\"tOracleOutput_1\"") + ", INPUT_COLUMN="
						+ ("content") + ", WHOLE_WORD=" + ("false")
						+ ", COMMENT=" + ("") + "}, {REPLACE_STRING="
						+ ("\"tRunJob_Rules_Maitenance\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tRunJob_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tRunJob_Schema_Connection_Maintenance\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tRunJob_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tRunJob_Src_Custom_SQL_Maintenance\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tRunJob_3\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"tSendMail_On_Failure\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tSendMail_1\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING=" + ("\"tSendMail_On_Success\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tSendMail_2\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_Child_Rules\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_8\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_Child_Schema_Connection\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_9\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_Child_Custom_SQL\"")
						+ ", USE_GLOB=" + ("false") + ", CASE_SENSITIVE="
						+ ("false") + ", SEARCH_PATTERN=" + ("\"tJava_10\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_MSSQL_SRC\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_11\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_ORACLE_SRC\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_12\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("")
						+ "}, {REPLACE_STRING="
						+ ("\"tJava_Msg_Print_DB2_SRC\"") + ", USE_GLOB="
						+ ("false") + ", CASE_SENSITIVE=" + ("false")
						+ ", SEARCH_PATTERN=" + ("\"tJava_7\"")
						+ ", INPUT_COLUMN=" + ("content") + ", WHOLE_WORD="
						+ ("false") + ", COMMENT=" + ("") + "}]");
				log4jParamters_tReplace_1.append(" | ");
				log4jParamters_tReplace_1.append("ADVANCED_MODE" + " = "
						+ "false");
				log4jParamters_tReplace_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tReplace_1 - " + log4jParamters_tReplace_1);

				int nb_line_tReplace_1 = 0;

				/**
				 * [tReplace_1 begin ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				int tos_count_tMap_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + "Start to work.");
				StringBuilder log4jParamters_tMap_3 = new StringBuilder();
				log4jParamters_tMap_3.append("Parameters:");
				log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = "
						+ "");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = "
						+ "2000000");
				log4jParamters_tMap_3.append(" | ");
				log4jParamters_tMap_3
						.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = "
								+ "false");
				log4jParamters_tMap_3.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + log4jParamters_tMap_3);

				// ###############################
				// # Lookup's keys initialization
				int count_row17_tMap_3 = 0;

				// ###############################

				// ###############################
				// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
				// ###############################

				// ###############################
				// # Outputs initialization
				int count_out4_tMap_3 = 0;

				out4Struct out4_tmp = new out4Struct();
				// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tFileInputRaw_1 begin ] start
				 */

				ok_Hash.put("tFileInputRaw_1", false);
				start_Hash.put("tFileInputRaw_1", System.currentTimeMillis());

				currentComponent = "tFileInputRaw_1";

				int tos_count_tFileInputRaw_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputRaw_1 - " + "Start to work.");
				StringBuilder log4jParamters_tFileInputRaw_1 = new StringBuilder();
				log4jParamters_tFileInputRaw_1.append("Parameters:");
				log4jParamters_tFileInputRaw_1.append("FILENAME" + " = "
						+ "context.LogFileDir+context.logfile");
				log4jParamters_tFileInputRaw_1.append(" | ");
				log4jParamters_tFileInputRaw_1.append("AS_STRING" + " = "
						+ "true");
				log4jParamters_tFileInputRaw_1.append(" | ");
				log4jParamters_tFileInputRaw_1.append("AS_BYTEARRAY" + " = "
						+ "false");
				log4jParamters_tFileInputRaw_1.append(" | ");
				log4jParamters_tFileInputRaw_1.append("AS_INPUTSTREAM" + " = "
						+ "false");
				log4jParamters_tFileInputRaw_1.append(" | ");
				log4jParamters_tFileInputRaw_1.append("ENCODING" + " = "
						+ "\"ISO-8859-15\"");
				log4jParamters_tFileInputRaw_1.append(" | ");
				log4jParamters_tFileInputRaw_1.append("DIE_ON_ERROR" + " = "
						+ "false");
				log4jParamters_tFileInputRaw_1.append(" | ");
				if (log.isDebugEnabled())
					log.debug("tFileInputRaw_1 - "
							+ log4jParamters_tFileInputRaw_1);

				final StringBuffer log4jSb_tFileInputRaw_1 = new StringBuffer();

				try {
					String content_tFileInputRaw_1 = org.apache.commons.io.FileUtils
							.readFileToString(new java.io.File(
									context.LogFileDir + context.logfile),
									"ISO-8859-15");
					row17.content = content_tFileInputRaw_1;
					globalMap.put("tFileInputRaw_1_FILENAME_PATH",
							context.LogFileDir + context.logfile);
				} catch (java.io.IOException e_tFileInputRaw_1) {

					log.error("tFileInputRaw_1 - "
							+ e_tFileInputRaw_1.getMessage());

					System.err.println(e_tFileInputRaw_1);
				}

				/**
				 * [tFileInputRaw_1 begin ] stop
				 */

				/**
				 * [tFileInputRaw_1 main ] start
				 */

				currentComponent = "tFileInputRaw_1";

				tos_count_tFileInputRaw_1++;

				/**
				 * [tFileInputRaw_1 main ] stop
				 */

				/**
				 * [tMap_3 main ] start
				 */

				currentComponent = "tMap_3";

				if (log.isTraceEnabled()) {
					log.trace("row17 - "
							+ (row17 == null ? "" : row17.toLogString()));
				}

				boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

				// ###############################
				// # Input tables (lookups)
				boolean rejectedInnerJoin_tMap_3 = false;
				boolean mainRowRejected_tMap_3 = false;

				// ###############################
				{ // start of Var scope

					// ###############################
					// # Vars tables

					Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
					// ###############################
					// # Output tables

					out4 = null;

					// # Output table : 'out4'
					count_out4_tMap_3++;

					out4_tmp.content = row17.content.toString();
					out4 = out4_tmp;
					log.debug("tMap_3 - Outputting the record "
							+ count_out4_tMap_3
							+ " of the output table 'out4'.");

					// ###############################

				} // end of Var scope

				rejectedInnerJoin_tMap_3 = false;

				tos_count_tMap_3++;

				/**
				 * [tMap_3 main ] stop
				 */
				// Start of branch "out4"
				if (out4 != null) {

					/**
					 * [tReplace_1 main ] start
					 */

					currentComponent = "tReplace_1";

					if (log.isTraceEnabled()) {
						log.trace("out4 - "
								+ (out4 == null ? "" : out4.toLogString()));
					}

					String searchStr_tReplace_1_1 = "tDB2Input_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_1, "DB2_SRC_Input" + "",
							false, false);
					String searchStr_tReplace_1_2 = "tDB2Output_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_2, "DB2_TGT_Output" + "",
							false, false);
					String searchStr_tReplace_1_3 = "tDenormalize_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_3,
							"tDenormalize_Rules_Denormalization" + "", false,
							false);
					String searchStr_tReplace_1_4 = "tFileInputExcel_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_4,
							"tFileInputExcel_Param_Execute" + "", false, false);
					String searchStr_tReplace_1_5 = "tFileOutputDelimited_1"
							+ "";
					out4.content = StringUtils
							.replaceAllStrictly(out4.content,
									searchStr_tReplace_1_5,
									"tFileOutputDelimited_Rows_Flow" + "",
									false, false);
					String searchStr_tReplace_1_6 = "tFileTouch_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_6,
							"tFileTouch_Create_Log_File" + "", false, false);
					String searchStr_tReplace_1_7 = "tJava_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_7, "tJava_Building_SRC_Sql"
									+ "", false, false);
					String searchStr_tReplace_1_8 = "tJava_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_8,
							"tJava_Initialize_SQLFilters_Routines" + "", false,
							false);
					String searchStr_tReplace_1_9 = "tJava_3" + "";
					out4.content = StringUtils
							.replaceAllStrictly(out4.content,
									searchStr_tReplace_1_9,
									"tJava_Generating_Log_File_Name" + "",
									false, false);
					String searchStr_tReplace_1_10 = "tJava_4" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_10, "tJava_Msg_Print_MSSQL"
									+ "", false, false);
					String searchStr_tReplace_1_11 = "tJava_5" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_11, "tJava_Msg_Print_ORACLE"
									+ "", false, false);
					String searchStr_tReplace_1_12 = "tJava_6" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_12,
							"tJava_Msg_Print_DB2" + "", false, false);
					String searchStr_tReplace_1_13 = "tJavaRow_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_13,
							"tJavaRow_Loading_Tgt_Connection_Context" + "",
							false, false);
					String searchStr_tReplace_1_14 = "tJavaRow_3" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_14,
							"tJavaRow_Loading_Context " + "", false, false);
					String searchStr_tReplace_1_15 = "tJavaRow_4" + "";
					out4.content = StringUtils
							.replaceAllStrictly(out4.content,
									searchStr_tReplace_1_15,
									"tJavaRow_Loading_Rules_Context" + "",
									false, false);
					String searchStr_tReplace_1_16 = "tJavaRow_5" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_16,
							"tJavaRow_Loading_Src_Connection_Context" + "",
							false, false);
					String searchStr_tReplace_1_17 = "tJavaRow_6" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_17,
							"tJavaRow_Loading_Src_Custom_Sql_Context" + "",
							false, false);
					String searchStr_tReplace_1_18 = "tMap_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_18, "t_Map_SRC_Connection"
									+ "", false, false);
					String searchStr_tReplace_1_19 = "tMap_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_19, "tMap_Rule_Details" + "",
							false, false);
					String searchStr_tReplace_1_20 = "tMSSqlInput_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_20, "MSSQL_SRC_Input" + "",
							false, false);
					String searchStr_tReplace_1_21 = "tMSSqlInput_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_21, "tMSSqlInput_Rule_Details"
									+ "", false, false);
					String searchStr_tReplace_1_22 = "tMSSqlInput_3" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_22,
							"tMSSqlInput_Src_Schema_Connection_Details" + "",
							false, false);
					String searchStr_tReplace_1_23 = "tMSSqlInput_4" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_23,
							"tMSSqlInput_Tgt_Schema_Connection_Details" + "",
							false, false);
					String searchStr_tReplace_1_24 = "tMSSqlInput_5" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_24,
							"tMSSqlInput_Src_Custom_Sql_Details" + "", false,
							false);
					String searchStr_tReplace_1_25 = "tMSSqlOutput_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_25, "MSSQL_TGT_Output" + "",
							false, false);
					String searchStr_tReplace_1_26 = "tMSSqlOutput_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_26, "tMSSqlOutput_Rows_Flow"
									+ "", false, false);
					String searchStr_tReplace_1_27 = "tOracleInput_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_27, "ORACLE_SRC_Input" + "",
							false, false);
					String searchStr_tReplace_1_28 = "tOracleOutput_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_28, "ORACLE_TGT_Output" + "",
							false, false);
					String searchStr_tReplace_1_29 = "tRunJob_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_29, "tRunJob_Rules_Maitenance"
									+ "", false, false);
					String searchStr_tReplace_1_30 = "tRunJob_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_30,
							"tRunJob_Schema_Connection_Maintenance" + "",
							false, false);
					String searchStr_tReplace_1_31 = "tRunJob_3" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_31,
							"tRunJob_Src_Custom_SQL_Maintenance" + "", false,
							false);
					String searchStr_tReplace_1_32 = "tSendMail_1" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_32, "tSendMail_On_Failure"
									+ "", false, false);
					String searchStr_tReplace_1_33 = "tSendMail_2" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_33, "tSendMail_On_Success"
									+ "", false, false);
					String searchStr_tReplace_1_34 = "tJava_8" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_34,
							"tJava_Msg_Print_Child_Rules" + "", false, false);
					String searchStr_tReplace_1_35 = "tJava_9" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_35,
							"tJava_Msg_Print_Child_Schema_Connection" + "",
							false, false);
					String searchStr_tReplace_1_36 = "tJava_10" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_36,
							"tJava_Msg_Print_Child_Custom_SQL" + "", false,
							false);
					String searchStr_tReplace_1_37 = "tJava_11" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_37,
							"tJava_Msg_Print_MSSQL_SRC" + "", false, false);
					String searchStr_tReplace_1_38 = "tJava_12" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_38,
							"tJava_Msg_Print_ORACLE_SRC" + "", false, false);
					String searchStr_tReplace_1_39 = "tJava_7" + "";
					out4.content = StringUtils.replaceAllStrictly(out4.content,
							searchStr_tReplace_1_39, "tJava_Msg_Print_DB2_SRC"
									+ "", false, false);
					row18.content = out4.content;

					nb_line_tReplace_1++;

					tos_count_tReplace_1++;

					/**
					 * [tReplace_1 main ] stop
					 */

					/**
					 * [tFileOutputRaw_1 main ] start
					 */

					currentComponent = "tFileOutputRaw_1";

					if (log.isTraceEnabled()) {
						log.trace("row18 - "
								+ (row18 == null ? "" : row18.toLogString()));
					}

					try {
						Object content_tFileOutputRaw_1 = row18.content;

						if (content_tFileOutputRaw_1 != null) {
							java.io.File file_tFileOutputRaw_1 = new java.io.File(
									fileName_tFileOutputRaw_1);
							java.io.File parentFile_tFileOutputRaw_1 = file_tFileOutputRaw_1
									.getParentFile();
							if (parentFile_tFileOutputRaw_1 != null
									&& !parentFile_tFileOutputRaw_1.exists()) {
								parentFile_tFileOutputRaw_1.mkdirs();
							}
							if (content_tFileOutputRaw_1 instanceof String) {
								org.apache.commons.io.FileUtils
										.writeStringToFile(
												file_tFileOutputRaw_1,
												content_tFileOutputRaw_1
														.toString(),
												"ISO-8859-15");
							} else if (content_tFileOutputRaw_1 instanceof byte[]) {
								org.apache.commons.io.FileUtils
										.writeByteArrayToFile(
												file_tFileOutputRaw_1,
												(byte[]) content_tFileOutputRaw_1);
							} else if (content_tFileOutputRaw_1 instanceof java.io.InputStream) {
								java.io.InputStream fis_tFileOutputRaw_1 = (java.io.InputStream) content_tFileOutputRaw_1;
								java.io.FileOutputStream fos_tFileOutputRaw_1 = new java.io.FileOutputStream(
										file_tFileOutputRaw_1);
								byte[] buffer_tFileOutputRaw_1 = new byte[65536];
								int nb_tFileOutputRaw_1 = 0;
								while (true) {
									nb_tFileOutputRaw_1 = fis_tFileOutputRaw_1
											.read(buffer_tFileOutputRaw_1);
									if (nb_tFileOutputRaw_1 == -1) {
										break;
									}
									fos_tFileOutputRaw_1.write(
											buffer_tFileOutputRaw_1, 0,
											nb_tFileOutputRaw_1);
								}
								fis_tFileOutputRaw_1.close();
								fos_tFileOutputRaw_1.close();
							}
						}
					} catch (java.lang.Exception e_tFileOutputRaw_1) {
						System.err.println(e_tFileOutputRaw_1);
						log.error("tFileOutputRaw_1 - "
								+ e_tFileOutputRaw_1.getMessage());
					}

					tos_count_tFileOutputRaw_1++;

					/**
					 * [tFileOutputRaw_1 main ] stop
					 */

				} // End of branch "out4"

				/**
				 * [tFileInputRaw_1 end ] start
				 */

				currentComponent = "tFileInputRaw_1";

				if (log.isDebugEnabled())
					log.debug("tFileInputRaw_1 - " + "Done.");

				ok_Hash.put("tFileInputRaw_1", true);
				end_Hash.put("tFileInputRaw_1", System.currentTimeMillis());

				/**
				 * [tFileInputRaw_1 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

				// ###############################
				// # Lookup hashes releasing
				// ###############################
				log.debug("tMap_3 - Written records count in the table 'out4': "
						+ count_out4_tMap_3 + ".");

				if (log.isDebugEnabled())
					log.debug("tMap_3 - " + "Done.");

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tReplace_1 end ] start
				 */

				currentComponent = "tReplace_1";

				globalMap.put("tReplace_1_NB_LINE", nb_line_tReplace_1);

				if (log.isDebugEnabled())
					log.debug("tReplace_1 - " + "Done.");

				ok_Hash.put("tReplace_1", true);
				end_Hash.put("tReplace_1", System.currentTimeMillis());

				/**
				 * [tReplace_1 end ] stop
				 */

				/**
				 * [tFileOutputRaw_1 end ] start
				 */

				currentComponent = "tFileOutputRaw_1";

				globalMap.put("tFileOutputRaw_1_FILENAME_PATH",
						fileName_tFileOutputRaw_1);

				if (log.isDebugEnabled())
					log.debug("tFileOutputRaw_1 - " + "Done.");

				ok_Hash.put("tFileOutputRaw_1", true);
				end_Hash.put("tFileOutputRaw_1", System.currentTimeMillis());

				/**
				 * [tFileOutputRaw_1 end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputRaw_1 finally ] start
				 */

				currentComponent = "tFileInputRaw_1";

				/**
				 * [tFileInputRaw_1 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tReplace_1 finally ] start
				 */

				currentComponent = "tReplace_1";

				/**
				 * [tReplace_1 finally ] stop
				 */

				/**
				 * [tFileOutputRaw_1 finally ] start
				 */

				currentComponent = "tFileOutputRaw_1";

				/**
				 * [tFileOutputRaw_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputRaw_1_SUBPROCESS_STATE", 1);
	}

	public static class row_talendLogs_LOGSStruct implements
			routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos)
				throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.root_pid = readString(dis);

					this.father_pid = readString(dis);

					this.project = readString(dis);

					this.job = readString(dis);

					this.context = readString(dis);

					this.priority = readInteger(dis);

					this.type = readString(dis);

					this.origin = readString(dis);

					this.message = readString(dis);

					this.code = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.root_pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.context, dos);

				// Integer

				writeInteger(this.priority, dos);

				// String

				writeString(this.type, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message, dos);

				// Integer

				writeInteger(this.code, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",context=" + context);
			sb.append(",priority=" + String.valueOf(priority));
			sb.append(",type=" + type);
			sb.append(",origin=" + origin);
			sb.append(",message=" + message);
			sb.append(",code=" + String.valueOf(code));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (moment == null) {
				sb.append("<null>");
			} else {
				sb.append(moment);
			}

			sb.append("|");

			if (pid == null) {
				sb.append("<null>");
			} else {
				sb.append(pid);
			}

			sb.append("|");

			if (root_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(root_pid);
			}

			sb.append("|");

			if (father_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(father_pid);
			}

			sb.append("|");

			if (project == null) {
				sb.append("<null>");
			} else {
				sb.append(project);
			}

			sb.append("|");

			if (job == null) {
				sb.append("<null>");
			} else {
				sb.append(job);
			}

			sb.append("|");

			if (context == null) {
				sb.append("<null>");
			} else {
				sb.append(context);
			}

			sb.append("|");

			if (priority == null) {
				sb.append("<null>");
			} else {
				sb.append(priority);
			}

			sb.append("|");

			if (type == null) {
				sb.append("<null>");
			} else {
				sb.append(type);
			}

			sb.append("|");

			if (origin == null) {
				sb.append("<null>");
			} else {
				sb.append(origin);
			}

			sb.append("|");

			if (message == null) {
				sb.append("<null>");
			} else {
				sb.append(message);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendLogs_LOGSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendLogs_LOGSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();

				/**
				 * [talendLogs_CONSOLE begin ] start
				 */

				ok_Hash.put("talendLogs_CONSOLE", false);
				start_Hash
						.put("talendLogs_CONSOLE", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				int tos_count_talendLogs_CONSOLE = 0;

				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - " + "Start to work.");
				StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
				log4jParamters_talendLogs_CONSOLE.append("Parameters:");
				log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = "
						+ "true");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR"
						+ " = " + "\"|\"");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = "
						+ "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH"
						+ " = " + "false");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				log4jParamters_talendLogs_CONSOLE
						.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
				log4jParamters_talendLogs_CONSOLE.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - "
							+ log4jParamters_talendLogs_CONSOLE);

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;

				StringBuilder strBuffer_talendLogs_CONSOLE = null;
				int nb_line_talendLogs_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendLogs_CONSOLE begin ] stop
				 */

				/**
				 * [talendLogs_LOGS begin ] start
				 */

				ok_Hash.put("talendLogs_LOGS", false);
				start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				int tos_count_talendLogs_LOGS = 0;

				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - " + "Start to work.");
				StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
				log4jParamters_talendLogs_LOGS.append("Parameters:");
				log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION"
						+ " = " + "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = "
						+ "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = "
						+ "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE"
						+ " = " + "true");
				log4jParamters_talendLogs_LOGS.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - "
							+ log4jParamters_talendLogs_LOGS);

				for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS
						.getMessages()) {
					row_talendLogs_LOGS.type = lcm.getType();
					row_talendLogs_LOGS.origin = (lcm.getOrigin() == null
							|| lcm.getOrigin().length() < 1 ? null : lcm
							.getOrigin());
					row_talendLogs_LOGS.priority = lcm.getPriority();
					row_talendLogs_LOGS.message = lcm.getMessage();
					row_talendLogs_LOGS.code = lcm.getCode();

					row_talendLogs_LOGS.moment = java.util.Calendar
							.getInstance().getTime();

					row_talendLogs_LOGS.pid = pid;
					row_talendLogs_LOGS.root_pid = rootPid;
					row_talendLogs_LOGS.father_pid = fatherPid;

					row_talendLogs_LOGS.project = projectName;
					row_talendLogs_LOGS.job = jobName;
					row_talendLogs_LOGS.context = contextStr;

					/**
					 * [talendLogs_LOGS begin ] stop
					 */

					/**
					 * [talendLogs_LOGS main ] start
					 */

					currentVirtualComponent = "talendLogs_LOGS";

					currentComponent = "talendLogs_LOGS";

					tos_count_talendLogs_LOGS++;

					/**
					 * [talendLogs_LOGS main ] stop
					 */

					/**
					 * [talendLogs_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendLogs_CONSOLE";

					currentComponent = "talendLogs_CONSOLE";

					// /////////////////////

					strBuffer_talendLogs_CONSOLE = new StringBuilder();

					if (row_talendLogs_LOGS.moment != null) { //

						strBuffer_talendLogs_CONSOLE.append(FormatterUtils
								.format_Date(row_talendLogs_LOGS.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.root_pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.root_pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.father_pid != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.father_pid));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.project != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.project));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.job != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.job));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.context != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.context));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.priority != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.priority));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.type != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.type));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.origin != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.origin));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.message != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.message));

					} //

					strBuffer_talendLogs_CONSOLE.append("|");

					if (row_talendLogs_LOGS.code != null) { //

						strBuffer_talendLogs_CONSOLE.append(String
								.valueOf(row_talendLogs_LOGS.code));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendLogs_CONSOLE);
					}
					log.info("talendLogs_CONSOLE - Content of row "
							+ (nb_line_talendLogs_CONSOLE + 1) + ": "
							+ strBuffer_talendLogs_CONSOLE.toString());
					consoleOut_talendLogs_CONSOLE
							.println(strBuffer_talendLogs_CONSOLE.toString());
					consoleOut_talendLogs_CONSOLE.flush();
					nb_line_talendLogs_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendLogs_CONSOLE++;

					/**
					 * [talendLogs_CONSOLE main ] stop
					 */

					/**
					 * [talendLogs_LOGS end ] start
					 */

					currentVirtualComponent = "talendLogs_LOGS";

					currentComponent = "talendLogs_LOGS";

				}

				if (log.isDebugEnabled())
					log.debug("talendLogs_LOGS - " + "Done.");

				ok_Hash.put("talendLogs_LOGS", true);
				end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				/**
				 * [talendLogs_LOGS end ] stop
				 */

				/**
				 * [talendLogs_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				// ////
				// ////
				globalMap.put("talendLogs_CONSOLE_NB_LINE",
						nb_line_talendLogs_CONSOLE);
				if (log.isInfoEnabled())
					log.info("talendLogs_CONSOLE - " + "Printed row count: "
							+ nb_line_talendLogs_CONSOLE + ".");

				// /////////////////////

				if (log.isDebugEnabled())
					log.debug("talendLogs_CONSOLE - " + "Done.");

				ok_Hash.put("talendLogs_CONSOLE", true);
				end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendLogs_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [talendLogs_LOGS finally ] start
				 */

				currentVirtualComponent = "talendLogs_LOGS";

				currentComponent = "talendLogs_LOGS";

				/**
				 * [talendLogs_LOGS finally ] stop
				 */

				/**
				 * [talendLogs_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendLogs_CONSOLE";

				currentComponent = "talendLogs_CONSOLE";

				/**
				 * [talendLogs_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendStats_STATSStruct implements
			routines.system.IPersistableRow<row_talendStats_STATSStruct> {
		final static byte[] commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking = new byte[0];
		static byte[] commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		private java.util.Date readDate(ObjectInputStream dis)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos)
				throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_3RDI_GIT_Data_Masking.length) {
					if (length < 1024
							&& commonByteArray_TALEND_3RDI_GIT_Data_Masking.length == 0) {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[1024];
					} else {
						commonByteArray_TALEND_3RDI_GIT_Data_Masking = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length);
				strReturn = new String(
						commonByteArray_TALEND_3RDI_GIT_Data_Masking, 0,
						length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos)
				throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_3RDI_GIT_Data_Masking) {

				try {

					int length = 0;

					this.moment = readDate(dis);

					this.pid = readString(dis);

					this.father_pid = readString(dis);

					this.root_pid = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					this.project = readString(dis);

					this.job = readString(dis);

					this.job_repository_id = readString(dis);

					this.job_version = readString(dis);

					this.context = readString(dis);

					this.origin = readString(dis);

					this.message_type = readString(dis);

					this.message = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				writeDate(this.moment, dos);

				// String

				writeString(this.pid, dos);

				// String

				writeString(this.father_pid, dos);

				// String

				writeString(this.root_pid, dos);

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				writeString(this.project, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.job_repository_id, dos);

				// String

				writeString(this.job_version, dos);

				// String

				writeString(this.context, dos);

				// String

				writeString(this.origin, dos);

				// String

				writeString(this.message_type, dos);

				// String

				writeString(this.message, dos);

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("moment=" + String.valueOf(moment));
			sb.append(",pid=" + pid);
			sb.append(",father_pid=" + father_pid);
			sb.append(",root_pid=" + root_pid);
			sb.append(",system_pid=" + String.valueOf(system_pid));
			sb.append(",project=" + project);
			sb.append(",job=" + job);
			sb.append(",job_repository_id=" + job_repository_id);
			sb.append(",job_version=" + job_version);
			sb.append(",context=" + context);
			sb.append(",origin=" + origin);
			sb.append(",message_type=" + message_type);
			sb.append(",message=" + message);
			sb.append(",duration=" + String.valueOf(duration));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (moment == null) {
				sb.append("<null>");
			} else {
				sb.append(moment);
			}

			sb.append("|");

			if (pid == null) {
				sb.append("<null>");
			} else {
				sb.append(pid);
			}

			sb.append("|");

			if (father_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(father_pid);
			}

			sb.append("|");

			if (root_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(root_pid);
			}

			sb.append("|");

			if (system_pid == null) {
				sb.append("<null>");
			} else {
				sb.append(system_pid);
			}

			sb.append("|");

			if (project == null) {
				sb.append("<null>");
			} else {
				sb.append(project);
			}

			sb.append("|");

			if (job == null) {
				sb.append("<null>");
			} else {
				sb.append(job);
			}

			sb.append("|");

			if (job_repository_id == null) {
				sb.append("<null>");
			} else {
				sb.append(job_repository_id);
			}

			sb.append("|");

			if (job_version == null) {
				sb.append("<null>");
			} else {
				sb.append(job_version);
			}

			sb.append("|");

			if (context == null) {
				sb.append("<null>");
			} else {
				sb.append(context);
			}

			sb.append("|");

			if (origin == null) {
				sb.append("<null>");
			} else {
				sb.append(origin);
			}

			sb.append("|");

			if (message_type == null) {
				sb.append("<null>");
			} else {
				sb.append(message_type);
			}

			sb.append("|");

			if (message == null) {
				sb.append("<null>");
			} else {
				sb.append(message);
			}

			sb.append("|");

			if (duration == null) {
				sb.append("<null>");
			} else {
				sb.append(duration);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendStats_STATSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(),
						object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendStats_STATSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {

			String currentMethodName = new java.lang.Exception()
					.getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume
				globalResumeTicket = true;

				row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();

				/**
				 * [talendStats_CONSOLE begin ] start
				 */

				ok_Hash.put("talendStats_CONSOLE", false);
				start_Hash.put("talendStats_CONSOLE",
						System.currentTimeMillis());

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				int tos_count_talendStats_CONSOLE = 0;

				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - " + "Start to work.");
				StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
				log4jParamters_talendStats_CONSOLE.append("Parameters:");
				log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = "
						+ "true");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = "
						+ "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = "
						+ "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR"
						+ " = " + "\"|\"");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH"
						+ " = " + "false");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				log4jParamters_talendStats_CONSOLE
						.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
				log4jParamters_talendStats_CONSOLE.append(" | ");
				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - "
							+ log4jParamters_talendStats_CONSOLE);

				// /////////////////////

				final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
				java.io.PrintStream consoleOut_talendStats_CONSOLE = null;

				StringBuilder strBuffer_talendStats_CONSOLE = null;
				int nb_line_talendStats_CONSOLE = 0;
				// /////////////////////

				/**
				 * [talendStats_CONSOLE begin ] stop
				 */

				/**
				 * [talendStats_STATS begin ] start
				 */

				ok_Hash.put("talendStats_STATS", false);
				start_Hash.put("talendStats_STATS", System.currentTimeMillis());

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				int tos_count_talendStats_STATS = 0;

				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - " + "Start to work.");
				StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
				log4jParamters_talendStats_STATS.append("Parameters:");
				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - "
							+ log4jParamters_talendStats_STATS);

				for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS
						.getMessages()) {
					row_talendStats_STATS.pid = pid;
					row_talendStats_STATS.root_pid = rootPid;
					row_talendStats_STATS.father_pid = fatherPid;
					row_talendStats_STATS.project = projectName;
					row_talendStats_STATS.job = jobName;
					row_talendStats_STATS.context = contextStr;
					row_talendStats_STATS.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row_talendStats_STATS.message = scm.getMessage();
					row_talendStats_STATS.duration = scm.getDuration();
					row_talendStats_STATS.moment = scm.getMoment();
					row_talendStats_STATS.message_type = scm.getMessageType();
					row_talendStats_STATS.job_version = scm.getJobVersion();
					row_talendStats_STATS.job_repository_id = scm.getJobId();
					row_talendStats_STATS.system_pid = scm.getSystemPid();

					/**
					 * [talendStats_STATS begin ] stop
					 */

					/**
					 * [talendStats_STATS main ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

					tos_count_talendStats_STATS++;

					/**
					 * [talendStats_STATS main ] stop
					 */

					/**
					 * [talendStats_CONSOLE main ] start
					 */

					currentVirtualComponent = "talendStats_CONSOLE";

					currentComponent = "talendStats_CONSOLE";

					// /////////////////////

					strBuffer_talendStats_CONSOLE = new StringBuilder();

					if (row_talendStats_STATS.moment != null) { //

						strBuffer_talendStats_CONSOLE.append(FormatterUtils
								.format_Date(row_talendStats_STATS.moment,
										"yyyy-MM-dd HH:mm:ss"));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.father_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.father_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.root_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.root_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.system_pid != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.system_pid));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.project != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.project));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.job));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job_repository_id != null) { //

						strBuffer_talendStats_CONSOLE
								.append(String
										.valueOf(row_talendStats_STATS.job_repository_id));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.job_version != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.job_version));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.context != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.context));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.origin != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.origin));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.message_type != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.message_type));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.message != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.message));

					} //

					strBuffer_talendStats_CONSOLE.append("|");

					if (row_talendStats_STATS.duration != null) { //

						strBuffer_talendStats_CONSOLE.append(String
								.valueOf(row_talendStats_STATS.duration));

					} //

					if (globalMap.get("tLogRow_CONSOLE") != null) {
						consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap
								.get("tLogRow_CONSOLE");
					} else {
						consoleOut_talendStats_CONSOLE = new java.io.PrintStream(
								new java.io.BufferedOutputStream(System.out));
						globalMap.put("tLogRow_CONSOLE",
								consoleOut_talendStats_CONSOLE);
					}
					log.info("talendStats_CONSOLE - Content of row "
							+ (nb_line_talendStats_CONSOLE + 1) + ": "
							+ strBuffer_talendStats_CONSOLE.toString());
					consoleOut_talendStats_CONSOLE
							.println(strBuffer_talendStats_CONSOLE.toString());
					consoleOut_talendStats_CONSOLE.flush();
					nb_line_talendStats_CONSOLE++;
					// ////

					// ////

					// /////////////////////

					tos_count_talendStats_CONSOLE++;

					/**
					 * [talendStats_CONSOLE main ] stop
					 */

					/**
					 * [talendStats_STATS end ] start
					 */

					currentVirtualComponent = "talendStats_STATS";

					currentComponent = "talendStats_STATS";

				}

				if (log.isDebugEnabled())
					log.debug("talendStats_STATS - " + "Done.");

				ok_Hash.put("talendStats_STATS", true);
				end_Hash.put("talendStats_STATS", System.currentTimeMillis());

				/**
				 * [talendStats_STATS end ] stop
				 */

				/**
				 * [talendStats_CONSOLE end ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				// ////
				// ////
				globalMap.put("talendStats_CONSOLE_NB_LINE",
						nb_line_talendStats_CONSOLE);
				if (log.isInfoEnabled())
					log.info("talendStats_CONSOLE - " + "Printed row count: "
							+ nb_line_talendStats_CONSOLE + ".");

				// /////////////////////

				if (log.isDebugEnabled())
					log.debug("talendStats_CONSOLE - " + "Done.");

				ok_Hash.put("talendStats_CONSOLE", true);
				end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());

				/**
				 * [talendStats_CONSOLE end ] stop
				 */

			}// end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage());
			}

			TalendException te = new TalendException(e, currentComponent,
					globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [talendStats_STATS finally ] start
				 */

				currentVirtualComponent = "talendStats_STATS";

				currentComponent = "talendStats_STATS";

				/**
				 * [talendStats_STATS finally ] stop
				 */

				/**
				 * [talendStats_CONSOLE finally ] start
				 */

				currentVirtualComponent = "talendStats_CONSOLE";

				currentComponent = "talendStats_CONSOLE";

				/**
				 * [talendStats_CONSOLE finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private SyncInt runningThreadCount = new SyncInt();

	private class SyncInt {
		private int count = 0;

		public synchronized void add(int i) {
			count += i;
		}

		public synchronized int getCount() {
			return count;
		}
	}

	private java.util.Properties context_param = new java.util.Properties();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final Data_Masking Data_MaskingClass = new Data_Masking();

		int exitCode = Data_MaskingClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Data_Masking' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (!"".equals(log4jLevel)) {
			if ("trace".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				log.setLevel(org.apache.log4j.Level.OFF);
			}
			org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
		}
		log.info("TalendJob: 'Data_Masking' - Start.");

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like:
			// --context=production. if without this parameter, there will use
			// the default context instead.
			java.io.InputStream inContext = Data_Masking.class.getClassLoader()
					.getResourceAsStream(
							"talend_3rdi_git/data_masking_0_1/contexts/"
									+ contextStr + ".properties");
			if (isDefaultContext && inContext == null) {

			} else {
				if (inContext != null) {
					// defaultProps is in order to keep the original context
					// value
					defaultProps.load(inContext);
					inContext.close();
					context = new ContextProperties(defaultProps);
				} else {
					// print info and job continue to run, for case:
					// context_param is not empty.
					System.err.println("Could not find the context "
							+ contextStr);
				}
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
			}
			context.src_db_type = (String) context.getProperty("src_db_type");
			context.src_db_nme = (String) context.getProperty("src_db_nme");
			context.src_db_schema = (String) context
					.getProperty("src_db_schema");
			context.table_nme = (String) context.getProperty("table_nme");
			context.src_host = (String) context.getProperty("src_host");
			context.src_port = (String) context.getProperty("src_port");
			context.src_db_user = (String) context.getProperty("src_db_user");
			context.src_db_pass = (String) context.getProperty("src_db_pass");
			context.src_additional_param = (String) context
					.getProperty("src_additional_param");
			context.src_table_all_col = (String) context
					.getProperty("src_table_all_col");
			context.tgt_db_type = (String) context.getProperty("tgt_db_type");
			context.tgt_db_nme = (String) context.getProperty("tgt_db_nme");
			context.tgt_db_schema = (String) context
					.getProperty("tgt_db_schema");
			context.tgt_host = (String) context.getProperty("tgt_host");
			context.tgt_port = (String) context.getProperty("tgt_port");
			context.tgt_db_user = (String) context.getProperty("tgt_db_user");
			context.tgt_db_pass = (String) context.getProperty("tgt_db_pass");
			context.tgt_additional_param = (String) context
					.getProperty("tgt_additional_param");
			context.rules = (String) context.getProperty("rules");
			context.src_sql = (String) context.getProperty("src_sql");
			context.logfile = (String) context.getProperty("logfile");
			context.LogFileDir = (String) context.getProperty("LogFileDir");
			context.file_param_execute = (String) context
					.getProperty("file_param_execute");
			context.file_custom_sql_details = (String) context
					.getProperty("file_custom_sql_details");
			context.file_schema_connection_details = (String) context
					.getProperty("file_schema_connection_details");
			context.file_rule_details = (String) context
					.getProperty("file_rule_details");
			context.metadata_host = (String) context
					.getProperty("metadata_host");
			context.metadata_port = (String) context
					.getProperty("metadata_port");
			context.metadata_db_schema = (String) context
					.getProperty("metadata_db_schema");
			context.metadata_db_name = (String) context
					.getProperty("metadata_db_name");
			context.metadata_db_user = (String) context
					.getProperty("metadata_db_user");
			String pwd_metadata_db_pass_value = context
					.getProperty("metadata_db_pass");
			context.metadata_db_pass = null;
			if (pwd_metadata_db_pass_value != null) {
				if (context_param.containsKey("metadata_db_pass")) {// no need
																	// to
																	// decrypt
																	// if it
																	// come from
																	// program
																	// argument
																	// or parent
																	// job
																	// runtime
					context.metadata_db_pass = pwd_metadata_db_pass_value;
				} else if (!pwd_metadata_db_pass_value.isEmpty()) {
					try {
						context.metadata_db_pass = routines.system.PasswordEncryptUtil
								.decryptPassword(pwd_metadata_db_pass_value);
						context.put("metadata_db_pass",
								context.metadata_db_pass);
					} catch (java.lang.RuntimeException e) {
						// do nothing
					}
				}
			}
			context.file_ref_stat = (String) context
					.getProperty("file_ref_stat");
			context.properties_file_path = (String) context
					.getProperty("properties_file_path");
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("src_db_type")) {
				context.src_db_type = (String) parentContextMap
						.get("src_db_type");
			}
			if (parentContextMap.containsKey("src_db_nme")) {
				context.src_db_nme = (String) parentContextMap
						.get("src_db_nme");
			}
			if (parentContextMap.containsKey("src_db_schema")) {
				context.src_db_schema = (String) parentContextMap
						.get("src_db_schema");
			}
			if (parentContextMap.containsKey("table_nme")) {
				context.table_nme = (String) parentContextMap.get("table_nme");
			}
			if (parentContextMap.containsKey("src_host")) {
				context.src_host = (String) parentContextMap.get("src_host");
			}
			if (parentContextMap.containsKey("src_port")) {
				context.src_port = (String) parentContextMap.get("src_port");
			}
			if (parentContextMap.containsKey("src_db_user")) {
				context.src_db_user = (String) parentContextMap
						.get("src_db_user");
			}
			if (parentContextMap.containsKey("src_db_pass")) {
				context.src_db_pass = (String) parentContextMap
						.get("src_db_pass");
			}
			if (parentContextMap.containsKey("src_additional_param")) {
				context.src_additional_param = (String) parentContextMap
						.get("src_additional_param");
			}
			if (parentContextMap.containsKey("src_table_all_col")) {
				context.src_table_all_col = (String) parentContextMap
						.get("src_table_all_col");
			}
			if (parentContextMap.containsKey("tgt_db_type")) {
				context.tgt_db_type = (String) parentContextMap
						.get("tgt_db_type");
			}
			if (parentContextMap.containsKey("tgt_db_nme")) {
				context.tgt_db_nme = (String) parentContextMap
						.get("tgt_db_nme");
			}
			if (parentContextMap.containsKey("tgt_db_schema")) {
				context.tgt_db_schema = (String) parentContextMap
						.get("tgt_db_schema");
			}
			if (parentContextMap.containsKey("tgt_host")) {
				context.tgt_host = (String) parentContextMap.get("tgt_host");
			}
			if (parentContextMap.containsKey("tgt_port")) {
				context.tgt_port = (String) parentContextMap.get("tgt_port");
			}
			if (parentContextMap.containsKey("tgt_db_user")) {
				context.tgt_db_user = (String) parentContextMap
						.get("tgt_db_user");
			}
			if (parentContextMap.containsKey("tgt_db_pass")) {
				context.tgt_db_pass = (String) parentContextMap
						.get("tgt_db_pass");
			}
			if (parentContextMap.containsKey("tgt_additional_param")) {
				context.tgt_additional_param = (String) parentContextMap
						.get("tgt_additional_param");
			}
			if (parentContextMap.containsKey("rules")) {
				context.rules = (String) parentContextMap.get("rules");
			}
			if (parentContextMap.containsKey("src_sql")) {
				context.src_sql = (String) parentContextMap.get("src_sql");
			}
			if (parentContextMap.containsKey("logfile")) {
				context.logfile = (String) parentContextMap.get("logfile");
			}
			if (parentContextMap.containsKey("LogFileDir")) {
				context.LogFileDir = (String) parentContextMap
						.get("LogFileDir");
			}
			if (parentContextMap.containsKey("file_param_execute")) {
				context.file_param_execute = (String) parentContextMap
						.get("file_param_execute");
			}
			if (parentContextMap.containsKey("file_custom_sql_details")) {
				context.file_custom_sql_details = (String) parentContextMap
						.get("file_custom_sql_details");
			}
			if (parentContextMap.containsKey("file_schema_connection_details")) {
				context.file_schema_connection_details = (String) parentContextMap
						.get("file_schema_connection_details");
			}
			if (parentContextMap.containsKey("file_rule_details")) {
				context.file_rule_details = (String) parentContextMap
						.get("file_rule_details");
			}
			if (parentContextMap.containsKey("metadata_host")) {
				context.metadata_host = (String) parentContextMap
						.get("metadata_host");
			}
			if (parentContextMap.containsKey("metadata_port")) {
				context.metadata_port = (String) parentContextMap
						.get("metadata_port");
			}
			if (parentContextMap.containsKey("metadata_db_schema")) {
				context.metadata_db_schema = (String) parentContextMap
						.get("metadata_db_schema");
			}
			if (parentContextMap.containsKey("metadata_db_name")) {
				context.metadata_db_name = (String) parentContextMap
						.get("metadata_db_name");
			}
			if (parentContextMap.containsKey("metadata_db_user")) {
				context.metadata_db_user = (String) parentContextMap
						.get("metadata_db_user");
			}
			if (parentContextMap.containsKey("metadata_db_pass")) {
				context.metadata_db_pass = (java.lang.String) parentContextMap
						.get("metadata_db_pass");
			}
			if (parentContextMap.containsKey("file_ref_stat")) {
				context.file_ref_stat = (String) parentContextMap
						.get("file_ref_stat");
			}
			if (parentContextMap.containsKey("properties_file_path")) {
				context.properties_file_path = (String) parentContextMap
						.get("properties_file_path");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		parametersToEncrypt.add("metadata_db_pass");
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "",
				resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		talendStats_STATS.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			errorCode = null;
			tPrejob_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPrejob_1) {
			globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

			e_tPrejob_1.printStackTrace();

		}

		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		runningThreadCount.add(1);
		new Thread() {
			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				try {
					((java.util.Map) threadLocal.get()).put("errorCode", null);
					tFileInputExcel_1Process(globalMap);
					if (!"failure".equals(((java.util.Map) threadLocal.get())
							.get("status"))) {
						((java.util.Map) threadLocal.get())
								.put("status", "end");
					}
				} catch (TalendException e_tFileInputExcel_1) {
					globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);

					e_tFileInputExcel_1.printStackTrace();

				} catch (java.lang.Error e_tFileInputExcel_1) {
					globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", -1);
					((java.util.Map) threadLocal.get())
							.put("status", "failure");
					throw e_tFileInputExcel_1;

				} finally {
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal
							.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal
							.get()).get("status"));
					if (localErrorCode != null) {
						if (errorCode == null
								|| localErrorCode.compareTo(errorCode) > 0) {
							errorCode = localErrorCode;
						}
					}
					if (!status.equals("failure")) {
						status = localStatus;
					}

					runningThreadCount.add(-1);
				}
			}
		}.start();

		while (runningThreadCount.getCount() > 0) {
			try {
				Thread.sleep(10);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = true;// to run tPostJob

		try {
			errorCode = null;
			tPostjob_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPostjob_2) {
			globalMap.put("tPostjob_2_SUBPROCESS_STATE", -1);

			e_tPostjob_2.printStackTrace();

		}

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : Data_Masking");
		}
		talendStats_STATS.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			talendStats_STATSProcess(globalMap);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "" + returnCode, "",
				"", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index),
							keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		}

	}

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" },
			{ "\\'", "\'" }, { "\\r", "\r" }, { "\\f", "\f" }, { "\\b", "\b" },
			{ "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex,
							index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left
			// into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 492954 characters generated by Talend Data Fabric on the March 28, 2017
 * 2:57:46 PM CDT
 ************************************************************************************************/
