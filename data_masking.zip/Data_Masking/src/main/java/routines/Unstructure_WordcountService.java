/**
 * Unstructure_WordcountService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public interface Unstructure_WordcountService extends javax.xml.rpc.Service {
    public java.lang.String getUnstructure_WordcountAddress();

    public routines.Unstructure_Wordcount_PortType getUnstructure_Wordcount() throws javax.xml.rpc.ServiceException;

    public routines.Unstructure_Wordcount_PortType getUnstructure_Wordcount(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
