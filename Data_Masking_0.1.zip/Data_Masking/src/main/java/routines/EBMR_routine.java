package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class EBMR_routine {


    public static String classifier(Object mesh_terms,Object mesh_terms_subheadings,Object mesh_subheadings,String chemicals,String keyword,String authors,Object publication_type,String description,String abstract_other,Integer pubMedId,String article,String journal) {
    	StringBuilder  json_string=new StringBuilder ();
    	json_string.append("{\"pubMedId\": \"").append(pubMedId).append("\",\"title\": \"").append(article).append("\",\"journal\": \"").append(journal).append("\",\"mesh_terms\":");
        if(mesh_terms==null)
        {
        	json_string.append("[]");
        }
        else{
        	
        	json_string.append(mesh_terms);
        }
        if(mesh_terms_subheadings==null)
        {
        	json_string.append(",\"mesh_terms_subheadings\":[]");
        }
        else{
        	json_string.append(",\"mesh_terms_subheadings\":").append(mesh_terms_subheadings);
        }
        if(mesh_subheadings==null)
        {
        	json_string.append(",\"mesh_subheadings\":[]");
        }
        else
        {
        	json_string.append(",\"mesh_subheadings\":").append(mesh_subheadings);
        }
        json_string.append(",\"abstract_default\": \"").append(description);
        json_string.append("\",\"text_words\": \"").append(chemicals).append(" ").append(keyword).append(" ").append(authors).append(" ").append(abstract_other);
        if(publication_type==null)
        {
        	json_string.append("\",\"publication_type\": ").append("[]");        
        }
        else
        {
        	json_string.append("\",\"publication_type\": ").append(publication_type).append("}");
        }
        
       return json_string.toString();
    	
    }
}
