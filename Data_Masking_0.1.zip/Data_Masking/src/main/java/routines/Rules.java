package routines;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Arrays;

import routines.system.Dynamic;

public class Rules {

	public static void Execute(HashMap<String, ArrayList<RuleColumn>> rulesMap, Dynamic facts) {

		Iterator<Entry<String, ArrayList<RuleColumn>>> it = rulesMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, ArrayList<RuleColumn>> pair = (Entry<String, ArrayList<RuleColumn>>) it.next();
			switch (pair.getKey().toUpperCase()) {
			case "MASK_NUMBER":
				MaskNumber(pair.getValue(), facts);
				break;
			case "MASK_CHAR":
				MaskChar(pair.getValue(), facts);
				break;
			case "MASK_NUM_CHAR":
				Encrypt(pair.getValue(), facts);
				break;
			case "MASKTO9":
				MaskTO9(pair.getValue(), facts);
				break;
			case "MASKTOZ":
				MaskTOZ(pair.getValue(), facts);
				break;
			case "MASK_EMAIL_1":
				MaskEmail_1(pair.getValue(), facts);
				break;
			case "MASK_EMAIL_2":
				MaskEmail_2(pair.getValue(), facts);
				break;
			case "MASK_MIDDLE_3C2C":
				MaskMiddle3C2C(pair.getValue(), facts);
				break;
			case "MASKLR_3C":
				MaskLR3C(pair.getValue(), facts);
				break;
			case "MASKMIDDLE4C":
				MaskMiddle4C(pair.getValue(), facts);
				break;
			}
		}
	}

	private static void MaskNumber(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		//System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_NUMBER");
		// only 1 column in play
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {
				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						String regex = "(0|1|2|3|4|5|6|7|8|9)";
						String replacement = "^~!$1!~^";
						colValue = maskNumbers(strColVal.replaceAll(regex, replacement));
						facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_NUMBER, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_NUMBER, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskChar(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		// only 1 column in play
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {
				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						String regex = "(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z)";
						String replacement = "^~!$1!~^";
						colValue = maskCharacters(strColVal.replaceAll(regex, replacement));
						facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_CHAR, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_CHAR, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void Encrypt(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						colValue = maskAll(colValue.toString());
						facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_NUM_CHAR, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_NUM_CHAR, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskTOZ(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						colValue = strColVal.replaceAll("[a-zA-Z]", "Z");
						facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKTOZ, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKTOZ, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskEmail_1(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String email = colValue.toString();
						String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
						Boolean isValidEmail = email.matches(emailregex);
						if (isValidEmail == true) {
							String[] firstPartOfEmail = email.split("@");
							String name = firstPartOfEmail[0];
							String result = name.replaceAll("[^0-9]", "A");
							colValue = result + "@" + firstPartOfEmail[1];
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_EMAIL_1, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_EMAIL_1, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskEmail_2(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String email = colValue.toString();
						String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
						Boolean isValidEmail = email.matches(emailregex);
						if (isValidEmail == true) {
							String regex = "(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z)";
							String replacement = "^~!$1!~^";
							String[] firstPartOfEmail = email.split("@");
							String name = firstPartOfEmail[0];
							String result = maskCharacters(name.replaceAll(regex, replacement));
							colValue = result + "@" + firstPartOfEmail[1];
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_EMAIL_2, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_EMAIL_2, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskTO9(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {

		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						colValue = strColVal.replaceAll("[0-9]", "9");
						facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKTO9, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKTO9, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskLR3C(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {

		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {

						String strColVal = colValue.toString();
						if (strColVal.length() >= 10) {
							String middleString = strColVal.substring(3, strColVal.length() - 3);
							colValue = "XXX" + middleString + "XXX";
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						} else {
							colValue = maskAll(colValue.toString());
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKLR_3C, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKLR_3C, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskMiddle4C(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {

		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {

				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						String lastPart = "";
						String firstPart = "";
						if (strColVal.length() >= 10) {
							firstPart = strColVal.substring(0, strColVal.length() / 2 - 2);
							if (strColVal.length() % 2 == 0) {
								lastPart = strColVal.substring(strColVal.length() - strColVal.length() / 2 + 2,
										strColVal.length());
								colValue = firstPart + "XXXX" + lastPart;
							} else {
								lastPart = strColVal.substring(strColVal.length() - strColVal.length() / 2 + 2,
										strColVal.length());
								colValue = firstPart + "XXXXX" + lastPart;
							}
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						} else {
							colValue = maskAll(colValue.toString());
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKMIDDLE4C, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASKMIDDLE4C, Exception : " + Arrays.toString(e.getStackTrace()));
		}
	}

	private static void MaskMiddle3C2C(ArrayList<RuleColumn> ruleColumns, Dynamic facts) {
		try {
			Iterator<RuleColumn> i = ruleColumns.iterator();
			while (i.hasNext()) {
				RuleColumn ruleColumn = i.next();// one 1 column
				Object colValue = facts.getColumnValue(ruleColumn.cloumnName);
				try {
					if (colValue != null) {
						String strColVal = colValue.toString();
						String lastPart = "";
						String firstPart = "";
						if (strColVal.length() >= 10) {
							firstPart = strColVal.substring(0, strColVal.length() / 2 - 1);
							lastPart = strColVal.substring(strColVal.length() - strColVal.length() / 2 + 1,
									strColVal.length());
							colValue = firstPart + lastPart;
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						} else {
							colValue = maskAll(colValue.toString());
							facts.setColumnValue(ruleColumn.colMetadata.getColumnPosition() - 1, colValue);
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_MIDDLE_3C2C, Column name : " + ruleColumn.cloumnName + ", Column value : " + colValue + ", Exception : " + Arrays.toString(e.getStackTrace()));
				}
			}
		} catch (Exception e) {
			// log the exception
			System.out.println(TalendDate.getDate("yyyy-MM-dd HH:mm:ss") + "|Rule name : MASK_MIDDLE_3C2C, Exception : " + Arrays.toString(e.getStackTrace()));
		}
 	}

	public static String maskNumbers(String maskedString) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("0", "0");		map.put("1", "2");		map.put("2", "5");		map.put("3", "8");
		map.put("4", "0");		map.put("5", "9");		map.put("6", "8");		map.put("7", "4");
		map.put("8", "1");		map.put("9", "9");

		maskedString = maskedString.replace("^~!0!~^", map.get("0"));
		maskedString = maskedString.replace("^~!1!~^", map.get("1"));
		maskedString = maskedString.replace("^~!2!~^", map.get("2"));
		maskedString = maskedString.replace("^~!3!~^", map.get("3"));
		maskedString = maskedString.replace("^~!4!~^", map.get("4"));
		maskedString = maskedString.replace("^~!5!~^", map.get("5"));
		maskedString = maskedString.replace("^~!6!~^", map.get("6"));
		maskedString = maskedString.replace("^~!7!~^", map.get("7"));
		maskedString = maskedString.replace("^~!8!~^", map.get("8"));
		maskedString = maskedString.replace("^~!9!~^", map.get("9"));

		return maskedString;
	}

	public static String maskCharacters(String maskedString) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("a", "t");		map.put("b", "a");		map.put("c", "h");		map.put("d", "n");
		map.put("e", "u");		map.put("f", "b");		map.put("g", "i");		map.put("h", "o");
		map.put("i", "v");		map.put("j", "c");		map.put("k", "j");		map.put("l", "p");
		map.put("m", "w");		map.put("n", "d");		map.put("o", "k");		map.put("p", "q");
		map.put("q", "x");		map.put("r", "e");		map.put("s", "l");		map.put("t", "r");
		map.put("u", "y");		map.put("v", "f");		map.put("w", "m");		map.put("x", "s");
		map.put("y", "z");		map.put("z", "g");

		map.put("A", "Z");		map.put("B", "Y");		map.put("C", "X");		map.put("D", "W");
		map.put("E", "V");		map.put("F", "U");		map.put("G", "T");		map.put("H", "S");
		map.put("I", "R");		map.put("J", "Q");		map.put("K", "P");		map.put("L", "O");
		map.put("M", "N");		map.put("N", "M");		map.put("O", "L");		map.put("P", "K");
		map.put("Q", "J");		map.put("R", "I");		map.put("S", "H");		map.put("T", "G");
		map.put("U", "F");		map.put("V", "E");		map.put("W", "D");		map.put("X", "C");
		map.put("Y", "B");
		map.put("Z", "A");

		maskedString = maskedString.replace("^~!a!~^", map.get("a"));
		maskedString = maskedString.replace("^~!b!~^", map.get("b"));
		maskedString = maskedString.replace("^~!c!~^", map.get("c"));
		maskedString = maskedString.replace("^~!d!~^", map.get("d"));
		maskedString = maskedString.replace("^~!e!~^", map.get("e"));
		maskedString = maskedString.replace("^~!f!~^", map.get("f"));
		maskedString = maskedString.replace("^~!g!~^", map.get("g"));
		maskedString = maskedString.replace("^~!h!~^", map.get("h"));
		maskedString = maskedString.replace("^~!i!~^", map.get("i"));
		maskedString = maskedString.replace("^~!j!~^", map.get("j"));
		maskedString = maskedString.replace("^~!k!~^", map.get("k"));
		maskedString = maskedString.replace("^~!l!~^", map.get("l"));
		maskedString = maskedString.replace("^~!m!~^", map.get("m"));
		maskedString = maskedString.replace("^~!n!~^", map.get("n"));
		maskedString = maskedString.replace("^~!o!~^", map.get("o"));
		maskedString = maskedString.replace("^~!p!~^", map.get("p"));
		maskedString = maskedString.replace("^~!q!~^", map.get("q"));
		maskedString = maskedString.replace("^~!r!~^", map.get("r"));
		maskedString = maskedString.replace("^~!s!~^", map.get("s"));
		maskedString = maskedString.replace("^~!t!~^", map.get("t"));
		maskedString = maskedString.replace("^~!u!~^", map.get("u"));
		maskedString = maskedString.replace("^~!v!~^", map.get("v"));
		maskedString = maskedString.replace("^~!w!~^", map.get("w"));
		maskedString = maskedString.replace("^~!x!~^", map.get("x"));
		maskedString = maskedString.replace("^~!y!~^", map.get("y"));
		maskedString = maskedString.replace("^~!z!~^", map.get("z"));

		maskedString = maskedString.replace("^~!A!~^", map.get("A"));
		maskedString = maskedString.replace("^~!B!~^", map.get("B"));
		maskedString = maskedString.replace("^~!C!~^", map.get("C"));
		maskedString = maskedString.replace("^~!D!~^", map.get("D"));
		maskedString = maskedString.replace("^~!E!~^", map.get("E"));
		maskedString = maskedString.replace("^~!F!~^", map.get("F"));
		maskedString = maskedString.replace("^~!G!~^", map.get("G"));
		maskedString = maskedString.replace("^~!H!~^", map.get("H"));
		maskedString = maskedString.replace("^~!I!~^", map.get("I"));
		maskedString = maskedString.replace("^~!J!~^", map.get("J"));
		maskedString = maskedString.replace("^~!K!~^", map.get("K"));
		maskedString = maskedString.replace("^~!L!~^", map.get("L"));
		maskedString = maskedString.replace("^~!M!~^", map.get("M"));
		maskedString = maskedString.replace("^~!N!~^", map.get("N"));
		maskedString = maskedString.replace("^~!O!~^", map.get("O"));
		maskedString = maskedString.replace("^~!P!~^", map.get("P"));
		maskedString = maskedString.replace("^~!Q!~^", map.get("Q"));
		maskedString = maskedString.replace("^~!R!~^", map.get("R"));
		maskedString = maskedString.replace("^~!S!~^", map.get("S"));
		maskedString = maskedString.replace("^~!T!~^", map.get("T"));
		maskedString = maskedString.replace("^~!U!~^", map.get("U"));
		maskedString = maskedString.replace("^~!V!~^", map.get("V"));
		maskedString = maskedString.replace("^~!W!~^", map.get("W"));
		maskedString = maskedString.replace("^~!X!~^", map.get("X"));
		maskedString = maskedString.replace("^~!Y!~^", map.get("Y"));
		maskedString = maskedString.replace("^~!Z!~^", map.get("Z"));

		return maskedString;
	}

	public static String maskAll(String strColVal) {
		String regex = "(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|0|1|2|3|4|5|6|7|8|9)";
		String replacement = "^~!$1!~^";
		return encrypt(strColVal.replaceAll(regex, replacement));
	}

	public static String encrypt(String maskedString) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("a", "t");		map.put("b", "a");		map.put("c", "h");		map.put("d", "n");
		map.put("e", "u");		map.put("f", "b");		map.put("g", "i");		map.put("h", "o");
		map.put("i", "v");		map.put("j", "c");		map.put("k", "j");		map.put("l", "p");
		map.put("m", "w");		map.put("n", "d");		map.put("o", "k");		map.put("p", "q");
		map.put("q", "x");		map.put("r", "e");		map.put("s", "l");		map.put("t", "r");
		map.put("u", "y");		map.put("v", "f");		map.put("w", "m");		map.put("x", "s");
		map.put("y", "z");		map.put("z", "g");

		map.put("A", "Z");		map.put("B", "Y");		map.put("C", "X");		map.put("D", "W");
		map.put("E", "V");		map.put("F", "U");		map.put("G", "T");		map.put("H", "S");
		map.put("I", "R");		map.put("J", "Q");		map.put("K", "P");		map.put("L", "O");
		map.put("M", "N");		map.put("N", "M");		map.put("O", "L");		map.put("P", "K");
		map.put("Q", "J");		map.put("R", "I");		map.put("S", "H");		map.put("T", "G");
		map.put("U", "F");		map.put("V", "E");		map.put("W", "D");		map.put("X", "C");
		map.put("Y", "B");		map.put("Z", "A");		
		
		map.put("0", "0");		map.put("1", "2");		map.put("2", "5");		map.put("3", "8");		
		map.put("4", "0");		map.put("5", "9");		map.put("6", "8");		map.put("7", "4");		
		map.put("8", "1");		map.put("9", "9");

		maskedString = maskedString.replace("^~!0!~^", map.get("0"));
		maskedString = maskedString.replace("^~!1!~^", map.get("1"));
		maskedString = maskedString.replace("^~!2!~^", map.get("2"));
		maskedString = maskedString.replace("^~!3!~^", map.get("3"));
		maskedString = maskedString.replace("^~!4!~^", map.get("4"));
		maskedString = maskedString.replace("^~!5!~^", map.get("5"));
		maskedString = maskedString.replace("^~!6!~^", map.get("6"));
		maskedString = maskedString.replace("^~!7!~^", map.get("7"));
		maskedString = maskedString.replace("^~!8!~^", map.get("8"));
		maskedString = maskedString.replace("^~!9!~^", map.get("9"));

		maskedString = maskedString.replace("^~!a!~^", map.get("a"));
		maskedString = maskedString.replace("^~!b!~^", map.get("b"));
		maskedString = maskedString.replace("^~!c!~^", map.get("c"));
		maskedString = maskedString.replace("^~!d!~^", map.get("d"));
		maskedString = maskedString.replace("^~!e!~^", map.get("e"));
		maskedString = maskedString.replace("^~!f!~^", map.get("f"));
		maskedString = maskedString.replace("^~!g!~^", map.get("g"));
		maskedString = maskedString.replace("^~!h!~^", map.get("h"));
		maskedString = maskedString.replace("^~!i!~^", map.get("i"));
		maskedString = maskedString.replace("^~!j!~^", map.get("j"));
		maskedString = maskedString.replace("^~!k!~^", map.get("k"));
		maskedString = maskedString.replace("^~!l!~^", map.get("l"));
		maskedString = maskedString.replace("^~!m!~^", map.get("m"));
		maskedString = maskedString.replace("^~!n!~^", map.get("n"));
		maskedString = maskedString.replace("^~!o!~^", map.get("o"));
		maskedString = maskedString.replace("^~!p!~^", map.get("p"));
		maskedString = maskedString.replace("^~!q!~^", map.get("q"));
		maskedString = maskedString.replace("^~!r!~^", map.get("r"));
		maskedString = maskedString.replace("^~!s!~^", map.get("s"));
		maskedString = maskedString.replace("^~!t!~^", map.get("t"));
		maskedString = maskedString.replace("^~!u!~^", map.get("u"));
		maskedString = maskedString.replace("^~!v!~^", map.get("v"));
		maskedString = maskedString.replace("^~!w!~^", map.get("w"));
		maskedString = maskedString.replace("^~!x!~^", map.get("x"));
		maskedString = maskedString.replace("^~!y!~^", map.get("y"));
		maskedString = maskedString.replace("^~!z!~^", map.get("z"));

		maskedString = maskedString.replace("^~!A!~^", map.get("A"));
		maskedString = maskedString.replace("^~!B!~^", map.get("B"));
		maskedString = maskedString.replace("^~!C!~^", map.get("C"));
		maskedString = maskedString.replace("^~!D!~^", map.get("D"));
		maskedString = maskedString.replace("^~!E!~^", map.get("E"));
		maskedString = maskedString.replace("^~!F!~^", map.get("F"));
		maskedString = maskedString.replace("^~!G!~^", map.get("G"));
		maskedString = maskedString.replace("^~!H!~^", map.get("H"));
		maskedString = maskedString.replace("^~!I!~^", map.get("I"));
		maskedString = maskedString.replace("^~!J!~^", map.get("J"));
		maskedString = maskedString.replace("^~!K!~^", map.get("K"));
		maskedString = maskedString.replace("^~!L!~^", map.get("L"));
		maskedString = maskedString.replace("^~!M!~^", map.get("M"));
		maskedString = maskedString.replace("^~!N!~^", map.get("N"));
		maskedString = maskedString.replace("^~!O!~^", map.get("O"));
		maskedString = maskedString.replace("^~!P!~^", map.get("P"));
		maskedString = maskedString.replace("^~!Q!~^", map.get("Q"));
		maskedString = maskedString.replace("^~!R!~^", map.get("R"));
		maskedString = maskedString.replace("^~!S!~^", map.get("S"));
		maskedString = maskedString.replace("^~!T!~^", map.get("T"));
		maskedString = maskedString.replace("^~!U!~^", map.get("U"));
		maskedString = maskedString.replace("^~!V!~^", map.get("V"));
		maskedString = maskedString.replace("^~!W!~^", map.get("W"));
		maskedString = maskedString.replace("^~!X!~^", map.get("X"));
		maskedString = maskedString.replace("^~!Y!~^", map.get("Y"));
		maskedString = maskedString.replace("^~!Z!~^", map.get("Z"));

		return maskedString;
	}

}

